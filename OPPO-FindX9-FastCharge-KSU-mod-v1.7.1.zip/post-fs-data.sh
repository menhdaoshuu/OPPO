#!/system/bin/sh
MODDIR=${0%/*}
MODID=oppo_findx9_fastcharge
mkdir -p "$MODDIR/logs" 2>/dev/null
chmod 0755 "$MODDIR/logs" 2>/dev/null
chmod 0666 /sys/class/oplus_chg/battery/battery_cc 2>/dev/null
chmod 0666 /sys/class/power_supply/main/constant_charge_current_max 2>/dev/null
chmod 0666 /sys/class/power_supply/battery/constant_charge_current_max 2>/dev/null
chmod 0666 /sys/class/power_supply/battery/constant_charge_current 2>/dev/null
chmod 0666 /sys/class/xm_power/charger/charger_thermal/wired_chg_curr 2>/dev/null
USER_CONFIG=/data/adb/$MODID/fastcharge.conf
if [ ! -f "$USER_CONFIG" ]; then
  mkdir -p "/data/adb/$MODID" 2>/dev/null
  cp -f "$MODDIR/config/fastcharge.conf" "$USER_CONFIG" 2>/dev/null
  chmod 0644 "$USER_CONFIG" 2>/dev/null
else
  CONFIG_VERSION_TMPL=$(grep '^CONFIG_VERSION=' "$MODDIR/config/fastcharge.conf" 2>/dev/null | cut -d= -f2)
  CONFIG_VERSION_OLD=$(grep '^CONFIG_VERSION=' "$USER_CONFIG" 2>/dev/null | cut -d= -f2)
  if [ -n "$CONFIG_VERSION_TMPL" ] && [ "$CONFIG_VERSION_OLD" != "$CONFIG_VERSION_TMPL" ]; then
    cp -f "$USER_CONFIG" "$USER_CONFIG.bak" 2>/dev/null
    cp -f "$MODDIR/config/fastcharge.conf" "$USER_CONFIG" 2>/dev/null
    chmod 0644 "$USER_CONFIG" 2>/dev/null
  fi

  # ---- 增量迁移(不提升 CONFIG_VERSION, 以免整体覆盖掉用户的偏好设置) ----
  # v1.4.2: 补上 votable 强制激活开关(老配置里没有这一项)。
  # 默认 true 保持原有行为; 第三方 PPS/PD 充电器用户可自行改为 false 解决协议冲突。
  if ! grep -q '^VOOTABLE_FORCE_ACTIVE=' "$USER_CONFIG" 2>/dev/null; then
    echo 'VOOTABLE_FORCE_ACTIVE=true' >> "$USER_CONFIG" 2>/dev/null
  fi
fi
exit 0
