#!/system/bin/sh
# OPPO Find X9 FastCharge - UI independent service
# 重要：快充守护进程不得依赖 KSU WebUI。WebUI 只是控制/查看前端，关闭后仍应正常工作。

MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"

CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

# 等待系统完成启动；不再等待“屏幕亮起”，避免快充功能被 WebUI/屏幕状态间接影响。
i=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ] && [ "$i" -lt 180 ]; do
  sleep 2
  i=$((i + 2))
done

if [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; then
  log "系统启动完成，独立启动快充守护进程（不依赖 WebUI/屏幕状态）"
else
  log "等待 sys.boot_completed 超时，仍尝试启动快充守护进程"
fi

# ColorOS17 HANS 冻结修复: HANS 会把后台 App 的 binder 冻结(DEFER_BY_OPLUS FROZEN),
# 导致流体云载体 App 无法 notify 通知/接收广播, 流体云停更。
# 关闭 HANS 后 App 不再被冻结, 流体云可持续实时刷新(实测)。默认关闭, 可设 HANS_DISABLE=false 恢复。
if [ "${HANS_DISABLE:-true}" = "true" ]; then
  setprop sys.hans.enable false 2>/dev/null
  log "已关闭 HANS 后台冻结(避免流体云停更)"
fi

# ColorOS17 binder 冻结关闭(实验, 需重启生效):
#   dumpsys activity 的 freezer 配置里 `freeze_binder_enabled=true` 是后台 App binder 被冻结
#   (DEFER_BY_OPLUS FROZEN) 的直接开关, 但它属 AOSP CachedAppOptimizer 的 DeviceConfig,
#   **ActivityManager 只在开机时读取** —— 脚本里 put 之后本次开机不会立即生效, 需重启一次。
#   写入后可用 `device_config get activity_manager freeze_binder_enabled` 回读确认为 false。
#   若发现副作用可设 FREEZE_BINDER_DISABLE=false。
if [ "${FREEZE_BINDER_DISABLE:-true}" = "true" ]; then
  device_config put activity_manager freeze_binder_enabled false 2>/dev/null
  log "已写入 freeze_binder_enabled=false (重启后生效)"
fi

# 同步"残留清理脚本"到共享存储(每次开机自动更新):
#   customize.sh 只在"安装模块那一刻"复制一次, 之后模块升级/脚本改动都不会刷新它,
#   会导致用户手里的 /storage/emulated/0/FindX9快充残留清理.sh 长期停留在旧版本(缺新清理项)。
#   这里每次开机都比对内容, 不一致才覆盖, 保证它始终等于当前模块内的 scripts/cleanup.sh。
if [ "${CLEANUP_SYNC_ENABLE:-true}" = "true" ]; then
  _cl_dst=/storage/emulated/0/FindX9快充残留清理.sh
  _cl_src="$MODDIR/scripts/cleanup.sh"
  if [ -d /storage/emulated/0 ] && [ -f "$_cl_src" ]; then
    _sum_src=$(md5sum "$_cl_src" 2>/dev/null | cut -d' ' -f1)
    _sum_dst=$(md5sum "$_cl_dst" 2>/dev/null | cut -d' ' -f1)
    if [ -n "$_sum_src" ] && [ "$_sum_src" != "$_sum_dst" ]; then
      if cp -f "$_cl_src" "$_cl_dst" 2>/dev/null; then
        chmod 0755 "$_cl_dst" 2>/dev/null
        log "已同步最新残留清理脚本 -> /storage/emulated/0/FindX9快充残留清理.sh"
      fi
    fi
  fi
fi

if [ "${DAEMON_ENABLED:-true}" = "true" ]; then
  start_daemon
else
  apply_fastcharge
  exit $?
fi

# 启动本地 WebUI 服务(fcweb): 让"点击流体云"能跳转到浏览器可打开的页面,
# 不再依赖 KSU 管理器注入的 window.ksu。失败不影响快充主功能。
if [ "${FCWEB_ENABLE:-true}" = "true" ]; then
  ( setsid sh "$MODDIR/scripts/fcweb.sh" >/dev/null 2>&1 < /dev/null & ) 2>/dev/null
  log "本地 WebUI 服务(fcweb)已启动"
fi

# 轻量 watchdog：WebUI 关闭、KSU Manager 退出均不应影响 daemon。
# daemon 自己负责每秒重写充电控制；这里负责三件事：
#   1) daemon 意外退出后的拉起
#   2) daemon "假死"检测 —— Android 17 / ColorOS 17 实测存在 daemon 进程存活
#      但主循环卡住不干活的情况(表现为流体云一直停在旧值/待机、votable 电流不再刷新)。
#      通过监测流体云功率文件的修改时间来发现假死并强制重启。
#   3) fcweb 服务意外退出后的拉起
while :; do
  sleep 10
  if [ "${DAEMON_ENABLED:-true}" != "true" ]; then
    break
  fi
  if ! is_daemon_running; then
    log "检测到快充守护进程退出，自动重启"
    start_daemon
    continue
  fi
  # fcweb 看护
  if [ "${FCWEB_ENABLE:-true}" = "true" ]; then
    if ! pgrep -f "scripts/fcweb.sh" >/dev/null 2>&1; then
      ( setsid sh "$MODDIR/scripts/fcweb.sh" >/dev/null 2>&1 < /dev/null & ) 2>/dev/null
    fi
  fi
  # HANS 关闭复核: 系统/HANS 服务可能把 sys.hans.enable 改回 true, 定期(每 30s)再关闭一次
  if [ "${HANS_DISABLE:-true}" = "true" ] && [ "$(getprop sys.hans.enable 2>/dev/null)" != "false" ]; then
    setprop sys.hans.enable false 2>/dev/null
  fi
  # 假死检测: 流体云开启时, fluid_power.txt 应由 daemon 每 1 秒刷新一次。
  # 超过 30 秒未更新即判定假死, 强杀并重启(30 个刷新周期的冗余, 容忍系统短时调度抖动)。
  # 仅在流体云开启时检测 —— 关闭时该文件本来就不会更新, 否则会误判。
  if [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ]; then
    _fp="$LOG_DIR/fluid_power.txt"
    _mt=$(stat -c %Y "$_fp" 2>/dev/null)
    _now=$(date +%s)
    if [ -n "$_mt" ] && [ "$((_now - _mt))" -gt 30 ]; then
      log "检测到守护进程假死(流体云 90s 未更新)，强制重启"
      kill -9 "$(cat "$LOG_DIR/daemon.pid" 2>/dev/null)" 2>/dev/null
      start_daemon
    fi
  fi
done
exit 0
