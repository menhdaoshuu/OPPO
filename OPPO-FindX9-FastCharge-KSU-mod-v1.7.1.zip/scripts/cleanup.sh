#!/system/bin/sh
# OPPO Find X9 快充模块 —— 残留清理脚本
# 由模块每次开机自动同步到 /storage/emulated/0/FindX9快充残留清理.sh（保证始终是最新版）
CLEANUP_VER="v1.2"
MODID=oppo_findx9_fastcharge
MODROOT=/data/adb/modules/$MODID
USER_DIR=/data/adb/$MODID
LOG_DIR=$MODROOT/logs
APP_PKG=com.fcpower
APP_DATA=/data/data/$APP_PKG
SHARED_SCRIPT=/storage/emulated/0/FindX9快充残留清理.sh
confirm="ask"
keep_config=0
uninstall_app=0
restore_hans=0
for a in "$@"; do
  case "$a" in
    -y|--force|--yes) confirm="force" ;;
    --keep-config)    keep_config=1 ;;
    --uninstall-app)  uninstall_app=1 ;;
    --restore-hans)   restore_hans=1 ;;
    -h|--help)
      echo "用法: sh FindX9快充残留清理.sh [选项]"
      echo "  -y, --yes        跳过确认，直接清理"
      echo "  --keep-config    保留 fastcharge.conf（只清日志/手动值/临时文件）"
      echo "  --uninstall-app  同时卸载载体 App (com.fcpower) 及其数据"
      echo "  --restore-hans   恢复被模块关闭的 HANS 后台冻结开关"
      echo ""
      echo "版本: $CLEANUP_VER"
      exit 0
      ;;
    *)
      echo "! 未知参数: $a"
      exit 1
      ;;
  esac
done
if [ "$(id -u 2>/dev/null)" != "0" ]; then
  echo "! 需要 root 权限才能清理"
  echo "  请在 KernelSU 终端 / adb root 下执行，例如:"
  echo "    su -c sh $SHARED_SCRIPT -y"
  exit 1
fi
echo "==== OPPO Find X9 快充模块残留清理 ($CLEANUP_VER) ===="
if [ "$keep_config" = "1" ]; then
  echo "模式: 保留 $USER_DIR/fastcharge.conf，仅清日志/手动值/临时文件"
else
  echo "模式: 完整清理（含配置、手动电流、日志）"
fi
[ "$uninstall_app" = "1" ] && echo "附加: 卸载载体 App ($APP_PKG)"
[ "$restore_hans" = "1" ] && echo "附加: 恢复 HANS 后台冻结开关"
if [ "$confirm" != "force" ]; then
  printf "确认清理? [y/N] "
  read ans
  case "$ans" in
    y|Y|yes|YES) ;;
    *) echo "已取消"; exit 0 ;;
  esac
fi

# ---------- 1. 停止守护进程 ----------
killed=0
if [ -f "$LOG_DIR/daemon.pid" ]; then
  pid=$(cat "$LOG_DIR/daemon.pid" 2>/dev/null)
  if [ -n "$pid" ]; then
    kill "$pid" 2>/dev/null && { echo "[OK] 已停止守护进程 (PID $pid)"; killed=1; }
  fi
fi
if [ "$killed" = "0" ]; then
  if pkill -f 'fastcharge_daemon.sh' 2>/dev/null; then
    echo "[OK] 已停止守护进程 (pkill 兜底)"
  else
    echo "[--] 未发现运行中的守护进程"
  fi
fi
# 本地 WebUI 服务(手机端 fcweb)
if pgrep -f 'scripts/fcweb.sh' >/dev/null 2>&1; then
  pkill -f 'scripts/fcweb.sh' 2>/dev/null && echo "[OK] 已停止本地 WebUI 服务(fcweb)"
fi
# 模块自己的 watchdog(service.sh 循环)
if pkill -f "$MODID/service.sh" 2>/dev/null; then
  echo "[OK] 已停止模块 watchdog"
fi
sleep 1

# ---------- 2. 载体 App 侧 ----------
# 先标记"已关闭"，避免 App 在被停前又发通知；再停服务
if [ -d "$APP_DATA/files" ]; then
  _uid=$(stat -c %u "$APP_DATA" 2>/dev/null)
  : > "$APP_DATA/files/stopped" 2>/dev/null
  [ -n "$_uid" ] && chown "$_uid:$_uid" "$APP_DATA/files/stopped" 2>/dev/null
fi
if [ "$uninstall_app" = "1" ]; then
  if pm uninstall "$APP_PKG" >/dev/null 2>&1; then
    echo "[OK] 已卸载载体 App: $APP_PKG"
  else
    am force-stop "$APP_PKG" >/dev/null 2>&1
    pm clear "$APP_PKG" >/dev/null 2>&1
    echo "[OK] 已停止并清空载体 App 数据: $APP_PKG"
  fi
else
  # 未指定卸载: 只停服务 + 撤通知, 保留 App 便于重新启用
  am stop-service -n "$APP_PKG/.PowerService" >/dev/null 2>&1
  am force-stop "$APP_PKG" >/dev/null 2>&1
  echo "[OK] 已停止载体 App 服务（App 本体保留，如需卸载加 --uninstall-app）"
fi

# ---------- 3. 模块日志 ----------
if [ -d "$LOG_DIR" ]; then
  rm -rf "$LOG_DIR" 2>/dev/null
  echo "[OK] 已删除模块日志目录: $LOG_DIR"
else
  echo "[--] 日志目录不存在: $LOG_DIR"
fi

# ---------- 4. 用户配置 ----------
if [ "$keep_config" = "1" ]; then
  rm -f "$USER_DIR/fastcharge.conf.bak" 2>/dev/null
  rm -f "$USER_DIR/current_ma" 2>/dev/null
  rm -f "$USER_DIR/current_state.txt" 2>/dev/null
  # 删掉载体 App 版本记录 -> 下次开机 ensure_fluid_app 会重装载体(用于图标/刷新逻辑不生效时)
  rm -f "$USER_DIR/fluid.apk.ver" 2>/dev/null
  echo "[OK] 已清理: fastcharge.conf.bak / current_ma / current_state.txt / fluid.apk.ver（保留 fastcharge.conf）"
else
  if [ -d "$USER_DIR" ]; then
    rm -rf "$USER_DIR" 2>/dev/null
    echo "[OK] 已删除用户配置目录: $USER_DIR"
  else
    echo "[--] 用户配置目录不存在: $USER_DIR"
  fi
fi

# ---------- 5. 临时文件 ----------
n=0
for f in /data/local/tmp/ksu_fastcharge_key.txt \
         /data/local/tmp/key_event.txt \
         /dev/tmp/key_event.txt \
         /data/local/tmp/mod_backup \
         /data/local/tmp/fcmod.zip; do
  if [ -e "$f" ]; then
    rm -rf "$f" 2>/dev/null
    echo "[OK] 已删除临时文件: $f"
    n=$((n + 1))
  fi
done
[ "$n" = "0" ] && echo "[--] 无临时文件残留"

# ---------- 6. 恢复被模块改过的系统开关(可选) ----------
if [ "$restore_hans" = "1" ]; then
  setprop sys.hans.enable true 2>/dev/null
  setprop persist.sys.hans.appcard.enable true 2>/dev/null
  setprop persist.vendor.enable.hans true 2>/dev/null
  device_config delete activity_manager freeze_binder_enabled 2>/dev/null
  echo "[OK] 已恢复 HANS / freeze_binder 相关开关（重启后完全生效）"
fi

# ---------- 7. 旧版导出脚本 ----------
if [ -f /storage/emulated/0/cleanup_fastcharge.sh ]; then
  rm -f /storage/emulated/0/cleanup_fastcharge.sh 2>/dev/null
  echo "[OK] 已删除旧版导出脚本: /storage/emulated/0/cleanup_fastcharge.sh"
fi

echo "----------------------------------------"
if [ -d "$MODROOT" ]; then
  echo "!! 注意: 模块仍处于安装/启用状态"
  echo "   手机重启或屏幕亮起后 service.sh 会重新创建日志/写入限流"
  echo "   若不再使用: 请在 KSU 管理器卸载模块后，可再运行本脚本收尾"
  if [ "$keep_config" = "1" ]; then
    echo "   已保留用户配置: $USER_DIR/fastcharge.conf"
  fi
fi
echo "==== 清理完成 ($CLEANUP_VER) ===="
exit 0
