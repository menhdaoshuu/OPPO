#!/system/bin/sh
# =============================================================================
# fcweb - 快充模块的极简本地 Web 服务
#
# 用途: 让"点击流体云"能跳转到一个浏览器可打开的 WebUI(不再依赖 KernelSU 管理器
#       注入的 window.ksu)。浏览器通过 fetch POST 到本服务执行命令。
#
# 实现: 用 toybox nc (Android 必带) 做单连接 HTTP 服务, 无依赖 python/busybox httpd。
#       为保证每个请求独立响应, 采用"accept 一次处理一次"的循环。
#
# 端口: 默认 8099(避免与 KSU WebUI/其他服务冲突)。
# =============================================================================
MODDIR=${0%/*}
MODROOT=${MODDIR%/*}
export MODROOT
. "$MODROOT/scripts/common.sh" 2>/dev/null

PORT="${FCWEB_PORT:-8099}"
WWW="$MODROOT/webroot"

# 找到可用的 nc
NC=""
for c in /system/bin/nc /system/bin/toybox /data/adb/magisk/busybox /system/xbin/busybox; do
  [ -x "$c" ] && { NC="$c"; break; }
done
[ -z "$NC" ] && { log "fcweb: 未找到 nc/toybox"; exit 1; }

# toybox 需要 `toybox nc` 形式调用
nc_cmd() { if [ "${NC##*/}" = "toybox" ]; then "$NC" nc "$@"; else "$NC" "$@"; fi; }

# 执行命令并返回 JSON(转义由前端处理, 这里直接原文输出)
handle() {
  # 读请求头(到空行为止)
  reqline=""
  IFS= read -r reqline || { echo "HTTP/1.1 400 Bad Request"; echo; return; }
  method=${reqline%% *}
  path=${reqline#* }
  path=${path%% *}

  body=""
  cl=0
  while IFS= read -r line; do
    line=${line%$'\r'}
    [ -z "$line" ] && break
    case "$line" in
      [Cc]ontent-[Ll]ength:*) cl=${line##*:}; cl=${cl// /} ;;
    esac
  done

  if [ "$cl" -gt 0 ] 2>/dev/null; then
    IFS= read -r -n "$cl" body
  fi

  # 路由
  case "$path" in
    / | /index.html)
      echo "HTTP/1.1 200 OK"
      echo "Content-Type: text/html; charset=utf-8"
      echo "Content-Length: $(stat -c %s "$WWW/index.html" 2>/dev/null || echo 0)"
      echo
      cat "$WWW/index.html" 2>/dev/null
      return
      ;;
    /background.png)
      echo "HTTP/1.1 200 OK"
      echo "Content-Type: image/png"
      echo "Content-Length: $(stat -c %s "$WWW/background.png" 2>/dev/null || echo 0)"
      echo
      cat "$WWW/background.png" 2>/dev/null
      return
      ;;
    /exec)
      # body 为原始命令串(纯文本)
      if [ -n "$body" ]; then
        out=$(sh -c "$body" 2>&1)
        code=$?
      else
        out="(empty command)"
        code=1
      fi
      echo "HTTP/1.1 200 OK"
      echo "Content-Type: application/json; charset=utf-8"
      # 转义双引号/反斜杠/换行, 输出为 JSON 对象
      j=$(printf '%s' "$out" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\r//g' | sed ':a;N;$!ba;s/\n/\\n/g')
      body_json="{\"errno\":$code,\"stdout\":\"$j\",\"stderr\":\"\"}"
      echo "Content-Length: ${#body_json}"
      echo
      printf '%s' "$body_json"
      return
      ;;
    *)
      echo "HTTP/1.1 404 Not Found"
      echo
      return
      ;;
  esac
}

log "fcweb: 启动于 127.0.0.1:${PORT} (nc=$NC)"

# 主循环: 反复监听并处理单个连接
while :; do
  nc_cmd -l -p "$PORT" -s 127.0.0.1 2>/dev/null | handle
done
