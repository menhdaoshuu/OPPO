#!/system/bin/sh
MODID=oppo_findx9_fastcharge
USER_CONFIG_DIR=/data/adb/$MODID
DEFAULT_CONFIG=$MODROOT/config/fastcharge.conf
LOG_DIR=$MODROOT/logs
LOG_FILE=$LOG_DIR/fastcharge.log
STATUS_FILE=$LOG_DIR/status.txt
DAEMON_PID_FILE=$LOG_DIR/daemon.pid
DERATE_STATE=$LOG_DIR/derate.state
mkdir -p "$LOG_DIR" 2>/dev/null
log() {
  echo "[$(date '+%F %T')] $*" >> "$LOG_FILE"
}
load_config() {
  CONFIG_PATH="$1"
  if [ ! -f "$CONFIG_PATH" ]; then
    mkdir -p "$USER_CONFIG_DIR" 2>/dev/null
    cp -f "$DEFAULT_CONFIG" "$CONFIG_PATH" 2>/dev/null
    log "配置不存在，已从模板重建: $CONFIG_PATH"
  fi
  if [ -f "$CONFIG_PATH" ]; then
    . "$CONFIG_PATH"
  else
    log "警告: 配置加载失败，使用默认值"
  fi
  log "已加载配置: $CONFIG_PATH"
}
device_check() {
  if [ "${ENABLE_DEVICE_CHECK:-true}" = "false" ]; then
    log "机型校验已关闭 (ENABLE_DEVICE_CHECK=false)"
    return 0
  fi
  if [ -z "$DEVICE_CODENAMES" ]; then
    log "DEVICE_CODENAMES 为空，跳过机型校验"
    return 0
  fi
  dev=$(getprop ro.product.device 2>/dev/null)
  model=$(getprop ro.product.model 2>/dev/null)
  for c in $DEVICE_CODENAMES; do
    if [ "$c" = "$dev" ] || [ "$c" = "$model" ]; then
      log "机型匹配: $c (device=$dev model=$model)"
      return 0
    fi
  done
  log "机型不匹配，不应用充电设置 (device=$dev model=$model, 期望: $DEVICE_CODENAMES)"
  return 1
}
write_node() {
  node="$1"
  value="$2"
  [ -n "$node" ] || return 1
  if [ -w "$node" ]; then
    if echo "$value" > "$node" 2>/dev/null; then
      log "OK   $node = $value"
      return 0
    else
      log "FAIL $node = $value (写入失败)"
    fi
  else
    log "SKIP $node (不存在或无写权限)"
  fi
  return 1
}
is_charging() {
  for status in /sys/class/power_supply/*/status; do
    [ -r "$status" ] || continue
    st=$(cat "$status" 2>/dev/null)
    case "$st" in
      Charging|Full) return 0 ;;
    esac
  done
  return 1
}
get_battery_capacity() {
  node=${CAPACITY_NODE:-/sys/class/power_supply/battery/capacity}
  if [ -r "$node" ]; then
    cat "$node" 2>/dev/null
  else
    log "容量节点不可读: $node"
    echo ""
  fi
}
get_battery_temp_tenths() {
  node=${TEMP_NODE:-/sys/class/power_supply/battery/temp}
  if [ -r "$node" ]; then
    t=$(cat "$node" 2>/dev/null)
    case "$t" in
      ""|*[!0-9]*)
        log "温度值无效: '$t'"
        echo ""
        return 1
        ;;
    esac
    echo "$t"
  else
    log "温度节点不可读: $node"
    echo ""
    return 1
  fi
}
# 带符号功率: 正=充电, 负=耗电 (单位 W)
get_battery_power_w_signed() {
  # 真实功率(带正负): 充电为正, 放电为负。符号由 get_battery_current_now 按 STATUS 判定,
  # 兼容 ColorOS16(负=充) 与 ColorOS17(正=充) 两种电流符号约定。
  v=$(cat /sys/class/power_supply/battery/voltage_now 2>/dev/null | tr -d ' \n')
  i=$(get_battery_current_now)
  case "$v" in ""|*[!0-9-]*) return 1 ;; esac
  case "$i" in ""|*[!0-9-]*) return 1 ;; esac
  a=${i#-}
  [ "$a" -lt 1000 ] && return 1
  [ "$v" -lt 100000 ] && v=$((v * 1000))
  awk -v v="$v" -v i="$i" 'BEGIN { printf "%.1f", v * i / 1e12 }'
}

get_battery_current_now() {
  # Scene-compatible uevent parsing.
  # 单位: battery/bms uevent 的 CURRENT_NOW 为 mA; usb 的 INPUT_CURRENT_NOW 为 uA。
  # 符号约定随系统版本变化: ColorOS16 下 NEGATIVE=charging, ColorOS17 起 POSITIVE=charging。
  # 因此不再硬编码符号, 改由 POWER_SUPPLY_STATUS 决定: Charging/Full -> 正(充电), 其余 -> 负(放电)。
  local _st=""
  _st=$(cat /sys/class/power_supply/battery/status 2>/dev/null | tr -d ' \n')
  local _sign=1
  case "$_st" in
    Charging|Full) _sign=1 ;;
    *) _sign=-1 ;;
  esac
  for ue in /sys/class/power_supply/battery/uevent /sys/class/power_supply/bms/uevent; do
    [ -r "$ue" ] || continue
    v=$(grep -m1 '^POWER_SUPPLY_CURRENT_NOW=' "$ue" 2>/dev/null | cut -d= -f2)
    case "$v" in
      ""|*[!0-9-]*) continue ;;
    esac
    abs=${v#-}
    [ "$abs" -lt 10 ] && continue
    echo $((_sign * abs * 1000))
    return 0
  done
  # 兜底1: battery/current_now 文件(单位 mA)
  if [ -r /sys/class/power_supply/battery/current_now ]; then
    v=$(cat /sys/class/power_supply/battery/current_now 2>/dev/null | tr -d ' \n\r')
    case "$v" in
      ""|*[!0-9-]*) ;;
      *)
        abs=${v#-}
        [ "$abs" -ge 10 ] && { echo $((_sign * abs * 1000)); return 0; }
        ;;
    esac
  fi
  # 兜底2: usb/uevent 的 INPUT_CURRENT_NOW(单位 uA)
  if [ -r /sys/class/power_supply/usb/uevent ]; then
    v=$(grep -m1 '^POWER_SUPPLY_INPUT_CURRENT_NOW=' /sys/class/power_supply/usb/uevent 2>/dev/null | cut -d= -f2)
    case "$v" in
      ""|*[!0-9-]*) ;;
      *)
        abs=${v#-}
        [ "$abs" -ge 1000 ] && { echo $((_sign * abs)); return 0; }
        ;;
    esac
  fi
  # fallback: node chain ("path:multiplier:unit")
  for n in $CURRENT_NOW_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    node=${n%%:*}
    rest=${n#*:}
    mul=${rest%%:*}
    unit=${rest#*:}
    [ "$node" = "$n" ] && mul=1
    [ "$rest" = "$mul" ] && unit="ua"
    case "$mul" in
      ""|0|*[!0-9]*) mul=1 ;;
    esac
    case "$unit" in
      ""|ua) unit="ua" ;;
    esac
    [ -r "$node" ] || continue
    v=$(cat "$node" 2>/dev/null | tr -d ' \n\r')
    case "$v" in
      ""|*[!0-9-]*) continue ;;
    esac
    abs=${v#-}
    [ "$abs" -lt 10 ] && continue
    if [ "$unit" = "ma" ]; then
      res=$((v * mul * 1000))
    else
      res=$((v * mul))
    fi
    rabs=${res#-}
    [ "$rabs" -lt 1000 ] && continue
    echo "$res"
    return 0
  done
  return 1
}

# real-time charging power in W (battery voltage x current / 1e12)
get_battery_power_w() {
  v=$(cat /sys/class/power_supply/battery/voltage_now 2>/dev/null | tr -d ' \n')
  i=$(get_battery_current_now)
  case "$v" in ""|*[!0-9-]*) return 1 ;; esac
  case "$i" in ""|*[!0-9-]*) return 1 ;; esac
  i=${i#-}
  [ "$i" -lt 1000 ] && return 1
  # OPPO node family reports voltage_now in mV (e.g. 3979) -> convert to uV
  [ "$v" -lt 100000 ] && v=$((v * 1000))
  awk -v v="$v" -v i="$i" 'BEGIN { printf "%.1f", v * i / 1e12 }'
}
get_uevent_current_max() {
  for u in /sys/class/power_supply/battery/uevent /sys/class/power_supply/bms/uevent; do
    [ -r "$u" ] || continue
    v=$(grep -m1 'POWER_SUPPLY_CURRENT_MAX=' "$u" 2>/dev/null | cut -d= -f2)
    if [ -n "$v" ]; then
      echo "$v"
      return 0
    fi
  done
  return 1
}
current_for_capacity() {
  cap="$1"
  case "$cap" in
    ""|*[!0-9]*)
      log "电量值无效: '$cap'"
      return 1
      ;;
  esac
  low=${CAP_LOW:-10}
  high=${CAP_HIGH:-70}
  if   [ "$cap" -lt "$low" ]; then v=${CURRENT_LOW_MA:-5000}
  elif [ "$cap" -le "$high" ]; then v=${CURRENT_MID_MA:-8000}
  else v=${CURRENT_HIGH_MA:-3000}; fi
  case "$v" in
    ""|*[!0-9]*) ;;
    *)
      case "$GLOBAL_MAX_MA" in
        ""|*[!0-9]*) ;;
        *) [ "$v" -gt "$GLOBAL_MAX_MA" ] && v=$GLOBAL_MAX_MA ;;
      esac
      ;;
  esac
  echo "$v"
}
pick_charger_node() {
  if [ -n "$CURRENT_NODE" ] && [ -w "$CURRENT_NODE" ]; then
    echo "$CURRENT_NODE"
    return 0
  fi
  for n in $CHARGER_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ -w "$n" ]; then
      echo "$n"
      return 0
    fi
  done
  log "未找到可写的充电电流节点"
  return 1
}
derate_current() {
  ma="$1"
  if [ "${TEMP_DERATE_ENABLE:-true}" != "true" ]; then
    echo "$ma"
    return 0
  fi
  t=$(get_battery_temp_tenths)
  [ -z "$t" ] && { echo "$ma"; return 0; }
  critical_t=${TEMP_CRITICAL_TENTHS:-450}
  critical_exit=${TEMP_CRITICAL_EXIT_TENTHS:-440}
  critical_ma=${TEMP_CRITICAL_MA:-0}
  hard_t=${TEMP_HARD_CAP_TENTHS:-420}
  hard_exit=${TEMP_HARD_CAP_EXIT_TENTHS:-415}
  hard_ma=${TEMP_HARD_CAP_MA:-2000}
  l1=${TEMP_L1_TENTHS:-416}
  l2=${TEMP_L2_TENTHS:-438}
  l3=${TEMP_L3_TENTHS:-445}
  exit_l=${TEMP_LIMIT_EXIT_TENTHS:-406}
  min_ma=${TEMP_MIN_MA:-2000}
  max_ma=${TEMP_MAX_MA:-15000}
  state=""
  [ -f "$DERATE_STATE" ] && state=$(cat "$DERATE_STATE" 2>/dev/null)
  if [ "$t" -gt "$critical_t" ] || { [ "$state" = "critical" ] && [ "$t" -gt "$critical_exit" ]; }; then
    if [ "$state" != "critical" ]; then
      log "进入 45℃ 临界保护: 电流 ${critical_ma}mA (充电保持连接, 放电速度为正)"
    fi
    echo "critical" > "$DERATE_STATE" 2>/dev/null
    echo "$critical_ma"
    return 0
  fi
  if [ "$t" -gt "$hard_t" ] || { [ "$state" = "hard" ] && [ "$t" -gt "$hard_exit" ]; }; then
    val=$(awk -v ma="$ma" -v t="$t" -v l1="$l1" -v l2="$l2" -v l3="$l3" \
          -v min_ma="$min_ma" -v max_ma="$max_ma" 'BEGIN {
      if (ma > max_ma) ma = max_ma;
      if (t > l3) t = l3;
      v = ma * exp((t - l1) / 10.0 * log(0.94));
      if (t > l2) v = v * exp((t - l2) / 10.0 * log(0.85));
      if (v < min_ma) v = min_ma;
      printf "%d", v + 0.5
    }')
    if [ "$val" -gt "$hard_ma" ]; then
      val=$hard_ma
    fi
    if [ "$state" != "hard" ]; then
      log "进入 42℃ 硬顶保护: 最大电流 ${val}mA"
    fi
    echo "hard" > "$DERATE_STATE" 2>/dev/null
    echo "$val"
    return 0
  fi
  limited=""
  [ "$state" = "scene" ] && limited=1
  if [ "$t" -gt "$l1" ] || { [ "$limited" = "1" ] && [ "$t" -gt "$exit_l" ]; }; then
    val=$(awk -v ma="$ma" -v t="$t" -v l1="$l1" -v l2="$l2" -v l3="$l3" \
          -v min_ma="$min_ma" -v max_ma="$max_ma" 'BEGIN {
      if (ma > max_ma) ma = max_ma;
      if (t > l3) t = l3;
      v = ma * exp((t - l1) / 10.0 * log(0.94));
      if (t > l2) v = v * exp((t - l2) / 10.0 * log(0.85));
      if (v < min_ma) v = min_ma;
      printf "%d", v + 0.5
    }')
    echo "scene" > "$DERATE_STATE" 2>/dev/null
    echo "$val"
  else
    rm -f "$DERATE_STATE" 2>/dev/null
    echo "$ma"
  fi
}
try_write() {
  node="$1"
  value="$2"
  err=$( { echo "$value" > "$node"; } 2>&1 )
  if [ -z "$err" ]; then
    return 0
  fi
  echo "$err"
  return 1
}
write_input_current_ma() {
  ma="$1"
  if [ "${WRITE_UNIT:-ua}" = "ma" ]; then
    value=$ma
  else
    value=$((ma * 1000))
  fi
  for n in $INPUT_CURRENT_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ -w "$n" ]; then
      err=$(try_write "$n" "$value")
      if [ -z "$err" ]; then
        rb=$(cat "$n" 2>/dev/null)
        log "OK   输入限流 ${ma}mA (${value}ua) -> $n (读回: $rb)"
      else
        chmod 0666 "$n" 2>/dev/null
        err=$(try_write "$n" "$value")
        if [ -z "$err" ]; then
          rb=$(cat "$n" 2>/dev/null)
          log "OK   输入限流 ${ma}mA (${value}ua) -> $n (chmod 后成功, 读回: $rb)"
        else
          log "SKIP 输入限流 $n ($err)"
        fi
      fi
    else
      log "SKIP 输入限流 $n (不存在或无写权限)"
    fi
  done
}
write_votable_ma() {
  ma="$1"
  [ "${VOOTABLE_ENABLE:-true}" = "true" ] || return 0
  div=${VOOTABLE_DIVIDER:-1}
  case "$div" in
    ""|0|*[!0-9]*) div=1 ;;
  esac
  if [ "$div" -gt 1 ]; then
    ma=$((ma / div))
    [ "$ma" -lt 1 ] && ma=1
  fi
  # 强制激活标志: 默认 1, 与原行为完全一致。
  # 第三方 PPS/PD 充电器下若出现协议投票冲突(电流锁死 10W), 把 VOOTABLE_FORCE_ACTIVE
  # 改成 false —— 此时写 0 主动解除强制激活, 让系统按充电器实际类型自己选协议。
  _fa=1
  [ "${VOOTABLE_FORCE_ACTIVE:-true}" = "true" ] || _fa=0
  for v in $VOOTABLE_NODES; do
    case "$v" in
      ""|\#*) continue ;;
    esac
    if [ -w "$v/force_val" ]; then
      if echo "$ma" > "$v/force_val" 2>/dev/null; then
        echo "$_fa" > "$v/force_active" 2>/dev/null
        eff=$(cat "$v/status" 2>/dev/null | grep -o 'effective=[^ ]* type=[^ ]* v=[0-9]*' | head -1)
        log "OK   votable $v = ${ma}mA (active=${_fa} $eff)"
      else
        log "FAIL votable $v = ${ma}mA (写入失败)"
      fi
    else
      log "SKIP votable $v (不存在或无写权限)"
    fi
  done
}
check_overspeed() {
  [ "${SAFETY_OVERRIDE_ENABLE:-true}" = "true" ] || return 0
  now=$(get_battery_current_now)
  case "$now" in
    ""|*[!0-9-]*) return 0 ;;
  esac
  abs=${now#-}
  limit_ma=${SAFETY_MAX_MA:-8000}
  case "$limit_ma" in
    ""|*[!0-9]*) return 0 ;;
  esac
  limit_ua=$((limit_ma * 1000))
  if [ "$abs" -gt "$limit_ua" ]; then
    fallback=${SAFETY_FALLBACK_MA:-2000}
    log "!! 过流保护触发: 实测 ${abs}µA ($((abs / 1000))mA) > 上限 ${limit_ma}mA，强制压到 ${fallback}mA"
    write_votable_ma "$fallback"
    echo "OVERRIDE" > "$DERATE_STATE" 2>/dev/null
    return 1
  fi
  return 0
}
write_voltage_cap() {
  [ "${VOLTAGE_CAP_ENABLE:-true}" = "true" ] || return 0
  for n in $VOLTAGE_CAP_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ -w "$n" ]; then
      if echo "$VOLTAGE_CAP_UV" > "$n" 2>/dev/null; then
        log "OK   电压上限 ${VOLTAGE_CAP_UV}µV ($((VOLTAGE_CAP_UV / 1000000))V) -> $n"
      else
        log "FAIL 电压上限写入失败 -> $n"
      fi
    else
      log "SKIP 电压上限节点不可写 -> $n"
    fi
  done
}
check_votable_ma() {
  ma="$1"
  [ "${VOOTABLE_ENABLE:-true}" = "true" ] || return 0
  div=${VOOTABLE_DIVIDER:-1}
  case "$div" in
    ""|0|*[!0-9]*) div=1 ;;
  esac
  # 比对用的"期望写入值": 必须与 write_votable_ma 内部的算法保持一致(它自己会做除法)。
  # 注意: 这里算出来的 expect **只用于比较**, 传给 write_votable_ma 的必须是原始 ma ——
  # 否则会被除两次(11000 -> 5500 -> 2750), 电流只剩目标的 1/4,
  # 且校验永远不通过, 造成每 2 秒一次的"补写"死循环。
  expect=$ma
  if [ "$div" -gt 1 ]; then
    expect=$((ma / div))
    [ "$expect" -lt 1 ] && expect=1
  fi
  for v in $VOOTABLE_NODES; do
    case "$v" in
      ""|\#*) continue ;;
    esac
    [ -r "$v/force_val" ] || continue
    cur=$(cat "$v/force_val" 2>/dev/null)
    if [ "$cur" != "$expect" ]; then
      log "votable 值被改动 ($cur != $expect)，补写 $v"
      write_votable_ma "$ma"
      return 0
    fi
  done
}
apply_derated() {
  ma="$1"
  cap="$2"
  if [ "${SYSFS_WRITE_ENABLE:-false}" = "true" ]; then
    write_current_ma "$ma" "$cap"
    rc=$?
  else
    rc=0
  fi
  write_votable_ma "$ma"
  return $rc
}
write_current_ma() {
  ma="$1"
  cap="$2"
  if [ "${WRITE_UNIT:-ua}" = "ma" ]; then
    value=$ma
    unit="ma"
  else
    value=$((ma * 1000))
    unit="ua"
  fi
  if [ -n "$CURRENT_NODE" ]; then
    err=$(try_write "$CURRENT_NODE" "$value")
    if [ -z "$err" ]; then
      rb=$(cat "$CURRENT_NODE" 2>/dev/null)
      if [ -n "$rb" ] && [ "$rb" != "$value" ]; then
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $CURRENT_NODE (读回: $rb) !! 读回≠写入，可能被内核钳制"
      else
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $CURRENT_NODE (读回: $rb)"
      fi
      write_input_current_ma "$ma"
      return 0
    fi
    chmod 0666 "$CURRENT_NODE" 2>/dev/null
    err=$(try_write "$CURRENT_NODE" "$value")
    if [ -z "$err" ]; then
      log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $CURRENT_NODE (chmod 后成功)"
      write_input_current_ma "$ma"
      return 0
    fi
    log "FAIL 电流 ${ma}mA -> $CURRENT_NODE ($err)"
    return 1
  fi
  for n in $CHARGER_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    err=$(try_write "$n" "$value")
    if [ -z "$err" ]; then
      rb=$(cat "$n" 2>/dev/null)
      if [ -n "$rb" ] && [ "$rb" != "$value" ]; then
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $n (读回: $rb) !! 读回≠写入，可能被内核钳制"
      else
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $n (读回: $rb)"
      fi
      write_input_current_ma "$ma"
      return 0
    fi
    chmod 0666 "$n" 2>/dev/null
    err=$(try_write "$n" "$value")
    if [ -z "$err" ]; then
      log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $n (chmod 后成功)"
      write_input_current_ma "$ma"
      return 0
    fi
    log "SKIP $n ($err)"
  done
  log "FAIL 电流 ${ma}mA 所有节点均写入失败"
  return 1
}
probe_nodes() {
  log "==== 自动节点探测开始（真实充电状态）===="
  baseline=$(get_battery_current_now)
  log "PROBE 充电基线 current_now=$baseline"
  for n in $PROBE_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ ! -e "$n" ]; then
      log "PROBE $n 不存在"
      continue
    fi
    pre=$(cat "$n" 2>/dev/null)
    log "PROBE $n 原始值: $pre"
    for tv in 3000 3000000; do
      err=$(try_write "$n" "$tv")
      sleep 2
      rb=$(cat "$n" 2>/dev/null)
      now=$(get_battery_current_now)
      log "PROBE $n 写$tv -> 错误:[$err] 读回:[$rb] current_now:[$now]"
    done
  done
  log "==== 自动节点探测结束 ===="
}
is_daemon_running() {
  [ -f "$DAEMON_PID_FILE" ] || return 1
  pid=$(cat "$DAEMON_PID_FILE" 2>/dev/null)
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}
start_daemon() {
  if is_daemon_running; then
    log "守护进程已在运行 (PID $(cat "$DAEMON_PID_FILE"))"
    return 0
  fi
  if command -v nohup >/dev/null 2>&1; then
    nohup sh "$MODROOT/scripts/fastcharge_daemon.sh" "$MODROOT" >> "$LOG_FILE" 2>&1 &
  else
    sh "$MODROOT/scripts/fastcharge_daemon.sh" "$MODROOT" >> "$LOG_FILE" 2>&1 &
  fi
  log "守护进程启动中 (PID $!)"
  echo "$!" > "$DAEMON_PID_FILE" 2>/dev/null
}
stop_daemon() {
  if [ -f "$DAEMON_PID_FILE" ]; then
    pid=$(cat "$DAEMON_PID_FILE" 2>/dev/null)
    [ -n "$pid" ] && kill "$pid" 2>/dev/null
    rm -f "$DAEMON_PID_FILE"
    log "已停止守护进程 (PID $pid)"
  fi
}
apply_fastcharge() {
  log "==== 开始应用充电设置 ===="
  device_check || return 1
  if [ -n "$CHARGE_RULES" ]; then
    printf '%s\n' "$CHARGE_RULES" | while IFS= read -r rule; do
      rule=$(echo "$rule" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')
      [ -z "$rule" ] && continue
      case "$rule" in
        \#*) continue ;;
        *=*)
          node=${rule%%=*}
          value=${rule#*=}
          write_node "$node" "$value"
          ;;
        *)
          log "规则格式无效，跳过: $rule"
          ;;
      esac
    done
  fi
  if [ -n "$EXTRA_COMMANDS" ]; then
    printf '%s\n' "$EXTRA_COMMANDS" | while IFS= read -r cmd; do
      case "$cmd" in
        ""|\#*) continue ;;
      esac
      log "执行附加命令: $cmd"
      sh -c "$cmd" >> "$LOG_FILE" 2>&1
    done
  fi
  cap=$(get_battery_capacity)
  base=$(current_for_capacity "$cap")
  result="SKIP: 电量不可用"
  derated=""
  if [ -n "$base" ]; then
    derated=$(derate_current "$base")
    if write_current_ma "$derated" "$cap"; then
      result="OK ${derated}mA (目标 ${base}mA)"
    else
      result="FAIL ${derated}mA (所有节点写入失败)"
    fi
  fi
  actual=$(get_battery_current_now)
  {
    echo "last_apply=$(date '+%F %T')"
    echo "result=$result"
    echo "capacity=${cap}%"
    echo "target_current=${base}mA"
    echo "applied_current=${derated:-none}mA"
    echo "actual_current=${actual:-n/a}µA"
    echo "device=$(getprop ro.product.device 2>/dev/null) model=$(getprop ro.product.model 2>/dev/null)"
    echo "config=$CONFIG_PATH"
  } > "$STATUS_FILE" 2>/dev/null
  log "==== 应用完成 ===="
}
MANUAL_CURRENT_FILE=$USER_CONFIG_DIR/current_ma
MANUAL_STATE_FILE=$USER_CONFIG_DIR/current_state.txt
read_manual_current() {
  [ -f "$MANUAL_CURRENT_FILE" ] || return 1
  v=$(tr -d ' \t\r' < "$MANUAL_CURRENT_FILE" 2>/dev/null)
  case "$v" in
    ""|*[!0-9]*)
      log "手动电流文件内容无效: '$v'（回退自动档）"
      rm -f "$MANUAL_CURRENT_FILE" 2>/dev/null
      return 1
      ;;
  esac
  echo "$v"
  return 0
}
clamp_manual_ma() {
  ma="$1"
  case "$ma" in
    ""|*[!0-9]*) echo ""; return 1 ;;
  esac
  min=${MANUAL_MIN_MA:-1000}
  max=${MANUAL_MAX_MA:-8800}
  gm=${GLOBAL_MAX_MA:-0}
  case "$gm" in
    ""|*[!0-9]*) gm=0 ;;
  esac
  if [ "$gm" -gt 0 ] && [ "$max" -gt "$gm" ]; then max=$gm; fi
  [ "$ma" -lt "$min" ] && ma=$min
  [ "$ma" -gt "$max" ] && ma=$max
  echo "$ma"
}
apply_current_ma_direct() {
  ma="$1"
  [ -n "$ma" ] || return 1
  cap=$(get_battery_capacity)
  derated=$(derate_current "$ma")
  [ -z "$derated" ] && derated=$ma
  if apply_derated "$derated" "$cap"; then
    echo "OK"
  else
    echo "FAIL"
  fi
}
set_manual_current() {
  ma="$1"
  if [ -z "$ma" ] || [ "$ma" -le 0 ]; then
    rm -f "$MANUAL_CURRENT_FILE" 2>/dev/null
    log "恢复自动档位电流（按电量分档）"
    mode="auto"
    mc="auto"
    result=$(apply_current_ma_direct "$(current_for_capacity "$(get_battery_capacity)")")
  else
    clamped=$(clamp_manual_ma "$ma") || { log "手动电流值无效: '$ma'"; return 1; }
    ma=$clamped
    log "设置手动电流: ${ma}mA"
    echo "$ma" > "$MANUAL_CURRENT_FILE" 2>/dev/null
    mode="manual"
    mc="${ma}mA"
    result=$(apply_current_ma_direct "$ma")
  fi
  cap=$(get_battery_capacity)
  {
    echo "mode=$mode"
    echo "manual_current=$mc"
    echo "capacity=${cap}%"
    echo "apply_result=${result:-n/a}"
    echo "last_set=$(date '+%F %T')"
  } > "$MANUAL_STATE_FILE" 2>/dev/null
  [ "$result" = "OK" ]
}

# ============================================================
# system limit unlock (bright-screen charge acceleration)
# re-applies system limit nodes every loop; keeps slider control
# ============================================================
ensure_node_value() {
  node="$1"; want="$2"; tag="$3"
  [ -n "$node" ] || return 0
  [ -e "$node" ] || return 0
  [ -w "$node" ] || return 0
  cur=$(cat "$node" 2>/dev/null)
  [ "$cur" = "$want" ] && return 0
  if echo "$want" > "$node" 2>/dev/null; then
    log "UNLOCK  ${tag} $node = ${want} (was ${cur})"
  fi
}

apply_limit_unlock() {
  [ "${LIMIT_UNLOCK_ENABLE:-true}" != "true" ] && return 0
  ensure_node_value /sys/class/oplus_chg/battery/cool_down 0 "cool-down"
  ensure_node_value /sys/class/oplus_chg/battery/normal_cool_down 0 "normal-cool"
  ensure_node_value /sys/class/power_supply/battery/step_charging_enabled 0 "step-charging"
  ensure_node_value /sys/class/power_supply/battery/restricted_charging 0 "restricted"
}
# ============================================================
# Fluid Cloud realtime charging power (bundled carrier app apk/base.apk)
# the app posts an ONGOING (non-clearable) notification driven by broadcast
# 刷新频率: 模块每 FLUID_CLOUD_INTERVAL_SEC(默认3)s 写一次功率到 App 私有文件,
#           载体 App 自轮询(500ms)后重发通知 -> 通知栏/流体云与 WebUI 同频(3s)
# ============================================================
FLUID_POWER_FILE=$LOG_DIR/fluid_power.txt
FLUID_PKG=com.fcpower
FLUID_APK_NAME=base.apk
# 内置载体 App 的 versionCode(构建时随 Apk 一起写入), 用于模块升级后自动覆盖安装。
# 不这样做的话, 模块升级换了图标/刷新逻辑, 手机上仍是旧 App, 改动不会生效。
FLUID_APK_VERSION_FILE=version.txt

# ColorOS 防冻结/防清理: 加入系统不冻结白名单 + 待机分组/白名单/后台权限
fluid_protect_app() {
  cur=$(settings get secure no_frozen 2>/dev/null)
  case "$cur" in
    *${FLUID_PKG}*) ;;
    *)
      settings put secure no_frozen "${cur}${FLUID_PKG}," >/dev/null 2>&1
      log "FLUID 已加入系统不冻结白名单"
      ;;
  esac
  # 流体云胶囊免动画(消除"收起->弹出"闪烁)
  _ca=$(settings get secure oplus_no_fluid_capsule_animation 2>/dev/null)
  case "$_ca" in
    *${FLUID_PKG}*) ;;
    *)
      _ca=$(echo "$_ca" | sed 's/^null//; s/^,//')
      settings put secure oplus_no_fluid_capsule_animation "${_ca},${FLUID_PKG}" >/dev/null 2>&1
      log "FLUID 已关闭胶囊动画(消除闪烁)"
      ;;
  esac
  am set-standby-bucket ${FLUID_PKG} active >/dev/null 2>&1
  dumpsys deviceidle whitelist +${FLUID_PKG} >/dev/null 2>&1
  cmd appops set ${FLUID_PKG} RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
}

# 已安装载体 App 的 versionCode:
#   1) 优先读模块自己记录的安装版本(最可靠, 不依赖 ROM 的 dumpsys 输出格式)
#   2) 其次 dumpsys / pm dump
fluid_installed_version() {
  _sv=$(tr -d ' \t\r\n' < "$USER_CONFIG_DIR/fluid.apk.ver" 2>/dev/null)
  if [ -n "$_sv" ]; then echo "$_sv"; return 0; fi
  _dv=$(dumpsys package ${FLUID_PKG} 2>/dev/null | grep -m1 -o 'versionCode=[0-9]*' | cut -d= -f2)
  if [ -n "$_dv" ]; then echo "$_dv"; return 0; fi
  _pv=$(pm dump ${FLUID_PKG} 2>/dev/null | grep -m1 -o 'versionCode=[0-9]*' | cut -d= -f2)
  [ -n "$_pv" ] && echo "$_pv"
}

# 版本号读不到时的兜底: 比较已安装 APK 与模块内置 APK 的体积
fluid_installed_size() {
  _p=$(pm path ${FLUID_PKG} 2>/dev/null | head -1 | sed 's/^package://')
  [ -n "$_p" ] && [ -f "$_p" ] && stat -c %s "$_p" 2>/dev/null
}

ensure_fluid_app() {
  [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ] || return 1
  apk="${MODROOT:-/data/adb/modules/oppo_findx9_fastcharge}/apk/${FLUID_APK_NAME}"
  [ -f "$apk" ] || apk="/data/adb/modules/oppo_findx9_fastcharge/apk/${FLUID_APK_NAME}"
  want=$(tr -d ' \t\r\n' < "${apk%/*}/${FLUID_APK_VERSION_FILE}" 2>/dev/null)
  if pm list packages 2>/dev/null | grep -q "package:${FLUID_PKG}"; then
    have=$(fluid_installed_version)
    if [ -n "$want" ] && [ "$have" = "$want" ]; then
      return 0                      # 已是内置版本, 无需重装
    fi
    if [ -z "$have" ] && [ -f "$apk" ]; then
      _isz=$(fluid_installed_size)
      _wsz=$(stat -c %s "$apk" 2>/dev/null)
      if [ -n "$_isz" ] && [ "$_isz" = "$_wsz" ]; then
        [ -n "$want" ] && echo "$want" > "$USER_CONFIG_DIR/fluid.apk.ver" 2>/dev/null
        return 0
      fi
    fi
    log "FLUID 载体版本变更 (${have:-unknown} -> ${want:-unknown}), 覆盖安装以应用新图标/刷新逻辑"
  else
    log "FLUID 未检测到载体 App, 开始安装 ${FLUID_APK_NAME}"
  fi
  [ -f "$apk" ] || { log "FLUID 未找到载体 ${FLUID_APK_NAME}"; return 1; }
  pm install -r -g "$apk" >/dev/null 2>&1
  pm grant ${FLUID_PKG} android.permission.POST_NOTIFICATIONS >/dev/null 2>&1
  am set-standby-bucket ${FLUID_PKG} active >/dev/null 2>&1
  dumpsys deviceidle whitelist +${FLUID_PKG} >/dev/null 2>&1
  cmd appops set ${FLUID_PKG} RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
  fluid_protect_app
  am start-foreground-service -n com.fcpower/.PowerService --es pw "待机" >/dev/null 2>&1
  if [ -n "$want" ]; then
    mkdir -p "$USER_CONFIG_DIR" 2>/dev/null
    echo "$want" > "$USER_CONFIG_DIR/fluid.apk.ver" 2>/dev/null
  fi
  log "FLUID 载体已安装 (versionCode=${want:-unknown}) 并拉起前台服务"
  return 0
}

# 流体云刷新: 每 FLUID_CLOUD_INTERVAL_SEC 秒(默认3s, 与 WebUI 同频)推送一次,
# 载体 App 另有 500ms 自轮询兜底 -> 通知栏/流体云功率数值在 3s 内更新
# 充电中 -> "45.2 W"; 未充电/放电 -> "-3.2 W"(耗电)
# 处理流体云胶囊/滑块发来的电流请求(立即生效)
# ============================================================
# 三档模式(游戏/日常/速充) - 数值由安装时音量键选择写入 modes.conf
# ============================================================
MODES_FILE=${MODES_FILE:-/data/adb/oppo_findx9_fastcharge/modes.conf}

read_mode_ma() {
  _m="$1"
  _g=0; _d=0; _f=0; _c=0
  if [ -f "$MODES_FILE" ]; then
    _c=$(grep -m1 '^COOLER=' "$MODES_FILE" 2>/dev/null | cut -d= -f2)
    _g=$(grep -m1 '^GAME=' "$MODES_FILE" 2>/dev/null | cut -d= -f2)
    _d=$(grep -m1 '^DAILY=' "$MODES_FILE" 2>/dev/null | cut -d= -f2)
    _f=$(grep -m1 '^FAST=' "$MODES_FILE" 2>/dev/null | cut -d= -f2)
  fi
  case "$_c" in 0|1) ;; *) _c=0 ;; esac
  case "$_g" in ""|*[!0-9]*) [ "$_c" = "1" ] && _g=6900 || _g=3000 ;; esac
  case "$_d" in ""|*[!0-9]*) [ "$_c" = "1" ] && _d=8000 || _d=6000 ;; esac
  case "$_f" in ""|*[!0-9]*) [ "$_c" = "1" ] && _f=11000 || _f=8100 ;; esac
  case "$_m" in
    game|游戏) echo "$_g" ;;
    daily|日常) echo "$_d" ;;
    fast|速充) echo "$_f" ;;
    *) echo "" ;;
  esac
}

apply_mode() {
  _m="$1"
  _ma=$(read_mode_ma "$_m")
  [ -n "$_ma" ] || { log "未知模式: $_m"; return 1; }
  if set_manual_current "$_ma" >/dev/null 2>&1; then
    log "模式切换: ${_m} -> ${_ma}mA (立即生效)"
    echo "$_m" > "$LOG_DIR/current_mode" 2>/dev/null
    return 0
  fi
  log "模式切换失败: ${_m} (${_ma}mA)"
  return 1
}

fluid_apply_request() {
  _reqf=/data/data/com.fcpower/files/current_req
  [ -f "$_reqf" ] || return 0
  _req=$(tr -d ' \t\r\n' < "$_reqf" 2>/dev/null)
  rm -f "$_reqf" 2>/dev/null
  case "$_req" in
    auto) set_manual_current 0 >/dev/null 2>&1; log "流体云控制: 恢复自动档" ;;
    mode:*) apply_mode "${_req#mode:}" ;;
    ""|*[!0-9]*) ;;
    *) set_manual_current "$_req" >/dev/null 2>&1; log "流体云控制: 手动电流 ${_req}mA (立即生效)" ;;
  esac
}

fluid_tick() {
  # WebUI 开关免重启即时生效: 每轮从配置文件重新读取开关值, 而不是沿用启动快照。
  # (守护进程启动时 load_config 就把值读进内存了, 之后改 conf 对运行中的进程无效,
  #  这正是 WebUI「流体云开关不生效」的根因)
  _fce_tip=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
  _fce=$(grep -m1 '^FLUID_CLOUD_ENABLE=' "$_fce_tip" 2>/dev/null | tr -d ' \t\r\n' | cut -d= -f2)
  case "$_fce" in true|false) FLUID_CLOUD_ENABLE="$_fce" ;; esac
  [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ] || return 0
  _nu=$(date +%s)
  _lf=$(cat "$LOG_DIR/fluid.last" 2>/dev/null)
  case "$_lf" in ""|*[!0-9]*) _lf=0 ;; esac
  [ $((_nu - _lf)) -ge "${FLUID_CLOUD_INTERVAL_SEC:-3}" ] || return 0
  echo "$_nu" > "$LOG_DIR/fluid.last" 2>/dev/null

  # 1) 解冻载体App的 uid cgroup(纯文件操作)
  _uid=$(stat -c %u /data/data/com.fcpower 2>/dev/null)
  if [ -n "$_uid" ]; then
    _fz="/sys/fs/cgroup/apps/uid_${_uid}/cgroup.freeze"
    if [ -r "$_fz" ] && [ "$(cat "$_fz" 2>/dev/null)" = "1" ]; then
      echo 0 > "$_fz" 2>/dev/null
    fi
  fi

  # 2) 读功率+实际电流, 写状态文件 + App私有文件(App轮询读取, 作为兜底)
  _pw=$(get_battery_power_w_signed 2>/dev/null)
  [ -n "$_pw" ] || _pw="0.0"
  _cur=$(get_battery_current_now 2>/dev/null)
  case "$_cur" in ""|*[!0-9-]*) _cur=0 ;; esac
  echo "$(date '+%F %T') ${_pw}W" > "$FLUID_POWER_FILE" 2>/dev/null
  if [ -d /data/data/com.fcpower/files ]; then
    echo "$_pw" > /data/data/com.fcpower/files/power 2>/dev/null
    chown "$_uid:$_uid" /data/data/com.fcpower/files/power 2>/dev/null
    chmod 600 /data/data/com.fcpower/files/power 2>/dev/null
    echo "$_cur" > /data/data/com.fcpower/files/current_now 2>/dev/null
    chown "$_uid:$_uid" /data/data/com.fcpower/files/current_now 2>/dev/null
    chmod 600 /data/data/com.fcpower/files/current_now 2>/dev/null
    _mc=$(read_manual_current 2>/dev/null)
    [ -n "$_mc" ] || _mc="auto"
    echo "$_mc" > /data/data/com.fcpower/files/current 2>/dev/null
    _cm=$(cat "$LOG_DIR/current_mode" 2>/dev/null)
    [ -n "$_cm" ] && echo "$_cm" > /data/data/com.fcpower/files/mode 2>/dev/null && chown "$_uid:$_uid" /data/data/com.fcpower/files/mode 2>/dev/null
    chown "$_uid:$_uid" /data/data/com.fcpower/files/current 2>/dev/null
    chmod 600 /data/data/com.fcpower/files/current 2>/dev/null
  fi

  # 3) 兜底通道: 广播推送(系统禁止后台启动前台服务, 广播用于 App 进程被清后仍能刷新)
  #    实时刷新已由载体 App 自轮询 files/power(500ms) 承担, 广播降频到 3s 以省电,
  #    避免每秒 fork 一个 am 进程拖慢系统
  _bc=$(cat "$LOG_DIR/fluid.bcast" 2>/dev/null)
  case "$_bc" in ""|*[!0-9]*) _bc=0 ;; esac
  if [ $((_nu - _bc)) -ge "${FLUID_BROADCAST_INTERVAL_SEC:-3}" ]; then
    echo "$_nu" > "$LOG_DIR/fluid.bcast" 2>/dev/null
    ( timeout 6 am broadcast -n com.fcpower/.PowerReceiver -a com.fcpower.UPDATE -f 0x01000000 --es pw "$_pw" >/dev/null 2>&1 ) &
  fi

  # 3b) 载体 App 保活(音频保活 + 心跳检测):
  #     App 侧用静音音频轨(AudioTrack, USAGE_MEDIA) + MediaSession 让 ColorOS 把它当"正在播放媒体",
  #     减少被 DEFER_BY_OPLUS 冻结的频率; 心跳(files/hb, poll 每秒写)一旦停止则补拉一次。
  #     ⚠️ 曾试过用 1x1 透明常驻 Activity(KeepAliveActivity) 进一步防冻结, 但它在**最近任务里
  #        渲染成巨大纯黑空白卡片**(标题"充电动率"), 用户以为"应用无响应" —— 已废弃, 不要再用。
  if [ "${FLUID_KEEPALIVE_ENABLE:-true}" = "true" ]; then
    _need=""
    if ! pidof com.fcpower >/dev/null 2>&1; then
      _need="1"                                    # App 进程不在 -> 拉起
    else
      _hb=$(stat -c %Y /data/data/com.fcpower/files/hb 2>/dev/null)
      case "$_hb" in ""|*[!0-9]*) _hb=0 ;; esac
      [ $((_nu - _hb)) -ge "${FLUID_HB_STALE_SEC:-12}" ] && _need="1"   # 心跳停 -> 被冻结, 解冻
    fi
    if [ -n "$_need" ]; then
      _ka=$(cat "$LOG_DIR/fluid.keepalive" 2>/dev/null)
      case "$_ka" in ""|*[!0-9]*) _ka=0 ;; esac
      if [ $((_nu - _ka)) -ge "${FLUID_UNFREEZE_MIN_GAP_SEC:-5}" ]; then
        echo "$_nu" > "$LOG_DIR/fluid.keepalive" 2>/dev/null
        # --activity-clear-task: 复用任务栈, 避免每次解冻都新建一个 MainActivity Task 堆积
        ( timeout 6 am start -n com.fcpower/.MainActivity --activity-clear-task >/dev/null 2>&1 ) &
      fi
    fi
  fi

  # 4) 防冻结/免动画白名单每 5 分钟复核一次
  _np=$(cat "$LOG_DIR/fluid.protect" 2>/dev/null)
  case "$_np" in ""|*[!0-9]*) _np=0 ;; esac
  if [ $((_nu - _np)) -ge 300 ]; then
    echo "$_nu" > "$LOG_DIR/fluid.protect" 2>/dev/null
    ( timeout 10 fluid_protect_app >/dev/null 2>&1 ) &
  fi
}

