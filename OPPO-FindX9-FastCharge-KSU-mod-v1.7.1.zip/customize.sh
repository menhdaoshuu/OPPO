#!/system/bin/sh
MODID=oppo_findx9_fastcharge
USER_CONFIG_DIR=/data/adb/$MODID
USER_CONFIG=$USER_CONFIG_DIR/fastcharge.conf
ui_print "***********************************************"
ui_print "* OPPO Find X9 快充增强模块 (KernelSU)"
ui_print "***********************************************"
ui_print ""
. "$MODPATH/config/fastcharge.conf" 2>/dev/null
ui_print ""
ui_print "!! 警告 / WARNING !!"
ui_print "本模块采用大电流快充方案（最高 13000mA）"
ui_print "请务必搭配散热器 / 散热背夹使用！"
ui_print "安装本模块后，请卸载温度伪装类模块！"
ui_print "否则温度降额保护失效，可能过热损坏电池与主板"
ui_print ""
wait_key_event() {
  if [ -n "$TMPDIR" ] && [ -d "$TMPDIR" ]; then
    ev_file="$TMPDIR/key_event.txt"
  else
    ev_file="/data/local/tmp/key_event.txt"
  fi
  mkdir -p "$(dirname "$ev_file")" 2>/dev/null
  rm -f "$ev_file" 2>/dev/null
  getevent -lc 1 2>/dev/null > "$ev_file" &
  local pid=$!
  local waited=0
  while [ ! -s "$ev_file" ]; do
    if ! kill -0 "$pid" 2>/dev/null; then
      break
    fi
    waited=$((waited + 1))
    if [ "$waited" -ge 30 ]; then
      kill "$pid" 2>/dev/null
      break
    fi
    sleep 1
  done
  cat "$ev_file" 2>/dev/null
}
cooler_profile_choose() {
  local modes_dir="/data/adb/$MODID"
  local modes_file="$modes_dir/modes.conf"
  if ! getevent -lp 2>/dev/null | grep -q 'KEY_VOLUMEUP'; then
    ui_print "! 未检测到音量键设备，按[未搭配散热器]安全档配置"
    write_modes "$modes_file" 0
    return 0
  fi
  ui_print ""
  ui_print "============================================"
  ui_print "  请选择使用方式（决定三档电流上限）："
  ui_print "    [音量-]  已搭配散热器使用（高性能档）"
  ui_print "             游戏 6900mA / 日常 8000mA / 速充 11000mA"
  ui_print "    [音量+]  未搭配散热器使用（安全档）"
  ui_print "             游戏 3000mA / 日常 6000mA / 速充 8100mA"
  ui_print "============================================"
  ui_print ""
  ui_print "- 等待按键（30 秒无操作按安全档继续）..."
  local choice=""
  while [ -z "$choice" ]; do
    ev=$(wait_key_event)
    case "$ev" in
      *KEY_VOLUMEDOWN*) choice="cooler" ;;
      *KEY_VOLUMEUP*)   choice="nocooler" ;;
      "")               choice="timeout" ;;
    esac
  done
  case "$choice" in
    cooler)
      ui_print "- 已确认：搭配散热器（高性能档）"
      write_modes "$modes_file" 1
      ;;
    nocooler)
      ui_print "- 已确认：未搭配散热器（安全档）"
      write_modes "$modes_file" 0
      ;;
    *)
      ui_print "- 未操作，默认按[未搭配散热器]安全档配置"
      write_modes "$modes_file" 0
      ;;
  esac
  return 0
}

write_modes() {
  local f="$1"; local cooler="$2"
  mkdir -p "$(dirname "$f")" 2>/dev/null
  if [ "$cooler" = "1" ]; then
    {
      echo "# 三档电流配置(安装时音量键选择): 1=已搭配散热器 0=未搭配"
      echo "COOLER=1"
      echo "GAME=6900"
      echo "DAILY=8000"
      echo "FAST=11000"
    } > "$f"
  else
    {
      echo "# 三档电流配置(安装时音量键选择): 1=已搭配散热器 0=未搭配"
      echo "COOLER=0"
      echo "GAME=3000"
      echo "DAILY=6000"
      echo "FAST=8100"
    } > "$f"
  fi
}
if [ "$KSU" = "true" ] && [ "${SKIP_VOL_CONFIRM:-0}" != "1" ]; then
  if [ -f /data/adb/modules/$MODID/module.prop ]; then
    ui_print "- 检测到模块已安装（更新/重装），自动跳过按键确认"
  else
    cooler_profile_choose
  fi
fi
if [ "$KSU" = "true" ]; then
  ui_print "- KernelSU: $KSU_VER (userspace $KSU_VER_CODE / kernel $KSU_KERNEL_VER_CODE)"
else
  ui_print "! 未检测到 KernelSU 环境，请使用 KernelSU 管理器安装"
fi
if [ -d /data/adb/modules ]; then
  spoof_found=""
  for m in /data/adb/modules/*/; do
    [ -d "$m" ] || continue
    [ -f "$m/module.prop" ] || continue
    name=$(grep -E '^(name|description)=' "$m/module.prop" 2>/dev/null | tr '\n' ' ' | tr '[:upper:]' '[:lower:]')
    case "$name" in
      *温度伪装*|*温度欺骗*|*温度*伪装*|*spoof*temp*|*temp*spoof*)
        spoof_found="$spoof_found ${m%/}"
        ;;
    esac
  done
  if [ -n "$spoof_found" ]; then
    ui_print "!! 检测到温度伪装模块，请卸载后重启:"
    for s in $spoof_found; do
      ui_print "   $s"
    done
    ui_print ""
  fi
fi
if command -v getprop >/dev/null 2>&1; then
  DEVICE=$(getprop ro.product.device 2>/dev/null)
  MODEL=$(getprop ro.product.model 2>/dev/null)
  ui_print "- 当前设备: device=$DEVICE model=$MODEL"
fi
if [ -f "$USER_CONFIG" ]; then
  cp -f "$USER_CONFIG" "$USER_CONFIG.bak" 2>/dev/null
  ui_print "- 备份旧配置: $USER_CONFIG.bak"
fi
mkdir -p "$USER_CONFIG_DIR"
cp -f "$MODPATH/config/fastcharge.conf" "$USER_CONFIG" 2>/dev/null
ui_print "- 已安装最新配置: $USER_CONFIG"
ui_print "  快充数据请编辑该文件，然后点击模块\"操作\"按钮应用"

# export cleanup script to shared storage (usable after module uninstall)
rm -f /storage/emulated/0/cleanup_fastcharge.sh 2>/dev/null
if cp -f "$MODPATH/scripts/cleanup.sh" /storage/emulated/0/FindX9快充残留清理.sh 2>/dev/null; then
  chmod 0755 /storage/emulated/0/FindX9快充残留清理.sh 2>/dev/null
  ui_print "- 清理脚本已复制: /storage/emulated/0/FindX9快充残留清理.sh"
else
  ui_print "! 清理脚本复制到 /storage/emulated/0/ 失败"
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh"          0 0 0755
set_perm "$MODPATH/boot-completed.sh"   0 0 0755
set_perm "$MODPATH/action.sh"           0 0 0755
set_perm "$MODPATH/post-fs-data.sh"     0 0 0755
set_perm "$MODPATH/uninstall.sh"        0 0 0755
set_perm "$MODPATH/scripts/common.sh"   0 0 0755
set_perm "$MODPATH/scripts/apply_fastcharge.sh" 0 0 0755
set_perm "$MODPATH/scripts/fastcharge_daemon.sh" 0 0 0755
set_perm "$MODPATH/scripts/cleanup.sh"   0 0 0755
ui_print "- 安装完成"
