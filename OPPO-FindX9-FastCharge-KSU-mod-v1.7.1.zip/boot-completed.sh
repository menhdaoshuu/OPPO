#!/system/bin/sh
# boot-completed fallback. It is intentionally UI-independent.
MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"
CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

# 载体 App(流体云)自动安装/升级: 模块升级会带新的图标与刷新逻辑,
# 必须在开机完成后覆盖安装一次, 否则手机上仍是旧 App(小飞机图标依旧)
ensure_fluid_app

if [ "${DAEMON_ENABLED:-true}" = "true" ]; then
  if ! is_daemon_running; then
    log "boot-completed 兜底：启动快充守护进程（不等待 WebUI/屏幕）"
    start_daemon
  else
    log "boot-completed 兜底：守护进程已运行"
  fi
else
  apply_fastcharge
fi
exit 0
