#!/system/bin/sh

MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"

# full residual cleanup on uninstall (daemon/logs/config/manual state/temp files)
if [ -f "$MODDIR/scripts/cleanup.sh" ]; then
  sh "$MODDIR/scripts/cleanup.sh" -y
fi

rm -f /storage/emulated/0/cleanup_fastcharge.sh 2>/dev/null

echo "uninstall cleanup done."
echo "note: current limit resets on replug or reboot."
exit 0
