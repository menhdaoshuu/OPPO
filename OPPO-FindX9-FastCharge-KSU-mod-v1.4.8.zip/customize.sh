#!/system/bin/sh
MODID=oppo_findx9_fastcharge
USER_CONFIG_DIR=/data/adb/$MODID
USER_CONFIG=$USER_CONFIG_DIR/fastcharge.conf
ui_print "***********************************************"
ui_print "* OPPO Find X9 快充增强模块 (KernelSU)"
ui_print "***********************************************"
ui_print ""
ui_print "!! 测试版本 / TEST BUILD !!"
ui_print "本模块当前处于测试阶段，OPPOfindx9Pro已完成测试"
ui_print "如有疑问请在酷安反馈"
. "$MODPATH/config/fastcharge.conf" 2>/dev/null
ui_print ""
ui_print "!! 警告 / WARNING !!"
ui_print "本模块采用大电流快充方案（最高 ${CURRENT_MID_MA:-8000}mA）"
ui_print "请务必搭配散热器 / 散热背夹使用！"
ui_print "安装本模块后，请卸载温度伪装类模块！"
ui_print "否则温度降额保护失效，可能过热损坏电池与主板"
ui_print ""
wait_key_event() {
  if [ -n "$TMPDIR" ] && [ -d "$TMPDIR" ]; then
    ev_file="$TMPDIR/key_event.txt"
  else
    ev_file="/data/local/tmp/key_event.txt"
  fi
  mkdir -p "$(dirname "$ev_file")" 2>/dev/null
  rm -f "$ev_file" 2>/dev/null
  getevent -lc 1 2>/dev/null > "$ev_file" &
  local pid=$!
  local waited=0
  while [ ! -s "$ev_file" ]; do
    if ! kill -0 "$pid" 2>/dev/null; then
      break
    fi
    waited=$((waited + 1))
    if [ "$waited" -ge 30 ]; then
      kill "$pid" 2>/dev/null
      break
    fi
    sleep 1
  done
  cat "$ev_file" 2>/dev/null
}
volume_key_choose() {
  if ! getevent -lp 2>/dev/null | grep -q 'KEY_VOLUMEUP'; then
    ui_print "! 未检测到音量键设备，跳过按键确认（直接继续）"
    return 0
  fi
  ui_print ""
  ui_print "============================================"
  ui_print "  请选择操作："
  ui_print "    [音量+] 同意安装并继续"
  ui_print "    [音量-] 不同意，退出安装"
  ui_print "============================================"
  ui_print ""
  ui_print "- 等待按键（30 秒无操作默认退出安装）..."
  local choice=""
  while [ -z "$choice" ]; do
    ev=$(wait_key_event)
    case "$ev" in
      *KEY_VOLUMEUP*)   choice="yes" ;;
      *KEY_VOLUMEDOWN*) choice="no" ;;
      "")               choice="timeout" ;;
    esac
  done
  case "$choice" in
    yes)
      ui_print "- 已确认，继续安装"
      return 0
      ;;
    *)
      ui_print "! 已取消安装"
      return 1
      ;;
  esac
}
if [ "$KSU" = "true" ] && [ "${SKIP_VOL_CONFIRM:-0}" != "1" ]; then
  if [ -f /data/adb/modules/$MODID/module.prop ]; then
    ui_print "- 检测到模块已安装（更新/重装），自动跳过按键确认"
  else
    if ! volume_key_choose; then
      abort "! 用户选择退出安装"
    fi
  fi
fi
if [ "$KSU" = "true" ]; then
  ui_print "- KernelSU: $KSU_VER (userspace $KSU_VER_CODE / kernel $KSU_KERNEL_VER_CODE)"
else
  ui_print "! 未检测到 KernelSU 环境，请使用 KernelSU 管理器安装"
fi
if [ -d /data/adb/modules ]; then
  spoof_found=""
  for m in /data/adb/modules/*/; do
    [ -d "$m" ] || continue
    [ -f "$m/module.prop" ] || continue
    name=$(grep -E '^(name|description)=' "$m/module.prop" 2>/dev/null | tr '\n' ' ' | tr '[:upper:]' '[:lower:]')
    case "$name" in
      *温度伪装*|*温度欺骗*|*温度*伪装*|*spoof*temp*|*temp*spoof*)
        spoof_found="$spoof_found ${m%/}"
        ;;
    esac
  done
  if [ -n "$spoof_found" ]; then
    ui_print "!! 检测到温度伪装模块，请卸载后重启:"
    for s in $spoof_found; do
      ui_print "   $s"
    done
    ui_print ""
  fi
fi
if command -v getprop >/dev/null 2>&1; then
  DEVICE=$(getprop ro.product.device 2>/dev/null)
  MODEL=$(getprop ro.product.model 2>/dev/null)
  ui_print "- 当前设备: device=$DEVICE model=$MODEL"
fi
if [ -f "$USER_CONFIG" ]; then
  cp -f "$USER_CONFIG" "$USER_CONFIG.bak" 2>/dev/null
  ui_print "- 备份旧配置: $USER_CONFIG.bak"
fi
mkdir -p "$USER_CONFIG_DIR"
cp -f "$MODPATH/config/fastcharge.conf" "$USER_CONFIG" 2>/dev/null
ui_print "- 已安装最新配置: $USER_CONFIG"
ui_print "  快充数据请编辑该文件，然后点击模块\"操作\"按钮应用"

# export cleanup script to shared storage (usable after module uninstall)
if cp -f "$MODPATH/scripts/cleanup.sh" /storage/emulated/0/cleanup_fastcharge.sh 2>/dev/null; then
  chmod 0755 /storage/emulated/0/cleanup_fastcharge.sh 2>/dev/null
  ui_print "- 清理脚本已复制: /storage/emulated/0/cleanup_fastcharge.sh"
else
  ui_print "! 清理脚本复制到 /storage/emulated/0/ 失败"
fi

set_perm_recursive "$MODPATH" 0 0 0755 0644
set_perm "$MODPATH/service.sh"          0 0 0755
set_perm "$MODPATH/boot-completed.sh"   0 0 0755
set_perm "$MODPATH/action.sh"           0 0 0755
set_perm "$MODPATH/post-fs-data.sh"     0 0 0755
set_perm "$MODPATH/uninstall.sh"        0 0 0755
set_perm "$MODPATH/scripts/common.sh"   0 0 0755
set_perm "$MODPATH/scripts/apply_fastcharge.sh" 0 0 0755
set_perm "$MODPATH/scripts/fastcharge_daemon.sh" 0 0 0755
set_perm "$MODPATH/scripts/cleanup.sh"   0 0 0755
ui_print "- 安装完成"
