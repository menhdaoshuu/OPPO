#!/system/bin/sh
# actions: (no arg = self-check) set <ma> | auto | apply | restart | start | stop | clean | status

MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"

CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

# key=value status (for WebUI)
status_lines() {
  m=$(read_manual_current)
  if [ -n "$m" ]; then
    mode="manual"; mc="${m}mA"
  else
    mode="auto"; mc="auto"
  fi
  cap=$(get_battery_capacity)
  t=$(get_battery_temp_tenths)
  now=$(get_battery_current_now)
  if is_charging; then st="charging"; else st="idle"; fi
  base="$m"
  [ -z "$base" ] && base=$(current_for_capacity "$cap")
  [ -z "$base" ] && base="n/a"

  echo "mode=$mode"
  echo "manual_current=$mc"
  echo "charging=$st"
  echo "capacity=${cap:-n/a}"
  if [ -n "$t" ]; then echo "temp=$((t / 10)).$((t % 10))"; else echo "temp=n/a"; fi
  echo "current_now=${now:-n/a}"
  echo "power=$(get_battery_power_w 2>/dev/null)"
  echo "target_current=${base}mA"

  if [ -f "$STATUS_FILE" ]; then
    grep -E '^(applied_current|result|node|daemon_pid|last_apply)=' "$STATUS_FILE" 2>/dev/null
  fi
}

# human-readable module self-check (action page only)
self_check() {
  echo "== 模块自检 =="
  if is_daemon_running; then
    echo "守护进程: 运行中 (PID $(cat "$DAEMON_PID_FILE"))"
  else
    echo "守护进程: 未运行"
  fi
  if is_charging; then echo "充电状态: 充电中"; else echo "充电状态: 未充电"; fi
  cap=$(get_battery_capacity)
  [ -n "$cap" ] && echo "电量: ${cap}%"
  t=$(get_battery_temp_tenths)
  [ -n "$t" ] && echo "温度: $((t / 10)).$((t % 10))℃"
  node=$(pick_charger_node)
  if [ -n "$node" ]; then
    echo "电流节点: $node"
    echo "节点当前值: $(cat "$node" 2>/dev/null)"
  else
    echo "电流节点: 未找到可写节点"
  fi
  actual=$(get_battery_current_now)
  [ -n "$actual" ] && echo "实际电流: $((actual / 1000))mA"
  maxc=$(get_uevent_current_max)
  [ -n "$maxc" ] && echo "系统电流上限: $((maxc / 1000))mA"
  m=$(read_manual_current)
  if [ -n "$m" ]; then echo "手动电流: ${m}mA"; else echo "手动电流: 自动档"; fi
  dev=$(getprop ro.product.device 2>/dev/null)
  model=$(getprop ro.product.model 2>/dev/null)
  echo "机型: $dev ($model)"
}

case "$1" in
  set)
    ma="$2"
    case "$ma" in
      ""|*[!0-9]*) echo "usage: $0 set <ma>"; exit 1 ;;
    esac
    if set_manual_current "$ma"; then
      echo "manual current set: $(clamp_manual_ma "$ma")mA"
    else
      echo "!! manual current saved but node write failed (see log: $LOG_FILE)"
    fi
    status_lines
    ;;
  auto)
    set_manual_current 0
    status_lines
    ;;
  apply)
    m=$(read_manual_current)
    if [ -n "$m" ]; then set_manual_current "$m"; else apply_fastcharge; fi
    status_lines
    ;;
  restart)
    stop_daemon
    if [ "${DAEMON_ENABLED:-true}" = "true" ]; then start_daemon; else apply_fastcharge; fi
    sleep 1
    status_lines
    ;;
  start)
    start_daemon
    status_lines
    ;;
  stop)
    stop_daemon
    echo "daemon stopped"
    ;;
  clean)
    sh "$MODDIR/scripts/cleanup.sh" -y
    ;;
  status)
    status_lines
    ;;
  *)
    # action page: restart control quietly, show self-check only
    stop_daemon
    if [ "${DAEMON_ENABLED:-true}" = "true" ]; then start_daemon; else apply_fastcharge; fi
    sleep 1
    self_check
    echo "日志: tail -f $LOG_FILE"
    echo "配置: $CONFIG_PATH"
    ;;
esac

exit 0
