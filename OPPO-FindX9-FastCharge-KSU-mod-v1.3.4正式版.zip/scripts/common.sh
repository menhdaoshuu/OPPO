#!/system/bin/sh
MODID=oppo_findx9_fastcharge
USER_CONFIG_DIR=/data/adb/$MODID
DEFAULT_CONFIG=$MODROOT/config/fastcharge.conf
LOG_DIR=$MODROOT/logs
LOG_FILE=$LOG_DIR/fastcharge.log
STATUS_FILE=$LOG_DIR/status.txt
DAEMON_PID_FILE=$LOG_DIR/daemon.pid
DERATE_STATE=$LOG_DIR/derate.state
mkdir -p "$LOG_DIR" 2>/dev/null
log() {
  echo "[$(date '+%F %T')] $*" >> "$LOG_FILE"
}
load_config() {
  CONFIG_PATH="$1"
  if [ ! -f "$CONFIG_PATH" ]; then
    mkdir -p "$USER_CONFIG_DIR" 2>/dev/null
    cp -f "$DEFAULT_CONFIG" "$CONFIG_PATH" 2>/dev/null
    log "配置不存在，已从模板重建: $CONFIG_PATH"
  fi
  if [ -f "$CONFIG_PATH" ]; then
    . "$CONFIG_PATH"
  else
    log "警告: 配置加载失败，使用默认值"
  fi
  log "已加载配置: $CONFIG_PATH"
}
device_check() {
  if [ "${ENABLE_DEVICE_CHECK:-true}" = "false" ]; then
    log "机型校验已关闭 (ENABLE_DEVICE_CHECK=false)"
    return 0
  fi
  if [ -z "$DEVICE_CODENAMES" ]; then
    log "DEVICE_CODENAMES 为空，跳过机型校验"
    return 0
  fi
  dev=$(getprop ro.product.device 2>/dev/null)
  model=$(getprop ro.product.model 2>/dev/null)
  for c in $DEVICE_CODENAMES; do
    if [ "$c" = "$dev" ] || [ "$c" = "$model" ]; then
      log "机型匹配: $c (device=$dev model=$model)"
      return 0
    fi
  done
  log "机型不匹配，不应用充电设置 (device=$dev model=$model, 期望: $DEVICE_CODENAMES)"
  return 1
}
write_node() {
  node="$1"
  value="$2"
  [ -n "$node" ] || return 1
  if [ -w "$node" ]; then
    if echo "$value" > "$node" 2>/dev/null; then
      log "OK   $node = $value"
      return 0
    else
      log "FAIL $node = $value (写入失败)"
    fi
  else
    log "SKIP $node (不存在或无写权限)"
  fi
  return 1
}
is_charging() {
  for status in /sys/class/power_supply/*/status; do
    [ -r "$status" ] || continue
    st=$(cat "$status" 2>/dev/null)
    case "$st" in
      Charging|Full) return 0 ;;
    esac
  done
  return 1
}
get_battery_capacity() {
  node=${CAPACITY_NODE:-/sys/class/power_supply/battery/capacity}
  if [ -r "$node" ]; then
    cat "$node" 2>/dev/null
  else
    log "容量节点不可读: $node"
    echo ""
  fi
}
get_battery_temp_tenths() {
  node=${TEMP_NODE:-/sys/class/power_supply/battery/temp}
  if [ -r "$node" ]; then
    t=$(cat "$node" 2>/dev/null)
    case "$t" in
      ""|*[!0-9]*)
        log "温度值无效: '$t'"
        echo ""
        return 1
        ;;
    esac
    echo "$t"
  else
    log "温度节点不可读: $node"
    echo ""
    return 1
  fi
}
get_battery_current_now() {
  # Scene-compatible uevent parsing. NOTE on this device/battery stack:
  # CURRENT_NOW / INPUT_CURRENT_NOW are reported in mA with NEGATIVE = charging.
  # real uA = value x -1000 (charging -> positive result).
  for ue in /sys/class/power_supply/battery/uevent /sys/class/power_supply/bms/uevent; do
    [ -r "$ue" ] || continue
    v=$(grep -m1 '^POWER_SUPPLY_CURRENT_NOW=' "$ue" 2>/dev/null | cut -d= -f2)
    case "$v" in
      ""|*[!0-9-]*) continue ;;
    esac
    abs=${v#-}
    [ "$abs" -lt 10 ] && continue
    echo $((v * -1000))
    return 0
  done
  if [ -r /sys/class/power_supply/usb/uevent ]; then
    v=$(grep -m1 '^POWER_SUPPLY_INPUT_CURRENT_NOW=' /sys/class/power_supply/usb/uevent 2>/dev/null | cut -d= -f2)
    case "$v" in
      ""|*[!0-9-]*) ;;
      *)
        abs=${v#-}
        [ "$abs" -ge 10 ] && { echo $((v * -1000)); return 0; }
        ;;
    esac
  fi
  # fallback: node chain ("path:multiplier:unit")
  for n in $CURRENT_NOW_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    node=${n%%:*}
    rest=${n#*:}
    mul=${rest%%:*}
    unit=${rest#*:}
    [ "$node" = "$n" ] && mul=1
    [ "$rest" = "$mul" ] && unit="ua"
    case "$mul" in
      ""|0|*[!0-9]*) mul=1 ;;
    esac
    case "$unit" in
      ""|ua) unit="ua" ;;
    esac
    [ -r "$node" ] || continue
    v=$(cat "$node" 2>/dev/null | tr -d ' \n\r')
    case "$v" in
      ""|*[!0-9-]*) continue ;;
    esac
    abs=${v#-}
    [ "$abs" -lt 10 ] && continue
    if [ "$unit" = "ma" ]; then
      res=$((v * mul * 1000))
    else
      res=$((v * mul))
    fi
    rabs=${res#-}
    [ "$rabs" -lt 1000 ] && continue
    echo "$res"
    return 0
  done
  return 1
}

# real-time charging power in W (battery voltage x current / 1e12)
get_battery_power_w() {
  v=$(cat /sys/class/power_supply/battery/voltage_now 2>/dev/null | tr -d ' \n')
  i=$(get_battery_current_now)
  case "$v" in ""|*[!0-9-]*) return 1 ;; esac
  case "$i" in ""|*[!0-9-]*) return 1 ;; esac
  i=${i#-}
  [ "$i" -lt 1000 ] && return 1
  # OPPO node family reports voltage_now in mV (e.g. 3979) -> convert to uV
  [ "$v" -lt 100000 ] && v=$((v * 1000))
  awk -v v="$v" -v i="$i" 'BEGIN { printf "%.1f", v * i / 1e12 }'
}
get_uevent_current_max() {
  for u in /sys/class/power_supply/battery/uevent /sys/class/power_supply/bms/uevent; do
    [ -r "$u" ] || continue
    v=$(grep -m1 'POWER_SUPPLY_CURRENT_MAX=' "$u" 2>/dev/null | cut -d= -f2)
    if [ -n "$v" ]; then
      echo "$v"
      return 0
    fi
  done
  return 1
}
current_for_capacity() {
  cap="$1"
  case "$cap" in
    ""|*[!0-9]*)
      log "电量值无效: '$cap'"
      return 1
      ;;
  esac
  low=${CAP_LOW:-10}
  high=${CAP_HIGH:-70}
  if   [ "$cap" -lt "$low" ]; then v=${CURRENT_LOW_MA:-5000}
  elif [ "$cap" -le "$high" ]; then v=${CURRENT_MID_MA:-8000}
  else v=${CURRENT_HIGH_MA:-3000}; fi
  case "$v" in
    ""|*[!0-9]*) ;;
    *)
      case "$GLOBAL_MAX_MA" in
        ""|*[!0-9]*) ;;
        *) [ "$v" -gt "$GLOBAL_MAX_MA" ] && v=$GLOBAL_MAX_MA ;;
      esac
      ;;
  esac
  echo "$v"
}
pick_charger_node() {
  if [ -n "$CURRENT_NODE" ] && [ -w "$CURRENT_NODE" ]; then
    echo "$CURRENT_NODE"
    return 0
  fi
  for n in $CHARGER_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ -w "$n" ]; then
      echo "$n"
      return 0
    fi
  done
  log "未找到可写的充电电流节点"
  return 1
}
derate_current() {
  ma="$1"
  if [ "${TEMP_DERATE_ENABLE:-true}" != "true" ]; then
    echo "$ma"
    return 0
  fi
  t=$(get_battery_temp_tenths)
  [ -z "$t" ] && { echo "$ma"; return 0; }
  critical_t=${TEMP_CRITICAL_TENTHS:-450}
  critical_exit=${TEMP_CRITICAL_EXIT_TENTHS:-440}
  critical_ma=${TEMP_CRITICAL_MA:-0}
  hard_t=${TEMP_HARD_CAP_TENTHS:-420}
  hard_exit=${TEMP_HARD_CAP_EXIT_TENTHS:-415}
  hard_ma=${TEMP_HARD_CAP_MA:-2000}
  l1=${TEMP_L1_TENTHS:-416}
  l2=${TEMP_L2_TENTHS:-438}
  l3=${TEMP_L3_TENTHS:-445}
  exit_l=${TEMP_LIMIT_EXIT_TENTHS:-406}
  min_ma=${TEMP_MIN_MA:-2000}
  max_ma=${TEMP_MAX_MA:-15000}
  state=""
  [ -f "$DERATE_STATE" ] && state=$(cat "$DERATE_STATE" 2>/dev/null)
  if [ "$t" -gt "$critical_t" ] || { [ "$state" = "critical" ] && [ "$t" -gt "$critical_exit" ]; }; then
    if [ "$state" != "critical" ]; then
      log "进入 45℃ 临界保护: 电流 ${critical_ma}mA (充电保持连接, 放电速度为正)"
    fi
    echo "critical" > "$DERATE_STATE" 2>/dev/null
    echo "$critical_ma"
    return 0
  fi
  if [ "$t" -gt "$hard_t" ] || { [ "$state" = "hard" ] && [ "$t" -gt "$hard_exit" ]; }; then
    val=$(awk -v ma="$ma" -v t="$t" -v l1="$l1" -v l2="$l2" -v l3="$l3" \
          -v min_ma="$min_ma" -v max_ma="$max_ma" 'BEGIN {
      if (ma > max_ma) ma = max_ma;
      if (t > l3) t = l3;
      v = ma * exp((t - l1) / 10.0 * log(0.94));
      if (t > l2) v = v * exp((t - l2) / 10.0 * log(0.85));
      if (v < min_ma) v = min_ma;
      printf "%d", v + 0.5
    }')
    if [ "$val" -gt "$hard_ma" ]; then
      val=$hard_ma
    fi
    if [ "$state" != "hard" ]; then
      log "进入 42℃ 硬顶保护: 最大电流 ${val}mA"
    fi
    echo "hard" > "$DERATE_STATE" 2>/dev/null
    echo "$val"
    return 0
  fi
  limited=""
  [ "$state" = "scene" ] && limited=1
  if [ "$t" -gt "$l1" ] || { [ "$limited" = "1" ] && [ "$t" -gt "$exit_l" ]; }; then
    val=$(awk -v ma="$ma" -v t="$t" -v l1="$l1" -v l2="$l2" -v l3="$l3" \
          -v min_ma="$min_ma" -v max_ma="$max_ma" 'BEGIN {
      if (ma > max_ma) ma = max_ma;
      if (t > l3) t = l3;
      v = ma * exp((t - l1) / 10.0 * log(0.94));
      if (t > l2) v = v * exp((t - l2) / 10.0 * log(0.85));
      if (v < min_ma) v = min_ma;
      printf "%d", v + 0.5
    }')
    echo "scene" > "$DERATE_STATE" 2>/dev/null
    echo "$val"
  else
    rm -f "$DERATE_STATE" 2>/dev/null
    echo "$ma"
  fi
}
try_write() {
  node="$1"
  value="$2"
  err=$( { echo "$value" > "$node"; } 2>&1 )
  if [ -z "$err" ]; then
    return 0
  fi
  echo "$err"
  return 1
}
write_input_current_ma() {
  ma="$1"
  if [ "${WRITE_UNIT:-ua}" = "ma" ]; then
    value=$ma
  else
    value=$((ma * 1000))
  fi
  for n in $INPUT_CURRENT_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ -w "$n" ]; then
      err=$(try_write "$n" "$value")
      if [ -z "$err" ]; then
        rb=$(cat "$n" 2>/dev/null)
        log "OK   输入限流 ${ma}mA (${value}ua) -> $n (读回: $rb)"
      else
        chmod 0666 "$n" 2>/dev/null
        err=$(try_write "$n" "$value")
        if [ -z "$err" ]; then
          rb=$(cat "$n" 2>/dev/null)
          log "OK   输入限流 ${ma}mA (${value}ua) -> $n (chmod 后成功, 读回: $rb)"
        else
          log "SKIP 输入限流 $n ($err)"
        fi
      fi
    else
      log "SKIP 输入限流 $n (不存在或无写权限)"
    fi
  done
}
write_votable_ma() {
  ma="$1"
  [ "${VOOTABLE_ENABLE:-true}" = "true" ] || return 0
  div=${VOOTABLE_DIVIDER:-1}
  case "$div" in
    ""|0|*[!0-9]*) div=1 ;;
  esac
  if [ "$div" -gt 1 ]; then
    ma=$((ma / div))
    [ "$ma" -lt 1 ] && ma=1
  fi
  for v in $VOOTABLE_NODES; do
    case "$v" in
      ""|\#*) continue ;;
    esac
    if [ -w "$v/force_val" ]; then
      if echo "$ma" > "$v/force_val" 2>/dev/null; then
        echo 1 > "$v/force_active" 2>/dev/null
        eff=$(cat "$v/status" 2>/dev/null | grep -o 'effective=[^ ]* type=[^ ]* v=[0-9]*' | head -1)
        log "OK   votable $v = ${ma}mA ($eff)"
      else
        log "FAIL votable $v = ${ma}mA (写入失败)"
      fi
    else
      log "SKIP votable $v (不存在或无写权限)"
    fi
  done
}
check_overspeed() {
  [ "${SAFETY_OVERRIDE_ENABLE:-true}" = "true" ] || return 0
  now=$(get_battery_current_now)
  case "$now" in
    ""|*[!0-9-]*) return 0 ;;
  esac
  abs=${now#-}
  limit_ma=${SAFETY_MAX_MA:-8000}
  case "$limit_ma" in
    ""|*[!0-9]*) return 0 ;;
  esac
  limit_ua=$((limit_ma * 1000))
  if [ "$abs" -gt "$limit_ua" ]; then
    fallback=${SAFETY_FALLBACK_MA:-2000}
    log "!! 过流保护触发: 实测 ${abs}µA ($((abs / 1000))mA) > 上限 ${limit_ma}mA，强制压到 ${fallback}mA"
    write_votable_ma "$fallback"
    echo "OVERRIDE" > "$DERATE_STATE" 2>/dev/null
    return 1
  fi
  return 0
}
write_voltage_cap() {
  [ "${VOLTAGE_CAP_ENABLE:-true}" = "true" ] || return 0
  for n in $VOLTAGE_CAP_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ -w "$n" ]; then
      if echo "$VOLTAGE_CAP_UV" > "$n" 2>/dev/null; then
        log "OK   电压上限 ${VOLTAGE_CAP_UV}µV ($((VOLTAGE_CAP_UV / 1000000))V) -> $n"
      else
        log "FAIL 电压上限写入失败 -> $n"
      fi
    else
      log "SKIP 电压上限节点不可写 -> $n"
    fi
  done
}
check_votable_ma() {
  ma="$1"
  [ "${VOOTABLE_ENABLE:-true}" = "true" ] || return 0
  div=${VOOTABLE_DIVIDER:-1}
  case "$div" in
    ""|0|*[!0-9]*) div=1 ;;
  esac
  if [ "$div" -gt 1 ]; then
    ma=$((ma / div))
    [ "$ma" -lt 1 ] && ma=1
  fi
  for v in $VOOTABLE_NODES; do
    case "$v" in
      ""|\#*) continue ;;
    esac
    [ -r "$v/force_val" ] || continue
    cur=$(cat "$v/force_val" 2>/dev/null)
    if [ "$cur" != "$ma" ]; then
      log "votable 值被改动 ($cur != $ma)，补写 $v"
      write_votable_ma "$ma"
      return 0
    fi
  done
}
apply_derated() {
  ma="$1"
  cap="$2"
  if [ "${SYSFS_WRITE_ENABLE:-false}" = "true" ]; then
    write_current_ma "$ma" "$cap"
    rc=$?
  else
    rc=0
  fi
  write_votable_ma "$ma"
  return $rc
}
write_current_ma() {
  ma="$1"
  cap="$2"
  if [ "${WRITE_UNIT:-ua}" = "ma" ]; then
    value=$ma
    unit="ma"
  else
    value=$((ma * 1000))
    unit="ua"
  fi
  if [ -n "$CURRENT_NODE" ]; then
    err=$(try_write "$CURRENT_NODE" "$value")
    if [ -z "$err" ]; then
      rb=$(cat "$CURRENT_NODE" 2>/dev/null)
      if [ -n "$rb" ] && [ "$rb" != "$value" ]; then
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $CURRENT_NODE (读回: $rb) !! 读回≠写入，可能被内核钳制"
      else
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $CURRENT_NODE (读回: $rb)"
      fi
      write_input_current_ma "$ma"
      return 0
    fi
    chmod 0666 "$CURRENT_NODE" 2>/dev/null
    err=$(try_write "$CURRENT_NODE" "$value")
    if [ -z "$err" ]; then
      log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $CURRENT_NODE (chmod 后成功)"
      write_input_current_ma "$ma"
      return 0
    fi
    log "FAIL 电流 ${ma}mA -> $CURRENT_NODE ($err)"
    return 1
  fi
  for n in $CHARGER_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    err=$(try_write "$n" "$value")
    if [ -z "$err" ]; then
      rb=$(cat "$n" 2>/dev/null)
      if [ -n "$rb" ] && [ "$rb" != "$value" ]; then
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $n (读回: $rb) !! 读回≠写入，可能被内核钳制"
      else
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $n (读回: $rb)"
      fi
      write_input_current_ma "$ma"
      return 0
    fi
    chmod 0666 "$n" 2>/dev/null
    err=$(try_write "$n" "$value")
    if [ -z "$err" ]; then
      log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $n (chmod 后成功)"
      write_input_current_ma "$ma"
      return 0
    fi
    log "SKIP $n ($err)"
  done
  log "FAIL 电流 ${ma}mA 所有节点均写入失败"
  return 1
}
probe_nodes() {
  log "==== 自动节点探测开始（真实充电状态）===="
  baseline=$(get_battery_current_now)
  log "PROBE 充电基线 current_now=$baseline"
  for n in $PROBE_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ ! -e "$n" ]; then
      log "PROBE $n 不存在"
      continue
    fi
    pre=$(cat "$n" 2>/dev/null)
    log "PROBE $n 原始值: $pre"
    for tv in 3000 3000000; do
      err=$(try_write "$n" "$tv")
      sleep 2
      rb=$(cat "$n" 2>/dev/null)
      now=$(get_battery_current_now)
      log "PROBE $n 写$tv -> 错误:[$err] 读回:[$rb] current_now:[$now]"
    done
  done
  log "==== 自动节点探测结束 ===="
}
is_screen_on() {
  if command -v dumpsys >/dev/null 2>&1; then
    wake=$(dumpsys power 2>/dev/null | grep -m1 'mWakefulness=')
    case "$wake" in
      *Awake*) return 0 ;;
    esac
    disp=$(dumpsys display 2>/dev/null | grep -m1 'mScreenState=')
    case "$disp" in
      *ON*) return 0 ;;
    esac
    disp2=$(dumpsys display 2>/dev/null | grep -m1 'Display Power: state=ON')
    [ -n "$disp2" ] && return 0
  fi
  for b in /sys/class/backlight/*/brightness; do
    [ -r "$b" ] || continue
    val=$(cat "$b" 2>/dev/null)
    case "$val" in
      ""|0) continue ;;
      *[!0-9]*) continue ;;
    esac
    return 0
  done
  return 1
}
is_daemon_running() {
  [ -f "$DAEMON_PID_FILE" ] || return 1
  pid=$(cat "$DAEMON_PID_FILE" 2>/dev/null)
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}
start_daemon() {
  if is_daemon_running; then
    log "守护进程已在运行 (PID $(cat "$DAEMON_PID_FILE"))"
    return 0
  fi
  if command -v nohup >/dev/null 2>&1; then
    nohup sh "$MODROOT/scripts/fastcharge_daemon.sh" "$MODROOT" >> "$LOG_FILE" 2>&1 &
  else
    sh "$MODROOT/scripts/fastcharge_daemon.sh" "$MODROOT" >> "$LOG_FILE" 2>&1 &
  fi
  log "守护进程启动中 (PID $!)"
  echo "$!" > "$DAEMON_PID_FILE" 2>/dev/null
}
stop_daemon() {
  if [ -f "$DAEMON_PID_FILE" ]; then
    pid=$(cat "$DAEMON_PID_FILE" 2>/dev/null)
    [ -n "$pid" ] && kill "$pid" 2>/dev/null
    rm -f "$DAEMON_PID_FILE"
    log "已停止守护进程 (PID $pid)"
  fi
}
apply_fastcharge() {
  log "==== 开始应用充电设置 ===="
  device_check || return 1
  if [ -n "$CHARGE_RULES" ]; then
    printf '%s\n' "$CHARGE_RULES" | while IFS= read -r rule; do
      rule=$(echo "$rule" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')
      [ -z "$rule" ] && continue
      case "$rule" in
        \#*) continue ;;
        *=*)
          node=${rule%%=*}
          value=${rule#*=}
          write_node "$node" "$value"
          ;;
        *)
          log "规则格式无效，跳过: $rule"
          ;;
      esac
    done
  fi
  if [ -n "$EXTRA_COMMANDS" ]; then
    printf '%s\n' "$EXTRA_COMMANDS" | while IFS= read -r cmd; do
      case "$cmd" in
        ""|\#*) continue ;;
      esac
      log "执行附加命令: $cmd"
      sh -c "$cmd" >> "$LOG_FILE" 2>&1
    done
  fi
  cap=$(get_battery_capacity)
  base=$(current_for_capacity "$cap")
  result="SKIP: 电量不可用"
  derated=""
  if [ -n "$base" ]; then
    derated=$(derate_current "$base")
    if write_current_ma "$derated" "$cap"; then
      result="OK ${derated}mA (目标 ${base}mA)"
    else
      result="FAIL ${derated}mA (所有节点写入失败)"
    fi
  fi
  actual=$(get_battery_current_now)
  {
    echo "last_apply=$(date '+%F %T')"
    echo "result=$result"
    echo "capacity=${cap}%"
    echo "target_current=${base}mA"
    echo "applied_current=${derated:-none}mA"
    echo "actual_current=${actual:-n/a}µA"
    echo "device=$(getprop ro.product.device 2>/dev/null) model=$(getprop ro.product.model 2>/dev/null)"
    echo "config=$CONFIG_PATH"
  } > "$STATUS_FILE" 2>/dev/null
  log "==== 应用完成 ===="
}
MANUAL_CURRENT_FILE=$USER_CONFIG_DIR/current_ma
MANUAL_STATE_FILE=$USER_CONFIG_DIR/current_state.txt
read_manual_current() {
  [ -f "$MANUAL_CURRENT_FILE" ] || return 1
  v=$(tr -d ' \t\r' < "$MANUAL_CURRENT_FILE" 2>/dev/null)
  case "$v" in
    ""|*[!0-9]*)
      log "手动电流文件内容无效: '$v'（回退自动档）"
      rm -f "$MANUAL_CURRENT_FILE" 2>/dev/null
      return 1
      ;;
  esac
  echo "$v"
  return 0
}
clamp_manual_ma() {
  ma="$1"
  case "$ma" in
    ""|*[!0-9]*) echo ""; return 1 ;;
  esac
  min=${MANUAL_MIN_MA:-1000}
  max=${MANUAL_MAX_MA:-8800}
  gm=${GLOBAL_MAX_MA:-0}
  case "$gm" in
    ""|*[!0-9]*) gm=0 ;;
  esac
  if [ "$gm" -gt 0 ] && [ "$max" -gt "$gm" ]; then max=$gm; fi
  [ "$ma" -lt "$min" ] && ma=$min
  [ "$ma" -gt "$max" ] && ma=$max
  echo "$ma"
}
apply_current_ma_direct() {
  ma="$1"
  [ -n "$ma" ] || return 1
  cap=$(get_battery_capacity)
  derated=$(derate_current "$ma")
  [ -z "$derated" ] && derated=$ma
  if apply_derated "$derated" "$cap"; then
    echo "OK"
  else
    echo "FAIL"
  fi
}
set_manual_current() {
  ma="$1"
  if [ -z "$ma" ] || [ "$ma" -le 0 ]; then
    rm -f "$MANUAL_CURRENT_FILE" 2>/dev/null
    log "恢复自动档位电流（按电量分档）"
    mode="auto"
    mc="auto"
    result=$(apply_current_ma_direct "$(current_for_capacity "$(get_battery_capacity)")")
  else
    clamped=$(clamp_manual_ma "$ma") || { log "手动电流值无效: '$ma'"; return 1; }
    ma=$clamped
    log "设置手动电流: ${ma}mA"
    echo "$ma" > "$MANUAL_CURRENT_FILE" 2>/dev/null
    mode="manual"
    mc="${ma}mA"
    result=$(apply_current_ma_direct "$ma")
  fi
  cap=$(get_battery_capacity)
  {
    echo "mode=$mode"
    echo "manual_current=$mc"
    echo "capacity=${cap}%"
    echo "apply_result=${result:-n/a}"
    echo "last_set=$(date '+%F %T')"
  } > "$MANUAL_STATE_FILE" 2>/dev/null
  [ "$result" = "OK" ]
}
