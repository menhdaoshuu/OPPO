#!/system/bin/sh
MODROOT="$1"
[ -n "$MODROOT" ] || { echo "用法: sh apply_fastcharge.sh <MODROOT> [CONFIG_PATH]"; exit 1; }
export MODROOT
. "$MODROOT/scripts/common.sh"
CONFIG_PATH="${2:-$USER_CONFIG_DIR/fastcharge.conf}"
load_config "$CONFIG_PATH"
apply_fastcharge
echo "完成。查看状态: cat $STATUS_FILE"
echo "查看日志: tail -f $LOG_FILE"
exit 0
