#!/system/bin/sh
MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"
CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"
i=0
until [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ] || [ "$i" -ge 120 ]; do
  sleep 2
  i=$((i + 2))
done
log "系统启动完成 (sys.boot_completed=1)"
if [ "${START_ON_SCREEN_ON:-true}" = "true" ]; then
  log "等待屏幕亮起 (最多 60s)..."
  waited=0
  while ! is_screen_on; do
    sleep 2
    waited=$((waited + 2))
    if [ "$waited" -ge 60 ]; then
      log "等待屏幕亮起超时(60s)，直接启动快充控制"
      break
    fi
  done
  delay=${SCREEN_ON_DELAY_SEC:-15}
  log "屏幕已亮起，${delay}s 后启动快充控制"
  sleep "$delay"
fi
if [ "${DAEMON_ENABLED:-true}" = "true" ]; then
  start_daemon
else
  apply_fastcharge
fi
exit 0
