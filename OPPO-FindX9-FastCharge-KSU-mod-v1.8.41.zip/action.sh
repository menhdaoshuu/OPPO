#!/system/bin/sh
# actions: (no arg = self-check) set <ma> | auto | apply | restart | start | stop | clean | status

MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"

CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

# key=value status (for WebUI)
# ============================================================
# 散热器档位(执行页面可用音量键即时切换)
# ============================================================
MODES_FILE=${MODES_FILE:-/data/adb/oppo_findx9_fastcharge/modes.conf}

set_cooler() {
  _c="$1"
  case "$_c" in
    on|1|cooler|有|是)
      _v=1; _g=6900; _d=8000; _f=11000; _txt="已搭配散热器（高性能档）"
      ;;
    off|0|none|无|否)
      _v=0; _g=3000; _d=6000; _f=8100; _txt="未搭配散热器（安全档）"
      ;;
    *) echo "用法: $0 cooler on|off"; return 1 ;;
  esac
  mkdir -p "$(dirname "$MODES_FILE")" 2>/dev/null
  {
    echo "# 三档电流配置: 1=已搭配散热器 0=未搭配"
    echo "COOLER=$_v"
    echo "GAME=$_g"
    echo "DAILY=$_d"
    echo "FAST=$_f"
  } > "$MODES_FILE"
  echo "已切换档位: $_txt"
  echo "  游戏 ${_g}mA / 日常 ${_d}mA / 速充 ${_f}mA"
  log "散热器档位切换: COOLER=$_v (游戏${_g}/日常${_d}/速充${_f})"
}

cooler_show() {
  _c=$(grep -m1 '^COOLER=' "$MODES_FILE" 2>/dev/null | cut -d= -f2)
  case "$_c" in
    1) echo "散热器档位: 已搭配散热器（高性能档）"; echo "  游戏 $(read_mode_ma game)mA / 日常 $(read_mode_ma daily)mA / 速充 $(read_mode_ma fast)mA" ;;
    0) echo "散热器档位: 未搭配散热器（安全档）"; echo "  游戏 $(read_mode_ma game)mA / 日常 $(read_mode_ma daily)mA / 速充 $(read_mode_ma fast)mA" ;;
    *) echo "散热器档位: 未设置（默认安全档）" ;;
  esac
}

cooler_prompt() {
  if ! getevent -lp 2>/dev/null | grep -q 'KEY_VOLUMEUP'; then
    return 0
  fi
  echo ""
  echo "--------------------------------------------"
  echo "  10 秒内按音量键切换档位："
  echo "    [音量-] 已搭配散热器  游戏6900/日常8000/速充11000"
  echo "    [音量+] 未搭配散热器  游戏3000/日常6000/速充8100"
  echo "    不按键 = 保持当前档位"
  echo "--------------------------------------------"
  ev=$(timeout 10 getevent -lc 1 2>/dev/null)
  case "$ev" in
    *KEY_VOLUMEDOWN*) set_cooler on ;;
    *KEY_VOLUMEUP*)   set_cooler off ;;
    *) echo "（未按键，保持当前档位）" ;;
  esac
}

status_lines() {
  m=$(read_manual_current)
  if [ -n "$m" ]; then
    mode="manual"; mc="${m}mA"
  else
    mode="auto"; mc="auto"
  fi
  cap=$(get_battery_capacity)
  t=$(get_battery_temp_tenths)
  now=$(get_battery_current_now)
  if is_charging; then st="charging"; else st="idle"; fi
  base="$m"
  [ -z "$base" ] && base=$(current_for_capacity "$cap")
  [ -z "$base" ] && base="n/a"

  echo "mode=$mode"
  echo "manual_current=$mc"
  echo "charging=$st"
  echo "capacity=${cap:-n/a}"
  if [ -n "$t" ]; then echo "temp=$((t / 10)).$((t % 10))"; else echo "temp=n/a"; fi
  echo "current_now=${now:-n/a}"
  # 与流体云芯片完全同一个数值: 直接读载体App私有文件(模块每3秒写入的那份)
_spw=$(cat /data/data/com.fcpower/files/power 2>/dev/null | tr -d ' \n\r')
case "$_spw" in
  ""|*[!0-9.-]*) _spw=$(get_battery_power_w_signed 2>/dev/null) ;;
esac
[ -n "$_spw" ] || _spw=$(get_battery_power_w 2>/dev/null)
echo "power=$_spw"
  echo "target_current=${base}mA"
echo "cur_mode=$(cat "$LOG_DIR/current_mode" 2>/dev/null)"
echo "mode_game=$(read_mode_ma game)"
echo "mode_daily=$(read_mode_ma daily)"
echo "mode_fast=$(read_mode_ma fast)"
  if [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ]; then echo "fluid=on"; else echo "fluid=off"; fi

  if [ -f "$STATUS_FILE" ]; then
    grep -E '^(applied_current|result|node|daemon_pid|last_apply)=' "$STATUS_FILE" 2>/dev/null
  fi
}

# human-readable module self-check (action page only)
self_check() {
  echo "== 模块自检 =="
  if is_daemon_running; then
    echo "守护进程: 运行中 (PID $(cat "$DAEMON_PID_FILE"))"
  else
    echo "守护进程: 未运行"
  fi
  if is_charging; then echo "充电状态: 充电中"; else echo "充电状态: 未充电"; fi
  cap=$(get_battery_capacity)
  [ -n "$cap" ] && echo "电量: ${cap}%"
  t=$(get_battery_temp_tenths)
  [ -n "$t" ] && echo "温度: $((t / 10)).$((t % 10))℃"
  node=$(pick_charger_node)
  if [ -n "$node" ]; then
    echo "电流节点: $node"
    echo "节点当前值: $(cat "$node" 2>/dev/null)"
  else
    echo "电流节点: 未找到可写节点"
  fi
  actual=$(get_battery_current_now)
  [ -n "$actual" ] && echo "实际电流: $((actual / 1000))mA"
  maxc=$(get_uevent_current_max)
  [ -n "$maxc" ] && echo "系统电流上限: $((maxc / 1000))mA"
  m=$(read_manual_current)
  if [ -n "$m" ]; then echo "手动电流: ${m}mA"; else echo "手动电流: 自动档"; fi
  dev=$(getprop ro.product.device 2>/dev/null)
  model=$(getprop ro.product.model 2>/dev/null)
  echo "机型: $dev ($model)"
}

case "$1" in
  set)
    ma="$2"
    case "$ma" in
      ""|*[!0-9]*) echo "usage: $0 set <ma>"; exit 1 ;;
    esac
    if set_manual_current "$ma"; then
      echo "manual current set: $(clamp_manual_ma "$ma")mA"
    else
      echo "!! manual current saved but node write failed (see log: $LOG_FILE)"
    fi
    status_lines
    ;;
  auto)
    set_manual_current 0
    status_lines
    ;;
  apply)
    m=$(read_manual_current)
    if [ -n "$m" ]; then set_manual_current "$m"; else apply_fastcharge; fi
    status_lines
    ;;
  restart)
    stop_daemon
    if [ "${DAEMON_ENABLED:-true}" = "true" ]; then start_daemon; else apply_fastcharge; fi
    sleep 1
    status_lines
    ;;
  start)
    start_daemon
    status_lines
    ;;
  stop)
    stop_daemon
    echo "daemon stopped"
    ;;
  clean)
    sh "$MODDIR/scripts/cleanup.sh" -y
    ;;
  fluid)
    case "$2" in
      on|off)
        if [ "$2" = "on" ]; then v="true"; else v="false"; fi
        # 注意: sed -i 在"无匹配"时返回码同样是 0, 不能用 if sed 判断成败。
        # 改为: 先确认配置里存在该键 -> sed 写入 -> 回读比对确认。
        if ! grep -q '^FLUID_CLOUD_ENABLE=' "$CONFIG_PATH" 2>/dev/null; then
          # 配置里没有这一行(老版本配置迁移不全), 直接追加
          echo "FLUID_CLOUD_ENABLE=${v}" >> "$CONFIG_PATH" 2>/dev/null
        else
          sed -i "s/^FLUID_CLOUD_ENABLE=.*/FLUID_CLOUD_ENABLE=${v}/" "$CONFIG_PATH" 2>/dev/null
        fi
        _now=$(grep -m1 '^FLUID_CLOUD_ENABLE=' "$CONFIG_PATH" 2>/dev/null | tr -d ' \t\r\n' | cut -d= -f2)
        if [ "$_now" = "$v" ]; then
          FLUID_CLOUD_ENABLE="$v"
          if [ "$v" = "true" ]; then
            # 开启: 确保载体 App 存在并拉起前台服务
            ensure_fluid_app
            # 续期保活白名单: 关闭期间 fluid_tick 不跑, no_frozen 等会逐渐失效, 这里补一次
            fluid_protect_app
            # 拉起载体服务, 让通知/流体云立刻出现。
            # 这是用户主动开启流体云时的一次性启动，不作为后台保活机制。
            # 后续生命周期交由 ColorOS 17 与前台服务自身管理。
            # v1.8.10: 带 unfreeze 标记 —— 这是"开启流体云"的副作用式拉起,
            # 不是用户点击 App 图标, 不应弹 ControlActivity 界面。
            am start -n com.fcpower/.MainActivity --ez unfreeze true >/dev/null 2>&1
            sleep 1
            # v1.8.8: 不再传 `--es pw "待机"`(非数字会被 App 原样上屏)。
            # 有真实功率就推真实功率, 否则不带 pw 让 App 自己读文件。
            fluid_push_power_now || am start-foreground-service -n com.fcpower/.PowerService >/dev/null 2>&1
            echo "流体云实时功率: 已开启（立即生效）"
          else
            # 关闭流体云。三个动作都不依赖"广播能否及时送达"——
            # ColorOS 会对后台应用延迟投递广播(BroadcastQueue setDeferPolicy defer:true),
            # 所以不能只靠广播。
            #
            # ① 直接落"已关闭"标记到 App 私有目录: 让 App 此后不再重发通知。
            #    (App 侧 isStopped 会读这个文件, 跨进程重启也有效)
            _uid=$(stat -c %u /data/data/com.fcpower 2>/dev/null)
            if [ -n "$_uid" ] && [ -d /data/data/com.fcpower/files ]; then
              : > /data/data/com.fcpower/files/stopped 2>/dev/null
              chown "$_uid:$_uid" /data/data/com.fcpower/files/stopped 2>/dev/null
              chmod 600 /data/data/com.fcpower/files/stopped 2>/dev/null
            fi
            # ② 停服务: 必定触发 PowerService.onDestroy, 由它撤下流体云通知(id=1)
            #    与档位条(id=3)。系统只自动撤前台服务通知(id=2)。
            am stop-service -n com.fcpower/.PowerService >/dev/null 2>&1
            # ③ 兜底广播: 若服务当时并未运行(也就没有 onDestroy), 让 App 自己再撤一次。
            am broadcast -n com.fcpower/.PowerReceiver -a com.fcpower.STOP -f 0x01000000 >/dev/null 2>&1
            echo "流体云实时功率: 已关闭（立即生效）"
          fi
          log "流体云开关(WebUI): FLUID_CLOUD_ENABLE=${v}"
        else
          echo "!! 配置写入失败（当前值: ${_now:-空}）"
        fi
        ;;
      status)
        # 直接读配置文件, 而不是用 action.sh 启动时加载的内存快照,
        # 否则 WebUI 轮询到的永远是旧值
        _cs=$(grep -m1 '^FLUID_CLOUD_ENABLE=' "$CONFIG_PATH" 2>/dev/null | tr -d ' \t\r\n' | cut -d= -f2)
        case "$_cs" in true|false) FLUID_CLOUD_ENABLE="$_cs" ;; esac
        if [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ]; then echo "流体云实时功率: 开"; else echo "流体云实时功率: 关"; fi
        ;;
      *) echo "用法: $0 fluid on|off|status" ;;
    esac
    ;;
  mode)
    apply_mode "$2" && echo "已切换模式: $2" || echo "模式切换失败"
    ;;
  cooler)
    case "$2" in
      ""|status) cooler_show ;;
      *) apply_mode "$(cat "$LOG_DIR/current_mode" 2>/dev/null || echo daily)" >/dev/null 2>&1; set_cooler "$2" ;;
    esac
    ;;
  status)
    status_lines
    ;;
  *)
    # action page: restart control quietly, show self-check only
    stop_daemon
    if [ "${DAEMON_ENABLED:-true}" = "true" ]; then start_daemon; else apply_fastcharge; fi
    sleep 1
    self_check
    echo ""
    cooler_show
    cooler_prompt
    echo "切换后当前档位："
    cooler_show
    echo ""
    echo "日志: tail -f $LOG_FILE"
    echo "配置: $CONFIG_PATH"
    ;;
esac

exit 0
