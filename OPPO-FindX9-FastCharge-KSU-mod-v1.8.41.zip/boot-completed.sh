#!/system/bin/sh
# boot-completed fallback. It is intentionally UI-independent.
MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"
CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

# 载体 App(流体云)自动安装/升级: 模块升级会带新的图标与刷新逻辑,
# 必须在开机完成后覆盖安装一次, 否则手机上仍是旧 App(小飞机图标依旧)
ensure_fluid_app

# v1.8.29: App 的界面是 WebView 加载模块 webroot/index.html —— 开机后立刻
# 同步一份, 这样用户点开 App 时不至于先看到"界面尚未就绪"的占位页。
sync_webui_to_app

# Root 级流体云维持守护：与快充 daemon 完全独立。
# v1.8.12: 统一调用 common.sh 的 start_fluid_daemon（原子锁 + PID 由 daemon 自写），
# 不再在此处 `rm pid` + `nohup` + `echo $!` —— 那套写法与 service.sh 并发时会起出两个进程。
start_fluid_daemon

if [ "${DAEMON_ENABLED:-true}" = "true" ]; then
  if ! is_daemon_running; then
    log "boot-completed 兜底：启动快充守护进程（不等待 WebUI/屏幕）"
    start_daemon
  else
    log "boot-completed 兜底：守护进程已运行"
  fi
else
  apply_fastcharge
fi
exit 0
