#!/system/bin/sh
# OPPO Find X9 FastCharge - 独立流体云 Root 守护进程
# 与快充控制 daemon 完全分离；即使快充控制循环触发保护/重启，流体云仍独立刷新。
MODROOT="$1"
[ -n "$MODROOT" ] || exit 1
export MODROOT
. "$MODROOT/scripts/common.sh"

CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"
# v1.8.12: PID 由本进程自己写真实 $$（与快充 daemon 统一策略）。
# 旧版调用方用 `echo $!` 写的是 nohup/sh 中间进程 PID，与 $$ 不同，
# 导致 watchdog 用 kill -0 判活失败 -> 误判退出 -> 再起一个 -> 双进程抢刷新。
FLUID_PID_FILE="$LOG_DIR/${FLUID_PID_FILE_NAME:-fluid_cloud.pid}"
echo $$ > "$FLUID_PID_FILE" 2>/dev/null
# v1.8.8: 清掉上一版本遗留的采样状态, 避免升级后第一轮读数受旧值影响
# (旧版有 batt_current.pend 之类的残留会让新逻辑的首轮判定出现偏差)
rm -f "$LOG_DIR/batt_current.pend" "$LOG_DIR/fluid_power.flip" 2>/dev/null
log "独立流体云 Root 守护进程已启动 (PID $$, v1.8.8 平滑+去占位文案)"

cleanup() {
  rm -f "$FLUID_PID_FILE" 2>/dev/null
  exit 0
}
trap cleanup INT TERM EXIT

while :; do
  # 每轮重新读取配置，WebUI 关闭/开启立即生效。
  if [ -f "$CONFIG_PATH" ]; then
    _fce=$(grep -m1 '^FLUID_CLOUD_ENABLE=' "$CONFIG_PATH" 2>/dev/null | tr -d ' \t\r\n' | cut -d= -f2)
    case "$_fce" in true|false) FLUID_CLOUD_ENABLE="$_fce" ;; esac
  fi

  # ★ v1.8.10: fluid_tick 必须**每轮都调用**, 不能再被 FLUID_CLOUD_ENABLE 包住。
  #   原因: fluid_tick 内部现在承担两件事 ——
  #     ① 与流体云无关的「数据落盘」(status.json / power / current_now,
  #        是载体 App 原生界面的唯一数据源);
  #     ② 与流体云有关的「发广播/刷胶囊/恢复服务」(受开关控制)。
  #   旧版把整个 fluid_tick 放在开关里, 用户一关流体云, 数据落盘就停了,
  #   App 界面直接冻结在旧值(表现为"关闭流体云后 App 不再刷新/状态不一致")。
  #   现在由 fluid_tick 自己根据开关决定做不做 ②, 但 ① 始终执行。
  fluid_tick
  # App 原生界面(ControlActivity)的请求通道:
  #   current_req / fluid_req / daemon_req 都是 App 写入私有目录的"请求文件"。
  #   放在这里消费而不是只靠 fastcharge_daemon, 是因为后者的 check_overspeed
  #   早退路径会跳过 fluid_apply_request —— 过流保护一旦触发, App 的点击就再无响应。
  #   本循环在 root 上下文、不早退, 是更可靠的消费点。
  fluid_apply_request
  # Root 级维持 + **心跳检测解冻**(v1.8.7 核心修复)：
  #   实测 ColorOS 17 会冻结后台 App；`am start-foreground-service` 在**冻结态无效**
  #   （返回 "Not found; no service started"），唯一能穿透冻结的是 **`am start`(Activity)**。
  #   App 侧已用静音音频轨(AudioTrack)+MediaSession 降低被冻结概率，并每秒写心跳 files/hb。
  #   这里用心跳判断 App 是否还活着 —— 活着就**不打扰**（避免 am start 引起胶囊闪烁），
  #   心跳停了(或进程消失)才用 MainActivity(无界面秒退)解冻一次。
  #
  #   v1.8.8 修正: 原来「App 活着」时每 5s 都补一次
  #   `am start-foreground-service ... --es pw "刷新"`，这是**双重有害**:
  #     ① "刷新" 不是数字, 会被 App 原样显示, 把通知从 "4.1 W" 覆盖成 "刷新";
  #     ② 每 5s 一次 notify(1) 会持续重建通知, 流体云胶囊反复重展开。
  #   现在: 活着时**什么都不做**(App 有 500ms 自轮询, 不需要 root 催);
  #   只有确认心跳停了才解冻, 且解冻后推送当前真实功率而不是占位文案。
  _now=$(date +%s)
  _keep=$(cat "$MODROOT/logs/fluid.root_keep" 2>/dev/null)
  case "$_keep" in ""|*[!0-9]*) _keep=0 ;; esac
  if [ $((_now - _keep)) -ge 5 ]; then
    echo "$_now" > "$MODROOT/logs/fluid.root_keep" 2>/dev/null
    fluid_protect_app
    pm enable com.fcpower >/dev/null 2>&1
    cmd package unsuspend com.fcpower >/dev/null 2>&1
    cmd appops set com.fcpower RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
    dumpsys deviceidle whitelist +com.fcpower >/dev/null 2>&1

    # ---- 心跳检测：只在确认 App 已被冻结/消失时才解冻 ----
    # ★ v1.8.10: 仅当流体云开启时才做「解冻/补服务/推功率」——
    #   用户关闭流体云后不应再强行拉起前台服务与通知(否则胶囊灭不掉)。
    _need_unfreeze=""
    _hb=0
    _svc_gone=""
    if [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ]; then
    if ! pidof com.fcpower >/dev/null 2>&1; then
      _need_unfreeze="1"                 # 进程都没了 -> 拉起
    else
      _hb=$(stat -c %Y /data/data/com.fcpower/files/hb 2>/dev/null)
      case "$_hb" in ""|*[!0-9]*) _hb=0 ;; esac
      [ $((_now - _hb)) -ge "${FLUID_HB_STALE_SEC:-10}" ] && _need_unfreeze="1"
    fi
    # 进程在、心跳也在, 但服务其实已经被回收 -> 只需补前台服务, 不必解冻 Activity。
    if [ -z "$_need_unfreeze" ] && ! fluid_service_running; then
      _svc_gone="1"
    fi
    if [ -n "$_need_unfreeze" ]; then
      # 限流：两次解冻至少间隔 FLUID_UNFREEZE_MIN_GAP_SEC(默认15s)，避免抖动
      _last=$(cat "$MODROOT/logs/fluid.unfreeze" 2>/dev/null)
      case "$_last" in ""|*[!0-9]*) _last=0 ;; esac
      if [ $((_now - _last)) -ge "${FLUID_UNFREEZE_MIN_GAP_SEC:-15}" ]; then
        echo "$_now" > "$MODROOT/logs/fluid.unfreeze" 2>/dev/null
        log "流体云心跳停止(心跳 ${_hb:-无}) -> am start 解冻载体 App"
        # v1.8.13: 原来这里是裸的 `sleep 1` —— 会**阻塞主循环**，
        # 使 fluid_tick 在该轮停摆，刷新节奏被拉到 2s 以上，
        # 正好发生在"App 刚被解冻、最需要立刻恢复刷新"的时刻，
        # 观感就是"解冻后要等两秒才动"。改为整段丢到后台子 shell，
        # 主循环不被阻塞，tick 保持 1s 节拍。
        (
          timeout 8 am start -n com.fcpower/.MainActivity --ez unfreeze true >/dev/null 2>&1
          sleep 1
          timeout 6 fluid_push_power_now >/dev/null 2>&1
        ) &
      fi
    elif [ -n "$_svc_gone" ]; then
      # 服务被回收但 App 没被冻结: 直接补服务 + 推当前真实功率
      log "流体云 PowerService 被回收 -> 补启动"
      ( timeout 6 fluid_push_power_now >/dev/null 2>&1 ) &
    fi
    fi  # end if FLUID_CLOUD_ENABLE
    # App 完全健康时不做任何 am 调用 —— 不打扰, 不闪烁。
  fi

  # ---- v1.8.13: 主循环节拍与 fluid_tick 解耦 ----
  # 旧版固定 `sleep 1`，与 fluid_tick 内部的 1s 限流**串联叠加**:
  #   tick 内部已按 1s 节流, 外层再固定 sleep 1, 两者相位一旦错开,
  #   就会出现"这一轮 tick 被内部限流早退 + 外层又睡满 1s" -> 实际 2s 才刷一次。
  # 改为按 FLUID_CLOUD_INTERVAL_SEC 的一半做**自适应小睡**(默认 500ms),
  # 让外层采样密度高于内层节流阈值, 内层限流成为唯一节拍源,
  # 从而稳定输出 1s 刷新, 不再出现 1s/2s 抖动。
  # 下限 100ms 防止配置被写成 0 时忙等烧 CPU。
  _loop_sleep=$(awk -v s="${FLUID_CLOUD_INTERVAL_SEC:-1}" 'BEGIN {
      v = s / 2; if (v < 0.1) v = 0.1; if (v > 1) v = 1; printf "%.2f", v
  }')
  case "$_loop_sleep" in ""|*[!0-9.]*) _loop_sleep=0.5 ;; esac
  sleep "$_loop_sleep" 2>/dev/null || sleep 1
done
