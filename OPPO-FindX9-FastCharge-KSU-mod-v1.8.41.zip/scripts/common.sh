#!/system/bin/sh
MODID=oppo_findx9_fastcharge
USER_CONFIG_DIR=/data/adb/$MODID
DEFAULT_CONFIG=$MODROOT/config/fastcharge.conf
LOG_DIR=$MODROOT/logs
LOG_FILE=$LOG_DIR/fastcharge.log
STATUS_FILE=$LOG_DIR/status.txt
DAEMON_PID_FILE=$LOG_DIR/daemon.pid
DERATE_STATE=$LOG_DIR/derate.state
mkdir -p "$LOG_DIR" 2>/dev/null
log() {
  echo "[$(date '+%F %T')] $*" >> "$LOG_FILE"
}
load_config() {
  CONFIG_PATH="$1"
  if [ ! -f "$CONFIG_PATH" ]; then
    mkdir -p "$USER_CONFIG_DIR" 2>/dev/null
    cp -f "$DEFAULT_CONFIG" "$CONFIG_PATH" 2>/dev/null
    log "配置不存在，已从模板重建: $CONFIG_PATH"
  fi
  if [ -f "$CONFIG_PATH" ]; then
    . "$CONFIG_PATH"
  else
    log "警告: 配置加载失败，使用默认值"
  fi
  log "已加载配置: $CONFIG_PATH"
}
device_check() {
  if [ "${ENABLE_DEVICE_CHECK:-true}" = "false" ]; then
    log "机型校验已关闭 (ENABLE_DEVICE_CHECK=false)"
    return 0
  fi
  if [ -z "$DEVICE_CODENAMES" ]; then
    log "DEVICE_CODENAMES 为空，跳过机型校验"
    return 0
  fi
  dev=$(getprop ro.product.device 2>/dev/null)
  model=$(getprop ro.product.model 2>/dev/null)
  for c in $DEVICE_CODENAMES; do
    if [ "$c" = "$dev" ] || [ "$c" = "$model" ]; then
      log "机型匹配: $c (device=$dev model=$model)"
      return 0
    fi
  done
  log "机型不匹配，不应用充电设置 (device=$dev model=$model, 期望: $DEVICE_CODENAMES)"
  return 1
}
write_node() {
  node="$1"
  value="$2"
  [ -n "$node" ] || return 1
  if [ -w "$node" ]; then
    if echo "$value" > "$node" 2>/dev/null; then
      log "OK   $node = $value"
      return 0
    else
      log "FAIL $node = $value (写入失败)"
    fi
  else
    log "SKIP $node (不存在或无写权限)"
  fi
  return 1
}
is_charging() {
  for status in /sys/class/power_supply/*/status; do
    [ -r "$status" ] || continue
    st=$(cat "$status" 2>/dev/null)
    case "$st" in
      Charging|Full) return 0 ;;
    esac
  done
  return 1
}
get_battery_capacity() {
  node=${CAPACITY_NODE:-/sys/class/power_supply/battery/capacity}
  if [ -r "$node" ]; then
    cat "$node" 2>/dev/null
  else
    log "容量节点不可读: $node"
    echo ""
  fi
}
get_battery_temp_tenths() {
  node=${TEMP_NODE:-/sys/class/power_supply/battery/temp}
  if [ -r "$node" ]; then
    t=$(cat "$node" 2>/dev/null)
    case "$t" in
      ""|*[!0-9]*)
        log "温度值无效: '$t'"
        echo ""
        return 1
        ;;
    esac
    echo "$t"
  else
    log "温度节点不可读: $node"
    echo ""
    return 1
  fi
}
# 带符号功率: 正=充电, 负=耗电 (单位 W)
get_battery_power_w_signed() {
  # 真实功率(带正负): 充电为正, 放电为负。符号由 get_battery_current_now 按 STATUS 判定,
  # 兼容 ColorOS16(负=充) 与 ColorOS17(正=充) 两种电流符号约定。
  v=$(cat /sys/class/power_supply/battery/voltage_now 2>/dev/null | tr -d ' \n')
  i=$(get_battery_current_now)
  case "$v" in ""|*[!0-9-]*) return 1 ;; esac
  case "$i" in ""|*[!0-9-]*) return 1 ;; esac
  a=${i#-}
  [ "$a" -lt 1000 ] && return 1
  [ "$v" -lt 100000 ] && v=$((v * 1000))
  awk -v v="$v" -v i="$i" 'BEGIN { printf "%.1f", v * i / 1e12 }'
}

# ------------------------------------------------------------
# v1.8.8: 对外使用的功率值 —— 带**输出平滑**。
# 旧版把原始瞬时功率直接推给通知, 而电池电流在快充协商/温控降流/PPS 切档
# 时会有真实的阶梯跳变, 流体云上表现为数字乱蹦甚至"回落"。
#
# 设计要点(踩过的坑):
#   · 只做**变化率限制**, 不做"疑似异常就永久压制"—— 否则一次真实的
#     大幅降流(如 4200→3100mA, 差 4.4W)会被永久钉死在旧值上, 再也下不来。
#   · 突变时按 FLUID_POWER_STEP_MAX_W 逐步逼近, 连续若干轮即可追上真实值,
#     视觉上是平滑爬升/下降, 而不是瞬跳或永久滞后。
#   · 只有**方向来回翻转**的抖动(反复跨越同一区间)才需要额外等待,
#     这里用"连续两次同向才允许换向"来抑制。
# 可通过 FLUID_POWER_SMOOTH=false 关闭平滑, 恢复原始瞬时报数(调试用)。
# ------------------------------------------------------------
FLUID_POWER_STATE=$LOG_DIR/fluid_power.state
FLUID_POWER_DIR=$LOG_DIR/fluid_power.dir

get_battery_power_w_stable() {
  _raw=$(get_battery_power_w_signed 2>/dev/null)
  [ -n "$_raw" ] || { cat "$FLUID_POWER_STATE" 2>/dev/null; return 0; }
  if [ "${FLUID_POWER_SMOOTH:-true}" != "true" ]; then
    echo "$_raw" > "$FLUID_POWER_STATE" 2>/dev/null
    echo "$_raw"
    return 0
  fi
  _step=${FLUID_POWER_STEP_MAX_W:-1.5}
  case "$_step" in ""|*[!0-9.]*) _step=1.5 ;; esac
  _prev=$(cat "$FLUID_POWER_STATE" 2>/dev/null)
  case "$_prev" in
    ""|*[!0-9.-]*)
      echo "$_raw" > "$FLUID_POWER_STATE" 2>/dev/null
      echo "$_raw"
      return 0
      ;;
  esac
  # 方向翻转抑制: 记录上次变化方向, 若本轮方向与上轮相反且幅度较大,
  # 要求再确认一轮, 避免在两个值之间来回跳。
  _rawdir=$(awk -v raw="$_raw" -v prev="$_prev" 'BEGIN{ d=raw-prev; if (d>0.05) print "up"; else if (d<-0.05) print "down"; else print "flat" }')
  _lastdir=$(cat "$FLUID_POWER_DIR" 2>/dev/null)
  _flips=$LOG_DIR/fluid_power.flip
  _fc=$(cat "$_flips" 2>/dev/null)
  case "$_fc" in ""|*[!0-9]*) _fc=0 ;; esac
  if [ "$_rawdir" = "flat" ]; then
    echo "$_raw" > "$FLUID_POWER_STATE" 2>/dev/null
    rm -f "$_flips" 2>/dev/null
    echo "$_raw"
    return 0
  fi
  if [ -n "$_lastdir" ] && [ "$_lastdir" != "flat" ] && [ "$_rawdir" != "$_lastdir" ]; then
    # 方向翻转 -> 需要连续两轮同向才承认换向
    _fc=$((_fc + 1))
    if [ "$_fc" -lt 2 ]; then
      echo "$_fc" > "$_flips" 2>/dev/null
      echo "$_prev"
      return 0
    fi
  else
    _fc=0
  fi
  rm -f "$_flips" 2>/dev/null
  # 残留 1 次的"待确认"若长时间没人来补第二轮, 会让方向标记停滞;
  # 用时间戳兜底: 距上次更新超过 30s 就清掉方向记忆, 保证能重新起步。
  _dts=$LOG_DIR/fluid_power.dir.ts
  _dnow=$(date +%s)
  _dold=$(cat "$_dts" 2>/dev/null)
  case "$_dold" in ""|*[!0-9]*) _dold=$_dnow ;; esac
  if [ $((_dnow - _dold)) -gt 30 ]; then
    rm -f "$FLUID_POWER_DIR" 2>/dev/null
  fi
  echo "$_dnow" > "$_dts" 2>/dev/null
  echo "$_rawdir" > "$FLUID_POWER_DIR" 2>/dev/null
  # 变化率限制: 向目标逐步逼近(不会永久滞后, 每轮最多走 _step)
  _out=$(awk -v raw="$_raw" -v prev="$_prev" -v step="$_step" 'BEGIN {
    d = raw - prev;
    if (d > step)  { printf "%.1f", prev + step; exit }
    if (d < -step) { printf "%.1f", prev - step; exit }
    printf "%.1f", raw;
  }')
  echo "$_out" > "$FLUID_POWER_STATE" 2>/dev/null
  echo "$_out"
}

# ------------------------------------------------------------
# 电池侧电流读取(内部函数): 只返回**电池侧**电流, 单位 uA, 已带符号。
# 与"输入侧"电流(usb/uevent INPUT_CURRENT_NOW)严格区分 —— 两者物理位置不同、
# 快充握手/PPS 切换瞬间数值差异极大, 混用会导致功率显示剧烈跳变。
# 读不到就返回 1, 由调用方决定"沿用上次值"还是"放弃本次采样"。
# ------------------------------------------------------------
_read_battery_current_ua() {
  local _st _sign v abs res rabs node rest mul unit
  _st=$(cat /sys/class/power_supply/battery/status 2>/dev/null | tr -d ' \n')
  case "$_st" in
    Charging|Full) _sign=1 ;;
    *) _sign=-1 ;;
  esac
  # 首选: battery/bms uevent 的 CURRENT_NOW (mA)
  for ue in /sys/class/power_supply/battery/uevent /sys/class/power_supply/bms/uevent; do
    [ -r "$ue" ] || continue
    v=$(grep -m1 '^POWER_SUPPLY_CURRENT_NOW=' "$ue" 2>/dev/null | cut -d= -f2)
    case "$v" in ""|*[!0-9-]*) continue ;; esac
    abs=${v#-}
    [ "$abs" -lt 10 ] && continue
    echo $((_sign * abs * 1000))
    return 0
  done
  # 次选: battery/current_now
  if [ -r /sys/class/power_supply/battery/current_now ]; then
    v=$(cat /sys/class/power_supply/battery/current_now 2>/dev/null | tr -d ' \n\r')
    case "$v" in
      ""|*[!0-9-]*) ;;
      *)
        abs=${v#-}
        [ "$abs" -ge 10 ] && { echo $((_sign * abs * 1000)); return 0; }
        ;;
    esac
  fi
  # 末选: 配置里的节点链(仍限定为电池侧节点, 绝不回落到 usb/输入侧)
  for n in $CURRENT_NOW_NODES; do
    case "$n" in ""|\#*) continue ;; esac
    node=${n%%:*}
    case "$node" in
      *power_supply/usb*) continue ;;   # 输入侧节点一律跳过
    esac
    rest=${n#*:}; mul=${rest%%:*}; unit=${rest#*:}
    [ "$node" = "$n" ] && mul=1
    [ "$rest" = "$mul" ] && unit="ua"
    case "$mul" in ""|0|*[!0-9]*) mul=1 ;; esac
    [ -r "$node" ] || continue
    v=$(cat "$node" 2>/dev/null | tr -d ' \n\r')
    case "$v" in ""|*[!0-9-]*) continue ;; esac
    abs=${v#-}
    [ "$abs" -lt 10 ] && continue
    if [ "$unit" = "ma" ]; then res=$((v * mul * 1000)); else res=$((v * mul)); fi
    rabs=${res#-}
    [ "$rabs" -lt 1000 ] && continue
    echo "$res"
    return 0
  done
  return 1
}

# ------------------------------------------------------------
# 输入侧电流(仅用于诊断/自检展示, 不参与功率计算)
# ------------------------------------------------------------
_read_input_current_ua() {
  local v abs
  if [ -r /sys/class/power_supply/usb/uevent ]; then
    v=$(grep -m1 '^POWER_SUPPLY_INPUT_CURRENT_NOW=' /sys/class/power_supply/usb/uevent 2>/dev/null | cut -d= -f2)
    case "$v" in
      ""|*[!0-9-]*) ;;
      *)
        abs=${v#-}
        [ "$abs" -ge 1000 ] && { echo "$v"; return 0; }
        ;;
    esac
  fi
  return 1
}

# ------------------------------------------------------------
# 对外接口: 带**采样黏滞**的电池电流(单位 uA, 带符号)。
#
# v1.8.8 修复核心之一:
#   旧实现会在"读不到电池侧电流"时静默回落到 usb/uevent 的输入侧电流,
#   两者单位/物理位置不同, 快充握手与 PPS 切换瞬间会来回切换数据源,
#   实测表现为流体云功率在 1.0/1.7/3.8/4.1/6.1 W 之间无规律跳变。
#   现在改为: 正常采样 -> 与上次有效值做"连续性"判定 -> 突跳时先抖动过滤
#   (连续 STALE_JUMP_CONFIRM 次相同才算数), 读不到则沿用上次有效值。
# ------------------------------------------------------------
BATT_CUR_STATE=$LOG_DIR/batt_current.state

get_battery_current_now() {
  local raw prev prev_ts now
  raw=$(_read_battery_current_ua)
  if [ -z "$raw" ]; then
    # 读不到: 沿用上次有效值(不换源重算), 避免制造假跳变
    prev=$(cat "$BATT_CUR_STATE" 2>/dev/null)
    case "$prev" in
      ""|*[!0-9-]*) return 1 ;;
    esac
    echo "$prev"
    return 0
  fi
  now=$(date +%s)
  prev=$(cat "$BATT_CUR_STATE" 2>/dev/null)
  case "$prev" in
    ""|*[!0-9-]*)
      echo "$raw" > "$BATT_CUR_STATE" 2>/dev/null
      echo "$raw"
      return 0
      ;;
  esac
  a=${raw#-}; b=${prev#-}
  # 变化幅度 < 1.5A 视为正常波动, 直接接受
  if [ $((a > b ? a - b : b - a)) -lt 1500000 ]; then
    echo "$raw" > "$BATT_CUR_STATE" 2>/dev/null
    echo "$raw"
    return 0
  fi
  # 突跳: 需要连续 2 次(约 1s)读到同方向的近似值才承认, 否则继续沿用旧值
  _pend=$LOG_DIR/batt_current.pend
  _pv=$(cat "$_pend" 2>/dev/null)
  cpv=${_pv#*:}
  # 注意: 校验对象必须是解析后的 cpv, 不能拿带冒号的 _pv 去匹配 [0-9-]
  # (否则 "1:2600000" 会因含 ':' 被判为非法, 导致确认逻辑永远失效)
  case "$cpv" in
    ""|*[!0-9-]*) cpv=0 ;;
  esac
  if [ "$cpv" -ne 0 ] 2>/dev/null; then
    e=${cpv#-}
    d=$((a > e ? a - e : e - a))
    if [ "$d" -lt 1500000 ]; then
      echo "$raw" > "$BATT_CUR_STATE" 2>/dev/null
      rm -f "$_pend" 2>/dev/null
      echo "$raw"
      return 0
    fi
  fi
  echo "1:$raw" > "$_pend" 2>/dev/null
  echo "$prev"
  return 0
}

# real-time charging power in W (battery voltage x current / 1e12)
get_battery_power_w() {
  v=$(cat /sys/class/power_supply/battery/voltage_now 2>/dev/null | tr -d ' \n')
  i=$(get_battery_current_now)
  case "$v" in ""|*[!0-9-]*) return 1 ;; esac
  case "$i" in ""|*[!0-9-]*) return 1 ;; esac
  i=${i#-}
  [ "$i" -lt 1000 ] && return 1
  # OPPO node family reports voltage_now in mV (e.g. 3979) -> convert to uV
  [ "$v" -lt 100000 ] && v=$((v * 1000))
  awk -v v="$v" -v i="$i" 'BEGIN { printf "%.1f", v * i / 1e12 }'
}
get_uevent_current_max() {
  for u in /sys/class/power_supply/battery/uevent /sys/class/power_supply/bms/uevent; do
    [ -r "$u" ] || continue
    v=$(grep -m1 'POWER_SUPPLY_CURRENT_MAX=' "$u" 2>/dev/null | cut -d= -f2)
    if [ -n "$v" ]; then
      echo "$v"
      return 0
    fi
  done
  return 1
}
current_for_capacity() {
  cap="$1"
  case "$cap" in
    ""|*[!0-9]*)
      log "电量值无效: '$cap'"
      return 1
      ;;
  esac
  low=${CAP_LOW:-10}
  high=${CAP_HIGH:-70}
  if   [ "$cap" -lt "$low" ]; then v=${CURRENT_LOW_MA:-5000}
  elif [ "$cap" -le "$high" ]; then v=${CURRENT_MID_MA:-8000}
  else v=${CURRENT_HIGH_MA:-3000}; fi
  case "$v" in
    ""|*[!0-9]*) ;;
    *)
      case "$GLOBAL_MAX_MA" in
        ""|*[!0-9]*) ;;
        *) [ "$v" -gt "$GLOBAL_MAX_MA" ] && v=$GLOBAL_MAX_MA ;;
      esac
      ;;
  esac
  echo "$v"
}
pick_charger_node() {
  if [ -n "$CURRENT_NODE" ] && [ -w "$CURRENT_NODE" ]; then
    echo "$CURRENT_NODE"
    return 0
  fi
  for n in $CHARGER_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ -w "$n" ]; then
      echo "$n"
      return 0
    fi
  done
  log "未找到可写的充电电流节点"
  return 1
}
derate_current() {
  ma="$1"
  if [ "${TEMP_DERATE_ENABLE:-true}" != "true" ]; then
    echo "$ma"
    return 0
  fi
  t=$(get_battery_temp_tenths)
  [ -z "$t" ] && { echo "$ma"; return 0; }
  critical_t=${TEMP_CRITICAL_TENTHS:-450}
  critical_exit=${TEMP_CRITICAL_EXIT_TENTHS:-440}
  critical_ma=${TEMP_CRITICAL_MA:-0}
  hard_t=${TEMP_HARD_CAP_TENTHS:-420}
  hard_exit=${TEMP_HARD_CAP_EXIT_TENTHS:-415}
  hard_ma=${TEMP_HARD_CAP_MA:-2000}
  l1=${TEMP_L1_TENTHS:-416}
  l2=${TEMP_L2_TENTHS:-438}
  l3=${TEMP_L3_TENTHS:-445}
  exit_l=${TEMP_LIMIT_EXIT_TENTHS:-406}
  min_ma=${TEMP_MIN_MA:-2000}
  max_ma=${TEMP_MAX_MA:-15000}
  state=""
  [ -f "$DERATE_STATE" ] && state=$(cat "$DERATE_STATE" 2>/dev/null)
  if [ "$t" -gt "$critical_t" ] || { [ "$state" = "critical" ] && [ "$t" -gt "$critical_exit" ]; }; then
    if [ "$state" != "critical" ]; then
      log "进入 45℃ 临界保护: 电流 ${critical_ma}mA (充电保持连接, 放电速度为正)"
    fi
    echo "critical" > "$DERATE_STATE" 2>/dev/null
    echo "$critical_ma"
    return 0
  fi
  if [ "$t" -gt "$hard_t" ] || { [ "$state" = "hard" ] && [ "$t" -gt "$hard_exit" ]; }; then
    val=$(awk -v ma="$ma" -v t="$t" -v l1="$l1" -v l2="$l2" -v l3="$l3" \
          -v min_ma="$min_ma" -v max_ma="$max_ma" 'BEGIN {
      if (ma > max_ma) ma = max_ma;
      if (t > l3) t = l3;
      v = ma * exp((t - l1) / 10.0 * log(0.94));
      if (t > l2) v = v * exp((t - l2) / 10.0 * log(0.85));
      if (v < min_ma) v = min_ma;
      printf "%d", v + 0.5
    }')
    if [ "$val" -gt "$hard_ma" ]; then
      val=$hard_ma
    fi
    if [ "$state" != "hard" ]; then
      log "进入 42℃ 硬顶保护: 最大电流 ${val}mA"
    fi
    echo "hard" > "$DERATE_STATE" 2>/dev/null
    echo "$val"
    return 0
  fi
  limited=""
  [ "$state" = "scene" ] && limited=1
  if [ "$t" -gt "$l1" ] || { [ "$limited" = "1" ] && [ "$t" -gt "$exit_l" ]; }; then
    val=$(awk -v ma="$ma" -v t="$t" -v l1="$l1" -v l2="$l2" -v l3="$l3" \
          -v min_ma="$min_ma" -v max_ma="$max_ma" 'BEGIN {
      if (ma > max_ma) ma = max_ma;
      if (t > l3) t = l3;
      v = ma * exp((t - l1) / 10.0 * log(0.94));
      if (t > l2) v = v * exp((t - l2) / 10.0 * log(0.85));
      if (v < min_ma) v = min_ma;
      printf "%d", v + 0.5
    }')
    echo "scene" > "$DERATE_STATE" 2>/dev/null
    echo "$val"
  else
    rm -f "$DERATE_STATE" 2>/dev/null
    echo "$ma"
  fi
}
try_write() {
  node="$1"
  value="$2"
  err=$( { echo "$value" > "$node"; } 2>&1 )
  if [ -z "$err" ]; then
    return 0
  fi
  echo "$err"
  return 1
}
write_input_current_ma() {
  ma="$1"
  if [ "${WRITE_UNIT:-ua}" = "ma" ]; then
    value=$ma
  else
    value=$((ma * 1000))
  fi
  for n in $INPUT_CURRENT_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ -w "$n" ]; then
      err=$(try_write "$n" "$value")
      if [ -z "$err" ]; then
        rb=$(cat "$n" 2>/dev/null)
        log "OK   输入限流 ${ma}mA (${value}ua) -> $n (读回: $rb)"
      else
        chmod 0666 "$n" 2>/dev/null
        err=$(try_write "$n" "$value")
        if [ -z "$err" ]; then
          rb=$(cat "$n" 2>/dev/null)
          log "OK   输入限流 ${ma}mA (${value}ua) -> $n (chmod 后成功, 读回: $rb)"
        else
          log "SKIP 输入限流 $n ($err)"
        fi
      fi
    else
      log "SKIP 输入限流 $n (不存在或无写权限)"
    fi
  done
}
write_votable_ma() {
  ma="$1"
  [ "${VOOTABLE_ENABLE:-true}" = "true" ] || return 0
  div=${VOOTABLE_DIVIDER:-1}
  case "$div" in
    ""|0|*[!0-9]*) div=1 ;;
  esac
  if [ "$div" -gt 1 ]; then
    ma=$((ma / div))
    [ "$ma" -lt 1 ] && ma=1
  fi
  # 协议节点按类型决定是否强制激活。
  # VOOC 默认保持原行为；PPS/PD 默认解除 force_active，避免第三方 PPS/PD
  # 被模块强制投票后触发协议冲突，表现为切档后掉到约 10W。
  for v in $VOOTABLE_NODES; do
    case "$v" in
      ""|\#*) continue ;;
    esac
    case "$v" in
      */PPS_CURR|*/PD_CURR)
        _fa=1
        [ "${VOOTABLE_PPS_FORCE_ACTIVE:-false}" = "true" ] || _fa=0
        ;;
      *)
        _fa=1
        [ "${VOOTABLE_FORCE_ACTIVE:-true}" = "true" ] || _fa=0
        ;;
    esac
    if [ -w "$v/force_val" ]; then
      if echo "$ma" > "$v/force_val" 2>/dev/null; then
        echo "$_fa" > "$v/force_active" 2>/dev/null
        eff=$(cat "$v/status" 2>/dev/null | grep -o 'effective=[^ ]* type=[^ ]* v=[0-9]*' | head -1)
        log "OK   votable $v = ${ma}mA (active=${_fa} $eff)"
      else
        log "FAIL votable $v = ${ma}mA (写入失败)"
      fi
    else
      log "SKIP votable $v (不存在或无写权限)"
    fi
  done
}
check_overspeed() {
  [ "${SAFETY_OVERRIDE_ENABLE:-true}" = "true" ] || return 0
  now=$(get_battery_current_now)
  case "$now" in
    ""|*[!0-9-]*) return 0 ;;
  esac
  abs=${now#-}

  # SAFETY_MAX_MA 语义 = 「电池侧实测电流」上限, 单位 mA(与目标值同量纲)。
  # v1.8.12: 旧版配 13500 时存在两个问题 ——
  #   ① 若阈值被误设得过低(例如 ≤ 目标峰值), 保护会常驻误触发, 把充电压到 2000mA;
  #   ② 若被误设得过高, 保护永远不会触发, 等于没有保护。
  # 这里做**下限保护**: 阈值至少不低于当前目标峰值, 否则自动抬到峰值,
  # 避免误触发; 同时用 GLOBAL_MAX_MA 作为软上限, 防止配出天文数字失去意义。
  limit_ma=${SAFETY_MAX_MA:-8000}
  case "$limit_ma" in
    ""|*[!0-9]*) limit_ma=8000 ;;
  esac
  _peak=${MANUAL_MAX_MA:-11000}
  case "$_peak" in ""|*[!0-9]*) _peak=11000 ;; esac
  if [ "$limit_ma" -lt "$_peak" ]; then
    log "!! SAFETY_MAX_MA(${limit_ma}) 低于目标峰值(${_peak})，已自动抬到峰值以避免误触发保护"
    limit_ma=$_peak
  fi

  limit_ua=$((limit_ma * 1000))
  if [ "$abs" -gt "$limit_ua" ]; then
    fallback=${SAFETY_FALLBACK_MA:-2000}
    log "!! 过流保护触发: 实测 $((abs / 1000))mA > 上限 ${limit_ma}mA，强制压到 ${fallback}mA"
    # 走与快充主路径相同的写入函数(会自行处理 VOOTABLE_DIVIDER)
    write_votable_ma "$fallback"
    echo "OVERRIDE" > "$DERATE_STATE" 2>/dev/null
    return 1
  fi
  return 0
}
write_voltage_cap() {
  [ "${VOLTAGE_CAP_ENABLE:-true}" = "true" ] || return 0
  for n in $VOLTAGE_CAP_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ -w "$n" ]; then
      if echo "$VOLTAGE_CAP_UV" > "$n" 2>/dev/null; then
        log "OK   电压上限 ${VOLTAGE_CAP_UV}µV ($((VOLTAGE_CAP_UV / 1000000))V) -> $n"
      else
        log "FAIL 电压上限写入失败 -> $n"
      fi
    else
      log "SKIP 电压上限节点不可写 -> $n"
    fi
  done
}
check_votable_ma() {
  ma="$1"
  [ "${VOOTABLE_ENABLE:-true}" = "true" ] || return 0
  div=${VOOTABLE_DIVIDER:-1}
  case "$div" in
    ""|0|*[!0-9]*) div=1 ;;
  esac
  # 比对用的"期望写入值": 必须与 write_votable_ma 内部的算法保持一致(它自己会做除法)。
  # 注意: 这里算出来的 expect **只用于比较**, 传给 write_votable_ma 的必须是原始 ma ——
  # 否则会被除两次(11000 -> 5500 -> 2750), 电流只剩目标的 1/4,
  # 且校验永远不通过, 造成每 2 秒一次的"补写"死循环。
  expect=$ma
  if [ "$div" -gt 1 ]; then
    expect=$((ma / div))
    [ "$expect" -lt 1 ] && expect=1
  fi
  for v in $VOOTABLE_NODES; do
    case "$v" in
      ""|\#*) continue ;;
    esac
    [ -r "$v/force_val" ] || continue
    # PPS/PD 在默认模式下由系统协议栈自行投票，不校验 force_val，避免
    # 守护进程每秒把系统自己的 PPS 协商结果覆盖回来。
    case "$v" in
      */PPS_CURR|*/PD_CURR)
        [ "${VOOTABLE_PPS_FORCE_ACTIVE:-false}" = "true" ] || continue
        ;;
    esac
    cur=$(cat "$v/force_val" 2>/dev/null)
    if [ "$cur" != "$expect" ]; then
      log "votable 值被改动 ($cur != $expect)，补写 $v"
      write_votable_ma "$ma"
      return 0
    fi
  done
}
apply_derated() {
  ma="$1"
  cap="$2"
  if [ "${SYSFS_WRITE_ENABLE:-false}" = "true" ]; then
    write_current_ma "$ma" "$cap"
    rc=$?
  else
    rc=0
  fi
  write_votable_ma "$ma"
  return $rc
}
write_current_ma() {
  ma="$1"
  cap="$2"
  if [ "${WRITE_UNIT:-ua}" = "ma" ]; then
    value=$ma
    unit="ma"
  else
    value=$((ma * 1000))
    unit="ua"
  fi
  if [ -n "$CURRENT_NODE" ]; then
    err=$(try_write "$CURRENT_NODE" "$value")
    if [ -z "$err" ]; then
      rb=$(cat "$CURRENT_NODE" 2>/dev/null)
      if [ -n "$rb" ] && [ "$rb" != "$value" ]; then
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $CURRENT_NODE (读回: $rb) !! 读回≠写入，可能被内核钳制"
      else
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $CURRENT_NODE (读回: $rb)"
      fi
      write_input_current_ma "$ma"
      return 0
    fi
    chmod 0666 "$CURRENT_NODE" 2>/dev/null
    err=$(try_write "$CURRENT_NODE" "$value")
    if [ -z "$err" ]; then
      log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $CURRENT_NODE (chmod 后成功)"
      write_input_current_ma "$ma"
      return 0
    fi
    log "FAIL 电流 ${ma}mA -> $CURRENT_NODE ($err)"
    return 1
  fi
  for n in $CHARGER_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    err=$(try_write "$n" "$value")
    if [ -z "$err" ]; then
      rb=$(cat "$n" 2>/dev/null)
      if [ -n "$rb" ] && [ "$rb" != "$value" ]; then
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $n (读回: $rb) !! 读回≠写入，可能被内核钳制"
      else
        log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $n (读回: $rb)"
      fi
      write_input_current_ma "$ma"
      return 0
    fi
    chmod 0666 "$n" 2>/dev/null
    err=$(try_write "$n" "$value")
    if [ -z "$err" ]; then
      log "OK   电流 ${ma}mA (${value}${unit}) 电量${cap}% -> $n (chmod 后成功)"
      write_input_current_ma "$ma"
      return 0
    fi
    log "SKIP $n ($err)"
  done
  log "FAIL 电流 ${ma}mA 所有节点均写入失败"
  return 1
}
probe_nodes() {
  log "==== 自动节点探测开始（真实充电状态）===="
  baseline=$(get_battery_current_now)
  log "PROBE 充电基线 current_now=$baseline"
  for n in $PROBE_NODES; do
    case "$n" in
      ""|\#*) continue ;;
    esac
    if [ ! -e "$n" ]; then
      log "PROBE $n 不存在"
      continue
    fi
    pre=$(cat "$n" 2>/dev/null)
    log "PROBE $n 原始值: $pre"
    for tv in 3000 3000000; do
      err=$(try_write "$n" "$tv")
      sleep 2
      rb=$(cat "$n" 2>/dev/null)
      now=$(get_battery_current_now)
      log "PROBE $n 写$tv -> 错误:[$err] 读回:[$rb] current_now:[$now]"
    done
  done
  log "==== 自动节点探测结束 ===="
}
is_daemon_running() {
  [ -f "$DAEMON_PID_FILE" ] || return 1
  pid=$(cat "$DAEMON_PID_FILE" 2>/dev/null)
  [ -n "$pid" ] && kill -0 "$pid" 2>/dev/null
}
start_daemon() {
  if is_daemon_running; then
    log "守护进程已在运行 (PID $(cat "$DAEMON_PID_FILE"))"
    return 0
  fi
  # v1.8.12: 启动加锁，消除 service.sh 与 boot-completed.sh 并发拉起导致的
  # 「两个 daemon 同时运行、互相覆盖 votable」问题。
  # is_daemon_running 检查与真正 fork 之间存在窗口：两个调用者可能同时通过检查。
  # 用 mkdir 的原子性做互斥锁，持有超过 10s 视为残留锁自动接管。
  _lk="$LOG_DIR/daemon.start.lock"
  if ! mkdir "$_lk" 2>/dev/null; then
    _lk_age=$(($(date +%s) - $(stat -c %Y "$_lk" 2>/dev/null || echo 0)))
    if [ "$_lk_age" -lt 10 ]; then
      log "另一处正在启动守护进程，跳过本次启动（锁龄 ${_lk_age}s）"
      return 0
    fi
    log "发现残留启动锁（锁龄 ${_lk_age}s），接管"
    rm -rf "$_lk" 2>/dev/null
    mkdir "$_lk" 2>/dev/null || return 0
  fi

  # 先清掉旧 PID 文件，避免 daemon 尚未写新 PID 时 is_daemon_running 读到陈旧值
  rm -f "$DAEMON_PID_FILE" 2>/dev/null
  if command -v nohup >/dev/null 2>&1; then
    nohup sh "$MODROOT/scripts/fastcharge_daemon.sh" "$MODROOT" >> "$LOG_FILE" 2>&1 &
  else
    sh "$MODROOT/scripts/fastcharge_daemon.sh" "$MODROOT" >> "$LOG_FILE" 2>&1 &
  fi
  # 注意: 这里**不再**写 PID 文件。daemon 启动后会自己写真实 $$，
  # 避免 $!（中间进程）与 $$（daemon 本体）不一致导致 stop 杀不干净。
  log "守护进程启动中"

  # 等 daemon 把真实 PID 落盘，最多 3s，然后释放锁
  _w=0
  while [ "$_w" -lt 30 ]; do
    [ -f "$DAEMON_PID_FILE" ] && break
    sleep 0.1 2>/dev/null || sleep 1
    _w=$((_w + 1))
  done
  rm -rf "$_lk" 2>/dev/null
  if is_daemon_running; then
    log "守护进程已就绪 (PID $(cat "$DAEMON_PID_FILE"))"
  else
    log "警告: 守护进程启动后未确认存活"
  fi
}
stop_daemon() {
  if [ -f "$DAEMON_PID_FILE" ]; then
    pid=$(cat "$DAEMON_PID_FILE" 2>/dev/null)
    [ -n "$pid" ] && kill "$pid" 2>/dev/null
    rm -f "$DAEMON_PID_FILE"
    log "已停止守护进程 (PID $pid)"
  else
    # v1.8.12: PID 文件可能因异常丢失，兜底按脚本名收掉残留进程，
    # 避免"PID 文件没了但 daemon 还在写 votable"的僵尸状态。
    if pkill -f 'fastcharge_daemon\.sh' 2>/dev/null; then
      log "PID 文件缺失，已按脚本名兜底停止守护进程"
    fi
  fi
  rm -rf "$LOG_DIR/daemon.start.lock" 2>/dev/null
}
apply_fastcharge() {
  log "==== 开始应用充电设置 ===="
  device_check || return 1
  if [ -n "$CHARGE_RULES" ]; then
    printf '%s\n' "$CHARGE_RULES" | while IFS= read -r rule; do
      rule=$(echo "$rule" | sed -e 's/^[[:space:]]*//' -e 's/[[:space:]]*$//')
      [ -z "$rule" ] && continue
      case "$rule" in
        \#*) continue ;;
        *=*)
          node=${rule%%=*}
          value=${rule#*=}
          write_node "$node" "$value"
          ;;
        *)
          log "规则格式无效，跳过: $rule"
          ;;
      esac
    done
  fi
  if [ -n "$EXTRA_COMMANDS" ]; then
    printf '%s\n' "$EXTRA_COMMANDS" | while IFS= read -r cmd; do
      case "$cmd" in
        ""|\#*) continue ;;
      esac
      log "执行附加命令: $cmd"
      sh -c "$cmd" >> "$LOG_FILE" 2>&1
    done
  fi
  cap=$(get_battery_capacity)
  base=$(current_for_capacity "$cap")
  result="SKIP: 电量不可用"
  derated=""
  if [ -n "$base" ]; then
    derated=$(derate_current "$base")
    if write_current_ma "$derated" "$cap"; then
      result="OK ${derated}mA (目标 ${base}mA)"
    else
      result="FAIL ${derated}mA (所有节点写入失败)"
    fi
  fi
  actual=$(get_battery_current_now)
  {
    echo "last_apply=$(date '+%F %T')"
    echo "result=$result"
    echo "capacity=${cap}%"
    echo "target_current=${base}mA"
    echo "applied_current=${derated:-none}mA"
    echo "actual_current=${actual:-n/a}µA"
    echo "device=$(getprop ro.product.device 2>/dev/null) model=$(getprop ro.product.model 2>/dev/null)"
    echo "config=$CONFIG_PATH"
  } | atomic_write "$STATUS_FILE"
  log "==== 应用完成 ===="
}
# ★ v1.8.32: 原子写 —— 先写同目录临时文件, 再 rename 覆盖。
#
# 为什么必须原子: 这些文件都是**跨进程**读写的。root 侧每秒整份重写
# (status.json / current / mode / power / current_now), 而载体 App(无 root,
# 另一个进程、另一种 SELinux 域)每秒读取; shell 的 `> file` 会先把文件
# truncate 成 0 字节再逐行写入 —— 读者若恰好落在这个窗口里就会读到半截内容:
#   · status.json -> JSON 解析失败, mode 字段丢失 -> 前端档位徽标翻回"自动档"
#   · current_ma  -> 被 read_manual_current 判成"内容无效"而删除 -> 档位掉回自动
# rename(2) 在同一文件系统内是原子的: 读者要么看到旧文件, 要么看到新文件。
# 注意: 覆盖后的文件属主仍是 root, 调用方仍需按原样 chown 回 App UID。
atomic_write() {
  _aw_dst="$1"
  [ -n "$_aw_dst" ] || return 1
  _aw_tmp="${_aw_dst%/*}/.${_aw_dst##*/}.tmp.$$"
  cat > "$_aw_tmp" 2>/dev/null || { rm -f "$_aw_tmp" 2>/dev/null; return 1; }
  chmod 600 "$_aw_tmp" 2>/dev/null
  mv -f "$_aw_tmp" "$_aw_dst" 2>/dev/null || { rm -f "$_aw_tmp" 2>/dev/null; return 1; }
  return 0
}

# ★ v1.8.41: 写**载体 App 私有目录**的专用版本。与 atomic_write 的唯一区别:
#   **在 mv 之前**就把属主 / 权限 / SELinux 标签设到 .tmp 上。
#   为什么必须"先设好再 mv", 而不是"先 mv 再 chown"(旧写法):
#     ① 窗口: mv(rename) 之后到 chown 之间, 文件是 root:root 600 ——
#        App(untrusted_app) 恰好在这一瞬读取就是 EACCES。App 每秒轮询,
#        绝大多数时候赶不上这个窗口 ⇒ 表现成"偶发"的 errno=1, 很难复现。
#     ② 更致命: 旧写法是 `[ -n "$_uid" ] && chown ...`, uid 解析失败时**静默跳过**,
#        文件就永久停在 root:root 600 ⇒ 表现成**持续**的「状态获取异常 (errno=1)」。
#   现在 uid 由调用方传入(每 tick 解析一次), 为空则本函数内部再回落到目录属主;
#   仍然拿不到就**返回失败**, 让调用方看得见, 而不是无声无息地写出一个读不了的文件。
#   标签(restorecon)同样重要: root 在 app 数据目录里新建的文件默认标签往往不是
#   app_data_file, 那样即使属主对了 App 也读不到 —— 与 v1.8.34 自选背景图是同一个坑。
atomic_write_app() {
  _aw_dst="$1"
  _aw_uid="$2"
  [ -n "$_aw_dst" ] || return 1
  case "$_aw_uid" in
    ""|*[!0-9]*|0) _aw_uid=$(stat -c %u "${_aw_dst%/*}" 2>/dev/null) ;;
  esac
  case "$_aw_uid" in
    ""|*[!0-9]*|0) return 1 ;;      # 拿不到 App uid —— 宁可不写, 也不写出一个 App 读不到的文件
  esac
  _aw_tmp="${_aw_dst%/*}/.${_aw_dst##*/}.tmp.$$"
  cat > "$_aw_tmp" 2>/dev/null || { rm -f "$_aw_tmp" 2>/dev/null; return 1; }
  chmod 600 "$_aw_tmp" 2>/dev/null
  chown "$_aw_uid:$_aw_uid" "$_aw_tmp" 2>/dev/null || { rm -f "$_aw_tmp" 2>/dev/null; return 1; }
  command -v restorecon >/dev/null 2>&1 && restorecon "$_aw_tmp" 2>/dev/null
  mv -f "$_aw_tmp" "$_aw_dst" 2>/dev/null || { rm -f "$_aw_tmp" 2>/dev/null; return 1; }
  return 0
}

MANUAL_CURRENT_FILE=$USER_CONFIG_DIR/current_ma
MANUAL_STATE_FILE=$USER_CONFIG_DIR/current_state.txt
read_manual_current() {
  [ -f "$MANUAL_CURRENT_FILE" ] || return 1
  v=$(tr -d ' \t\r' < "$MANUAL_CURRENT_FILE" 2>/dev/null)
  case "$v" in
    ""|*[!0-9]*)
      # ★ v1.8.32: **读取路径绝不删除文件**。
      #   旧实现在这里 `rm -f` 了, 理由是"内容无效就回退自动档"——听着合理,
      #   但它把"读"变成了"写", 而这个函数正被 root 侧多个进程以 0.5~1s 的
      #   频率并发调用(快充 daemon + 流体云 daemon 各自每轮都读)。一旦某次读到空
      #   (恰好落在别处 `> file` 的 truncate 窗口, 或是写入的中间态), 就会把
      #   **一份有效的配置**删掉 —— 档位直接掉回自动档, 用户再点一次又写回来,
      #   两个档位就这样来回跳。
      #   现在只报错、只让本次判定回退, 文件删除权收归 set_manual_current(0) 一个入口。
      log "手动电流文件内容无效: '$v'（本次按自动档处理, 不删除文件）"
      return 1
      ;;
  esac
  echo "$v"
  return 0
}
clamp_manual_ma() {
  ma="$1"
  case "$ma" in
    ""|*[!0-9]*) echo ""; return 1 ;;
  esac
  min=${MANUAL_MIN_MA:-1000}
  max=${MANUAL_MAX_MA:-8800}
  gm=${GLOBAL_MAX_MA:-0}
  case "$gm" in
    ""|*[!0-9]*) gm=0 ;;
  esac
  if [ "$gm" -gt 0 ] && [ "$max" -gt "$gm" ]; then max=$gm; fi
  [ "$ma" -lt "$min" ] && ma=$min
  [ "$ma" -gt "$max" ] && ma=$max
  echo "$ma"
}
apply_current_ma_direct() {
  ma="$1"
  [ -n "$ma" ] || return 1
  cap=$(get_battery_capacity)
  derated=$(derate_current "$ma")
  [ -z "$derated" ] && derated=$ma
  if apply_derated "$derated" "$cap"; then
    echo "OK"
  else
    echo "FAIL"
  fi
}
set_manual_current() {
  ma="$1"
  if [ -z "$ma" ] || [ "$ma" -le 0 ]; then
    rm -f "$MANUAL_CURRENT_FILE" 2>/dev/null
    log "恢复自动档位电流（按电量分档）"
    mode="auto"
    mc="auto"
    result=$(apply_current_ma_direct "$(current_for_capacity "$(get_battery_capacity)")")
  else
    clamped=$(clamp_manual_ma "$ma") || { log "手动电流值无效: '$ma'"; return 1; }
    ma=$clamped
    log "设置手动电流: ${ma}mA"
    # v1.8.32: 原子写 —— 否则并发读(read_manual_current 每 0.5s 一次)会读到
    # truncate 后的空文件并把档位判成自动档。
    echo "$ma" | atomic_write "$MANUAL_CURRENT_FILE"
    mode="manual"
    mc="${ma}mA"
    result=$(apply_current_ma_direct "$ma")
  fi
  cap=$(get_battery_capacity)
  {
    echo "mode=$mode"
    echo "manual_current=$mc"
    echo "capacity=${cap}%"
    echo "apply_result=${result:-n/a}"
    echo "last_set=$(date '+%F %T')"
  } > "$MANUAL_STATE_FILE" 2>/dev/null
  [ "$result" = "OK" ]
}

# ============================================================
# system limit unlock (bright-screen charge acceleration)
# re-applies system limit nodes every loop; keeps slider control
# ============================================================
ensure_node_value() {
  node="$1"; want="$2"; tag="$3"
  [ -n "$node" ] || return 0
  [ -e "$node" ] || return 0
  [ -w "$node" ] || return 0
  cur=$(cat "$node" 2>/dev/null)
  [ "$cur" = "$want" ] && return 0
  if echo "$want" > "$node" 2>/dev/null; then
    log "UNLOCK  ${tag} $node = ${want} (was ${cur})"
  fi
}

apply_limit_unlock() {
  [ "${LIMIT_UNLOCK_ENABLE:-true}" != "true" ] && return 0
  ensure_node_value /sys/class/oplus_chg/battery/cool_down 0 "cool-down"
  ensure_node_value /sys/class/oplus_chg/battery/normal_cool_down 0 "normal-cool"
  ensure_node_value /sys/class/power_supply/battery/step_charging_enabled 0 "step-charging"
  ensure_node_value /sys/class/power_supply/battery/restricted_charging 0 "restricted"
}
# ============================================================
# Fluid Cloud realtime charging power (bundled carrier app apk/base.apk)
# the app posts an ONGOING (non-clearable) notification driven by broadcast
# 刷新频率: 模块每 FLUID_CLOUD_INTERVAL_SEC(默认3)s 写一次功率到 App 私有文件,
#           载体 App 自轮询(500ms)后重发通知 -> 通知栏/流体云与 WebUI 同频(3s)
# ============================================================
FLUID_POWER_FILE=$LOG_DIR/fluid_power.txt
FLUID_PKG=com.fcpower
FLUID_APK_NAME=base.apk
# 内置载体 App 的 versionCode(构建时随 Apk 一起写入), 用于模块升级后自动覆盖安装。
# 不这样做的话, 模块升级换了图标/刷新逻辑, 手机上仍是旧 App, 改动不会生效。
FLUID_APK_VERSION_FILE=version.txt

# ColorOS 防冻结/防清理: 加入系统不冻结白名单 + 待机分组/白名单/后台权限
fluid_protect_app() {
  cur=$(settings get secure no_frozen 2>/dev/null)
  case "$cur" in
    *${FLUID_PKG}*) ;;
    *)
      settings put secure no_frozen "${cur}${FLUID_PKG}," >/dev/null 2>&1
      log "FLUID 已加入系统不冻结白名单"
      ;;
  esac
  # 流体云胶囊免动画(消除"收起->弹出"闪烁)
  _ca=$(settings get secure oplus_no_fluid_capsule_animation 2>/dev/null)
  case "$_ca" in
    *${FLUID_PKG}*) ;;
    *)
      _ca=$(echo "$_ca" | sed 's/^null//; s/^,//')
      settings put secure oplus_no_fluid_capsule_animation "${_ca},${FLUID_PKG}" >/dev/null 2>&1
      log "FLUID 已关闭胶囊动画(消除闪烁)"
      ;;
  esac
  am set-standby-bucket ${FLUID_PKG} active >/dev/null 2>&1
  dumpsys deviceidle whitelist +${FLUID_PKG} >/dev/null 2>&1
  cmd appops set ${FLUID_PKG} RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
}

# 已安装载体 App 的 versionCode:
#   1) 优先读模块自己记录的安装版本(最可靠, 不依赖 ROM 的 dumpsys 输出格式)
#   2) 其次 dumpsys / pm dump
fluid_installed_version() {
  _sv=$(tr -d ' \t\r\n' < "$USER_CONFIG_DIR/fluid.apk.ver" 2>/dev/null)
  if [ -n "$_sv" ]; then echo "$_sv"; return 0; fi
  _dv=$(dumpsys package ${FLUID_PKG} 2>/dev/null | grep -m1 -o 'versionCode=[0-9]*' | cut -d= -f2)
  if [ -n "$_dv" ]; then echo "$_dv"; return 0; fi
  _pv=$(pm dump ${FLUID_PKG} 2>/dev/null | grep -m1 -o 'versionCode=[0-9]*' | cut -d= -f2)
  [ -n "$_pv" ] && echo "$_pv"
}

# 版本号读不到时的兜底: 比较已安装 APK 与模块内置 APK 的体积
fluid_installed_size() {
  _p=$(pm path ${FLUID_PKG} 2>/dev/null | head -1 | sed 's/^package://')
  [ -n "$_p" ] && [ -f "$_p" ] && stat -c %s "$_p" 2>/dev/null
}

# ---- v1.8.29: 把模块 WebUI 同步到载体 App 私有目录 ----
# 载体 App 的原生界面已改为 WebView, 它加载的就是这一份 index.html ——
# 于是 App 与 KernelSU WebUI **只有一套 UI**: 模块更新 WebUI, App 界面即同步更新,
# 不会再出现"两端界面/参数不一致"这类反复返工的问题。
# App 没有 root, 读不到 /data/adb/modules/... , 必须由 root 侧复制进它的私有目录,
# 并把属主改回 App UID(否则 App 读不到 —— 与 bg.png 同一套做法)。
WEBUI_APP_DIR=/data/data/com.fcpower/files/webroot
WEBUI_APP_FILE=$WEBUI_APP_DIR/index.html

sync_webui_to_app() {
  _wsrc="${MODROOT:-/data/adb/modules/oppo_findx9_fastcharge}/webroot/index.html"
  [ -f "$_wsrc" ] || return 1
  [ -d /data/data/com.fcpower/files ] || return 1
  # 已同步且大小一致就跳过 —— 这个函数在守护进程 tick 里每秒都会被调到,
  # 绝不能在稳定态做多余的 IO。
  if [ -f "$WEBUI_APP_FILE" ] && \
     [ "$(stat -c %s "$_wsrc" 2>/dev/null)" = "$(stat -c %s "$WEBUI_APP_FILE" 2>/dev/null)" ]; then
    return 0
  fi
  mkdir -p "$WEBUI_APP_DIR" 2>/dev/null || return 1
  # ★ v1.8.32: 原子替换(先 cp 到同目录 .tmp 再 mv)。
  #   App 的 WebView 拦截器是把整个 index.html 一次性读出来喂给内核的,
  #   直接 `cp -f` 覆盖的那一瞬间它可能读到半截 HTML —— 页面直接报错或被判为空。
  #   rename 保证读者拿到的要么是旧完本、要么是新完本。
  cp -f "$_wsrc" "$WEBUI_APP_FILE.tmp" 2>/dev/null || return 1
  mv -f "$WEBUI_APP_FILE.tmp" "$WEBUI_APP_FILE" 2>/dev/null || return 1
  _wu=$(fluid_resolve_uid 2>/dev/null)
  [ -n "$_wu" ] && chown "$_wu:$_wu" "$WEBUI_APP_DIR" "$WEBUI_APP_FILE" 2>/dev/null
  chmod 755 "$WEBUI_APP_DIR" 2>/dev/null
  chmod 644 "$WEBUI_APP_FILE" 2>/dev/null
  # root 侧创建的文件可能带错 SELinux 标签, 会导致 App(untrusted_app) 读不到。
  command -v restorecon >/dev/null 2>&1 && \
    restorecon "$WEBUI_APP_FILE" >/dev/null 2>&1
  log "已同步 WebUI 到载体 App: $WEBUI_APP_FILE"
  return 0
}

ensure_fluid_app() {
  [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ] || return 1
  apk="${MODROOT:-/data/adb/modules/oppo_findx9_fastcharge}/apk/${FLUID_APK_NAME}"
  [ -f "$apk" ] || apk="/data/adb/modules/oppo_findx9_fastcharge/apk/${FLUID_APK_NAME}"
  want=$(tr -d ' \t\r\n' < "${apk%/*}/${FLUID_APK_VERSION_FILE}" 2>/dev/null)
  if pm list packages 2>/dev/null | grep -q "package:${FLUID_PKG}"; then
    have=$(fluid_installed_version)
    if [ -n "$want" ] && [ "$have" = "$want" ]; then
      return 0                      # 已是内置版本, 无需重装
    fi
    if [ -z "$have" ] && [ -f "$apk" ]; then
      _isz=$(fluid_installed_size)
      _wsz=$(stat -c %s "$apk" 2>/dev/null)
      if [ -n "$_isz" ] && [ "$_isz" = "$_wsz" ]; then
        [ -n "$want" ] && echo "$want" > "$USER_CONFIG_DIR/fluid.apk.ver" 2>/dev/null
        return 0
      fi
    fi
    log "FLUID 载体版本变更 (${have:-unknown} -> ${want:-unknown}), 覆盖安装以应用新图标/刷新逻辑"
  else
    log "FLUID 未检测到载体 App, 开始安装 ${FLUID_APK_NAME}"
  fi
  [ -f "$apk" ] || { log "FLUID 未找到载体 ${FLUID_APK_NAME}"; return 1; }
  # Android 17: 载体 APK 必须满足 resources.arsc 不压缩/4-byte 对齐，并带 V2+ 签名。
  # 先直接覆盖安装；若因签名不一致失败，必须先彻底移除旧包再安装。
  # 同时不要吞掉错误信息：把 pm 的 stderr 写入模块日志，方便定位 ROM 的真实失败原因。
  _fluid_tmp=/data/local/tmp/oppo_findx9_fluid.apk
  _fluid_err=/data/local/tmp/oppo_findx9_fluid_install.err
  _fluid_install_ok=0

  pm install -r -g "$apk" >"$_fluid_err" 2>&1 && _fluid_install_ok=1

  if [ "$_fluid_install_ok" != "1" ]; then
    _reason=$(tr '\n' ' ' < "$_fluid_err" 2>/dev/null | tail -c 500)
    log "FLUID 直接覆盖安装失败: ${_reason:-unknown}"
    # 停掉旧服务/进程，避免 ColorOS 在卸载窗口重新拉起旧包。
    am stop-service -n ${FLUID_PKG}/.PowerService >/dev/null 2>&1
    am force-stop ${FLUID_PKG} >/dev/null 2>&1
    # Android 17 上优先通过 cmd package 按用户移除，再用 pm 兜底。
    cmd package uninstall --user 0 ${FLUID_PKG} >"$_fluid_err" 2>&1 || true
    pm uninstall --user 0 ${FLUID_PKG} >>"$_fluid_err" 2>&1 || true
    pm uninstall ${FLUID_PKG} >>"$_fluid_err" 2>&1 || true
    sleep 1

    if pm list packages 2>/dev/null | grep -q "package:${FLUID_PKG}"; then
      log "FLUID 旧包仍存在，尝试禁用后再次移除"
      pm disable-user --user 0 ${FLUID_PKG} >>"$_fluid_err" 2>&1 || true
      cmd package uninstall --user 0 ${FLUID_PKG} >>"$_fluid_err" 2>&1 || true
      pm uninstall ${FLUID_PKG} >>"$_fluid_err" 2>&1 || true
    fi

    # 不再直接从 /data/adb/modules_update/... 安装，改从 shell 可读的临时路径安装。
    # 这样可规避 Android 17/ColorOS 17 对模块更新临时目录上下文的限制。
    cp -f "$apk" "$_fluid_tmp" 2>/dev/null || true
    chmod 0644 "$_fluid_tmp" 2>/dev/null || true
    pm install -r -g "$_fluid_tmp" >>"$_fluid_err" 2>&1 && _fluid_install_ok=1
  fi

  if [ "$_fluid_install_ok" != "1" ]; then
    _reason=$(tr '\n' ' ' < "$_fluid_err" 2>/dev/null | tail -c 800)
    log "FLUID 载体重新安装失败: ${_reason:-unknown}"
    rm -f "$_fluid_tmp" "$_fluid_err" 2>/dev/null
    return 1
  fi
  rm -f "$_fluid_tmp" "$_fluid_err" 2>/dev/null
  pm grant ${FLUID_PKG} android.permission.POST_NOTIFICATIONS >/dev/null 2>&1
  am set-standby-bucket ${FLUID_PKG} active >/dev/null 2>&1
  dumpsys deviceidle whitelist +${FLUID_PKG} >/dev/null 2>&1
  cmd appops set ${FLUID_PKG} RUN_ANY_IN_BACKGROUND allow >/dev/null 2>&1
  fluid_protect_app
  # v1.8.8: 原为 `--es pw "待机"` —— "待机" 不是数字, 会被 App 原样上屏,
  # 表现为流体云先显示"待机"再跳成真实功率。改为不带 pw(让 App 读文件),
  # 若文件已有值则直接推真实数值。
  if ! fluid_push_power_now; then
    am start-foreground-service -n com.fcpower/.PowerService >/dev/null 2>&1
  fi
  if [ -n "$want" ]; then
    mkdir -p "$USER_CONFIG_DIR" 2>/dev/null
    echo "$want" > "$USER_CONFIG_DIR/fluid.apk.ver" 2>/dev/null
  fi
  log "FLUID 载体已安装 (versionCode=${want:-unknown}) 并拉起前台服务"
  return 0
}

# 流体云刷新: 每 FLUID_CLOUD_INTERVAL_SEC 秒(默认1s)推送一次。
# 刷新与过流保护/快充写入完全解耦，避免保护分支 continue 导致流体云停止刷新。
# 载体 App 另有 500ms 自轮询兜底 -> 通知栏/流体云功率数值在 1s 内更新
# 充电中 -> "45.2 W"; 未充电/放电 -> "-3.2 W"(耗电)
# v1.8.13: 限流改用毫秒精度, 详见 fluid_tick 内的说明。
# 处理流体云胶囊/滑块发来的电流请求(立即生效)
# ============================================================
# 三档模式(游戏/日常/速充) - 数值由安装时音量键选择写入 modes.conf
# ============================================================
MODES_FILE=${MODES_FILE:-/data/adb/oppo_findx9_fastcharge/modes.conf}

read_mode_ma() {
  _m="$1"
  _g=0; _d=0; _f=0; _c=0
  if [ -f "$MODES_FILE" ]; then
    _c=$(grep -m1 '^COOLER=' "$MODES_FILE" 2>/dev/null | cut -d= -f2)
    _g=$(grep -m1 '^GAME=' "$MODES_FILE" 2>/dev/null | cut -d= -f2)
    _d=$(grep -m1 '^DAILY=' "$MODES_FILE" 2>/dev/null | cut -d= -f2)
    _f=$(grep -m1 '^FAST=' "$MODES_FILE" 2>/dev/null | cut -d= -f2)
  fi
  case "$_c" in 0|1) ;; *) _c=0 ;; esac
  case "$_g" in ""|*[!0-9]*) [ "$_c" = "1" ] && _g=6900 || _g=3000 ;; esac
  case "$_d" in ""|*[!0-9]*) [ "$_c" = "1" ] && _d=8000 || _d=6000 ;; esac
  case "$_f" in ""|*[!0-9]*) [ "$_c" = "1" ] && _f=11000 || _f=8100 ;; esac
  case "$_m" in
    game|游戏) echo "$_g" ;;
    daily|日常) echo "$_d" ;;
    fast|速充) echo "$_f" ;;
    *) echo "" ;;
  esac
}

apply_mode() {
  _m="$1"
  _ma=$(read_mode_ma "$_m")
  [ -n "$_ma" ] || { log "未知模式: $_m"; return 1; }
  if set_manual_current "$_ma" >/dev/null 2>&1; then
    log "模式切换: ${_m} -> ${_ma}mA (立即生效)"
    echo "$_m" > "$LOG_DIR/current_mode" 2>/dev/null
    return 0
  fi
  log "模式切换失败: ${_m} (${_ma}mA)"
  return 1
}

fluid_apply_request() {
  _reqf=/data/data/com.fcpower/files/current_req
  [ -f "$_reqf" ] || _reqf=""
  if [ -n "$_reqf" ]; then
    _req=$(tr -d ' \t\r\n' < "$_reqf" 2>/dev/null)
    rm -f "$_reqf" 2>/dev/null
    case "$_req" in
      auto) set_manual_current 0 >/dev/null 2>&1; log "App控制: 恢复自动档" ;;
      mode:*) apply_mode "${_req#mode:}" ;;
      ""|*[!0-9]*) ;;
      *) set_manual_current "$_req" >/dev/null 2>&1; log "App控制: 手动电流 ${_req}mA (立即生效)" ;;
    esac
  fi
  # ---- App 原生界面的流体云开关请求 (与 WebUI 的 action.sh fluid on/off 等价) ----
  _freqf=/data/data/com.fcpower/files/fluid_req
  if [ -f "$_freqf" ]; then
    _freq=$(tr -d ' \t\r\n' < "$_freqf" 2>/dev/null)
    rm -f "$_freqf" 2>/dev/null
    case "$_freq" in
      on|off)
        _cfg=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
        if [ "$_freq" = "on" ]; then _fv=true; else _fv=false; fi
        if grep -q '^FLUID_CLOUD_ENABLE=' "$_cfg" 2>/dev/null; then
          sed -i "s/^FLUID_CLOUD_ENABLE=.*/FLUID_CLOUD_ENABLE=${_fv}/" "$_cfg" 2>/dev/null
        else
          echo "FLUID_CLOUD_ENABLE=${_fv}" >> "$_cfg" 2>/dev/null
        fi
        FLUID_CLOUD_ENABLE="$_fv"
        if [ "$_fv" = "true" ]; then
          ( timeout 10 fluid_recover_service >/dev/null 2>&1 ) &
        else
          # 与 action.sh fluid off 相同的三步: 落标记 -> 停服务 -> 兜底广播
          _uid2=$(fluid_resolve_uid 2>/dev/null)
          if [ -d /data/data/com.fcpower/files ]; then
            # ★ v1.8.41: 改用 atomic_write_app。旧写法把整段包在 `[ -n "$_uid2" ]` 里,
            #   uid 解析失败就**整段静默跳过** —— 标记文件根本没写, 而 App 侧靠这个标记
            #   判断"模块已停止", 于是 App 显示的还是旧状态。现在:
            #   拿不到 uid 时 atomic_write_app 会自己回落到目录属主, 实在拿不到才返回非 0,
            #   并且这里会**写进日志**而不是无声无息。
            printf '' | atomic_write_app /data/data/com.fcpower/files/stopped "$_uid2" \
              || log "警告: 写 stopped 标记失败(可能是 App uid 解析异常)"
          fi
          am stop-service -n com.fcpower/.PowerService >/dev/null 2>&1
          am broadcast -n com.fcpower/.PowerReceiver -a com.fcpower.STOP -f 0x01000000 >/dev/null 2>&1
        fi
        log "App控制: 流体云开关 -> ${_fv}"
        ;;
    esac
  fi
  # ---- App 原生界面的"重启守护"请求 ----
  _dreqf=/data/data/com.fcpower/files/daemon_req
  if [ -f "$_dreqf" ]; then
    _dreq=$(tr -d ' \t\r\n' < "$_dreqf" 2>/dev/null)
    rm -f "$_dreqf" 2>/dev/null
    case "$_dreq" in
      restart)
        ( stop_daemon >/dev/null 2>&1; start_daemon >/dev/null 2>&1 ) &
        log "App控制: 重启快充守护进程"
        ;;
    esac
  fi
  # ---- App 原生界面的"重新应用"请求 (对应 WebUI 的 action.sh apply) ----
  # v1.8.13: 载体 App 底部按钮与 WebUI 对齐后新增。
  # 语义与 action.sh apply 完全一致: 有手动值就重写手动值, 否则按电量重新套用自动档。
  # 用途: 插拔充电器 / 协议重新协商 / 系统改动节点后, 强制把当前设置再压一遍。
  _areqf=/data/data/com.fcpower/files/reapply_req
  if [ -f "$_areqf" ]; then
    _areq=$(tr -d ' \t\r\n' < "$_areqf" 2>/dev/null)
    rm -f "$_areqf" 2>/dev/null
    case "$_areq" in
      apply)
        _m=$(read_manual_current 2>/dev/null)
        if [ -n "$_m" ]; then
          set_manual_current "$_m" >/dev/null 2>&1
          log "App控制: 重新应用手动电流 ${_m}mA"
        else
          apply_fastcharge >/dev/null 2>&1
          log "App控制: 重新应用自动档"
        fi
        ;;
    esac
  fi
  # ---- v1.8.29: 载体 App 首启时请求同步 WebUI ----
  # App 打开时若 files/webroot/index.html 还不存在(刚装模块/刚重启, 守护进程
  # 尚未跑完第一轮), 它会写这个请求; 这里立刻补一次同步, App 随即自动重载。
  _wqf=/data/data/com.fcpower/files/webui_req
  if [ -f "$_wqf" ]; then
    rm -f "$_wqf" 2>/dev/null
    sync_webui_to_app
  fi
}

fluid_service_running() {
  dumpsys activity services ${FLUID_PKG} 2>/dev/null | grep -q 'com\.fcpower/\.PowerService'
}

fluid_resolve_uid() {
  _uid=$(cmd package list packages -U 2>/dev/null | grep -m1 "package:${FLUID_PKG} " | sed -n 's/.*uid:\([0-9]*\).*/\1/p')
  case "$_uid" in
    ""|*[!0-9]*)
      _uid=$(dumpsys package ${FLUID_PKG} 2>/dev/null | grep -m1 -o 'userId=[0-9]*' | cut -d= -f2)
      ;;
  esac
  # ★ v1.8.41: 第三条兜底 —— App 私有目录自己的属主。
  #   为什么必须要它: 上面两条依赖 `cmd package` / `dumpsys`, 在部分 ColorOS 版本 /
  #   系统服务未就绪 / SELinux 受限时会**双双失败**, 于是这个函数返回非 0、
  #   调用方 `[ -n "$_uid" ] && chown ...` 就**静默跳过** chown ——
  #   root 写进 App 私有目录的文件永久停在 root:root 600,
  #   App(untrusted_app) 再也读不到 → 表现为**持续**的「状态获取异常 (errno=1)」+ 状态格全空。
  #   /data/data/com.fcpower/files 是 App 自己创建的, 它的属主**就是** App 的 uid,
  #   而且只要目录存在就一定读得到 —— 这是最可靠的一条来源。
  case "$_uid" in
    ""|*[!0-9]*)
      _uid=$(stat -c %u /data/data/com.fcpower/files 2>/dev/null)
      ;;
  esac
  case "$_uid" in
    ""|*[!0-9]*) return 1 ;;
    # 0 = root。落成 root 说明目录本身就不对(不该出现), 当作解析失败处理,
    # 否则下面的 chown root:root 等于什么都没做, 却让调用方以为已经修好了。
    0) return 1 ;;
  esac
  echo "$_uid"
}

# ------------------------------------------------------------
# v1.8.12: 统一的流体云守护进程启动入口。
# 旧版 service.sh 与 boot-completed.sh 各自 `nohup ... &` + `echo $! > pid`，
# 且 fluid_cloud_daemon.sh 内部又用 $$ 再写一次，存在与快充 daemon 完全相同的
# 「$! ≠ $$」问题，并且两个调用者并发启动时可能起出两个流体云 daemon
# （表现为通知/胶囊被反复重建、功率数值来回跳）。
# 现在三处统一调用本函数：mkdir 原子锁防并发，PID 由 daemon 自己落盘。
# ------------------------------------------------------------
FLUID_PID_FILE_NAME="fluid_cloud.pid"
start_fluid_daemon() {
  [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ] || return 0
  _fp="$LOG_DIR/$FLUID_PID_FILE_NAME"
  if [ -f "$_fp" ]; then
    _fpid=$(cat "$_fp" 2>/dev/null)
    if [ -n "$_fpid" ] && kill -0 "$_fpid" 2>/dev/null; then
      log "独立流体云守护进程已运行 (PID $_fpid)"
      return 0
    fi
  fi
  _lk="$LOG_DIR/fluid.start.lock"
  if ! mkdir "$_lk" 2>/dev/null; then
    _lk_age=$(($(date +%s) - $(stat -c %Y "$_lk" 2>/dev/null || echo 0)))
    if [ "$_lk_age" -lt 10 ]; then
      log "另一处正在启动流体云守护进程，跳过本次（锁龄 ${_lk_age}s）"
      return 0
    fi
    rm -rf "$_lk" 2>/dev/null
    mkdir "$_lk" 2>/dev/null || return 0
  fi
  rm -f "$_fp" 2>/dev/null
  if command -v nohup >/dev/null 2>&1; then
    nohup sh "$MODROOT/scripts/fluid_cloud_daemon.sh" "$MODROOT" >> "$LOG_FILE" 2>&1 &
  else
    sh "$MODROOT/scripts/fluid_cloud_daemon.sh" "$MODROOT" >> "$LOG_FILE" 2>&1 &
  fi
  log "独立流体云 Root 守护进程启动中"
  _w=0
  while [ "$_w" -lt 30 ]; do
    [ -f "$_fp" ] && break
    sleep 0.1 2>/dev/null || sleep 1
    _w=$((_w + 1))
  done
  rm -rf "$_lk" 2>/dev/null
  if [ -f "$_fp" ] && kill -0 "$(cat "$_fp" 2>/dev/null)" 2>/dev/null; then
    log "独立流体云守护进程已就绪 (PID $(cat "$_fp"))"
  fi
}

fluid_recover_service() {
  [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ] || return 0
  pm list packages 2>/dev/null | grep -q "package:${FLUID_PKG}" || return 0
  if ! fluid_service_running; then
    log "FLUID PowerService 未运行，执行一次恢复启动"
    fluid_protect_app
    # v1.8.7: 冻结态下 `am start-foreground-service` 无效(Not found)，
    # 先用 Activity 解冻 —— 这是唯一能穿透 ColorOS17 冻结的方式 —— 再拉起服务。
    # v1.8.10: 必须带 unfreeze 标记 —— MainActivity 现在有双入口,
    # 不带标记会被当成"用户点击", 弹出生界面 ControlActivity。
    am start -n ${FLUID_PKG}/.MainActivity --ez unfreeze true >/dev/null 2>&1
    sleep 1
    # v1.8.8: 这里**绝不能**再传 `--es pw "刷新"`。
    # App 的 Label.of() 只对纯数字追加 " W"，非数字字符串会原样上屏 ——
    # 旧版每 5s 一次的解冻/补服务都会把通知 id=1 从 "4.1 W" 覆盖成 "刷新"，
    # 500ms 后轮询线程再改回数值，形成视频里"数值↔刷新"来回闪的观感。
    # 改为传当前真实功率，App 立刻显示正确数值，无需等待轮询。
    fluid_push_power_now
  fi
}

# ------------------------------------------------------------
# v1.8.8: 把当前功率推给载体 App(唯一合法的"主动推"入口)
#   - 只传纯数字(或带负号的数字), 永不传中文占位文案
#   - 无有效功率时不推送, 交给 App 自己的轮询去读文件
# ------------------------------------------------------------
fluid_push_power_now() {
  _pw=$(get_battery_power_w_stable 2>/dev/null)
  case "$_pw" in
    ""|*[!0-9.-]*) return 1 ;;   # 非数值一律不推
  esac
  am start-foreground-service -n ${FLUID_PKG}/.PowerService --es pw "$_pw" >/dev/null 2>&1
}

fluid_tick() {
  # WebUI 开关免重启即时生效: 每轮从配置文件重新读取开关值, 而不是沿用启动快照。
  # (守护进程启动时 load_config 就把值读进内存了, 之后改 conf 对运行中的进程无效,
  #  这正是 WebUI「流体云开关不生效」的根因)
  _fce_tip=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
  _fce=$(grep -m1 '^FLUID_CLOUD_ENABLE=' "$_fce_tip" 2>/dev/null | tr -d ' \t\r\n' | cut -d= -f2)
  case "$_fce" in true|false) FLUID_CLOUD_ENABLE="$_fce" ;; esac

  # ---- v1.8.13: 限流改毫秒精度, 修「1 秒刷新但实际 2 秒」----
  # 旧版用 `date +%s` 的**秒级**时间戳与 FLUID_CLOUD_INTERVAL_SEC 比较:
  #     [ $((_nu - _lf)) -ge 1 ] || return 0
  # 而调用方守护进程主循环是 `sleep 1`。两者叠加会出问题:
  #   sleep 1 实际耗时略大于 1s(进程调度+本轮计算), 但时间戳只精确到秒。
  #   若某轮 tick 在 X.99s 执行, 下一轮在 X+1.98s 执行 -> 时间戳差 == 1,
  #   恰好 < 2 且 >= 1 尚可通过; 但当漂移累积到 X.01 -> X+1.99 这类边界时,
  #   时间戳差仍是 1 却已经"多等了一轮", 表现为刷新节奏在 1s/2s 之间抖动。
  #   更糟的是 `sleep 1` 若被调度延迟(系统忙), 时间戳差可能只有 0,
  #   整轮直接 return —— 那一秒完全不刷新。
  # 改为读 /proc/uptime 的毫秒小数部分做单调时钟比较, 精度 10ms,
  # 彻底消除秒边界抖动。用 uptime 而非 date 还避免系统时间被 NTP 校正后跳变。
  _now_ms() {
    awk '{ printf "%d", ($1 * 1000) }' /proc/uptime 2>/dev/null || echo 0
  }
  _nu_ms=$(_now_ms)
  _lf_ms=$(cat "$LOG_DIR/fluid.last_ms" 2>/dev/null)
  case "$_lf_ms" in ""|*[!0-9]*) _lf_ms=0 ;; esac
  _gap_ms=$(( ${FLUID_CLOUD_INTERVAL_SEC:-1} * 1000 ))
  [ "$_gap_ms" -ge 200 ] || _gap_ms=1000
  [ $((_nu_ms - _lf_ms)) -ge "$_gap_ms" ] || return 0
  echo "$_nu_ms" > "$LOG_DIR/fluid.last_ms" 2>/dev/null

  # 秒级时间戳仍保留: 供后续 10s/300s 级别的低频任务(服务恢复/白名单)使用
  _nu=$(date +%s)

  # ★ 数据落盘与流体云开关**解耦**:
  #   status.json / power / current_now 是载体 App 原生界面的**唯一数据源**。
  #   旧版把它们放在 `FLUID_CLOUD_ENABLE = true` 的早退之后 —— 一旦用户关闭流体云,
  #   fluid_tick 立即 return, App 界面就永远停在旧数据(表现为"关了流体云后 App 不再刷新"
  #   以及"流体云开关状态显示不一致")。现在改为: 采集+落盘**始终执行**,
  #   只有"发广播/刷胶囊/推通知"这类真正属于流体云的动作才受开关控制。
  _do_fluid=""
  [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ] && _do_fluid="1"

  # 1) 不再主动解冻/拉起载体 App。ColorOS 17 对后台生命周期管理更严格，
  #    模块不应与系统冻结策略互相抢控制权。

  # 2) 读功率+实际电流, 写状态文件 + App私有文件(App轮询读取, 作为兜底)
  _pw=$(get_battery_power_w_stable 2>/dev/null)
  [ -n "$_pw" ] || _pw="0.0"
  _cur=$(get_battery_current_now 2>/dev/null)
  case "$_cur" in ""|*[!0-9-]*) _cur=0 ;; esac
  echo "$(date '+%F %T') ${_pw}W" > "$FLUID_POWER_FILE" 2>/dev/null
  if [ -d /data/data/com.fcpower/files ]; then
    # Root 写入 App 私有目录后必须恢复为载体 App UID；旧版这里使用了
    # 未初始化的 $_uid，导致部分 ColorOS 17 版本下 App 后续读不到更新值。
    _uid=$(fluid_resolve_uid 2>/dev/null)
    # v1.8.12: 旧版每秒对 files/ 做一次递归 chown -R。
    # 该目录虽小，但它是**每秒**执行的递归遍历 + 系统调用，属于不必要的持续开销，
    # 且下方每个文件本来就会单独 chown 一次，递归整目录纯属重复劳动。
    # 改为「目录属主异常时才修一次」：用 stat 比对当前 owner 与目标 UID，
    # 一致就直接跳过，仅在首次创建 / 被改动后才做一次修正。
    if [ -n "$_uid" ]; then
      _dir_uid=$(stat -c %u /data/data/com.fcpower/files 2>/dev/null)
      if [ "$_dir_uid" != "$_uid" ]; then
        chown -R "$_uid:$_uid" /data/data/com.fcpower/files 2>/dev/null
        log "已修正载体 App files/ 目录属主: ${_dir_uid:-?} -> $_uid"
      fi
    fi
    # v1.8.32: 全部改原子写 —— App 侧每秒在读这几个文件, `> file` 的 truncate
    # 窗口会让它读到空值/半截值(通知栏功率显示空白、current 读成 0 等)。
    echo "$_pw" | atomic_write_app /data/data/com.fcpower/files/power "$_uid"
    echo "$_cur" | atomic_write_app /data/data/com.fcpower/files/current_now "$_uid"
    _mc=$(read_manual_current 2>/dev/null)
    [ -n "$_mc" ] || _mc="auto"
    echo "$_mc" | atomic_write_app /data/data/com.fcpower/files/current "$_uid"
    _cm=$(cat "$LOG_DIR/current_mode" 2>/dev/null)
    if [ -n "$_cm" ]; then
      echo "$_cm" | atomic_write_app /data/data/com.fcpower/files/mode "$_uid"
    fi

    # ---- status.json: 供载体 App 的原生控制界面读取 ----
    # 目的: App 原生界面与 KernelSU WebUI **同源同数据**, 永远不会出现两边数值不一致。
    #   WebUI 走 `action.sh status` 输出 key=value; 这里把同一批字段以 JSON 落到
    #   App 私有目录, 由 ControlActivity 直接读取渲染。
    #   字段与 action.sh status_lines 保持一一对应, 新增字段时两边都要改。
    _sj_mode="auto"
    [ -n "$_mc" ] && [ "$_mc" != "auto" ] && _sj_mode="manual"
    _sj_cap=$(get_battery_capacity 2>/dev/null)
    case "$_sj_cap" in ""|*[!0-9]*) _sj_cap="" ;; esac
    _sj_t=$(get_battery_temp_tenths 2>/dev/null)
    case "$_sj_t" in ""|*[!0-9]*) _sj_temp="" ;; *) _sj_temp="$((_sj_t / 10)).$((_sj_t % 10))" ;; esac
    if is_charging; then _sj_chg="charging"; else _sj_chg="idle"; fi
    _sj_target="$_mc"
    [ "$_sj_target" = "auto" ] && _sj_target=$(current_for_capacity "$_sj_cap" 2>/dev/null)
    [ -n "$_sj_target" ] || _sj_target="n/a"
    # 流体云开关: 必须以**磁盘配置**为准。
    # 长驻的 fluid_cloud_daemon 在启动时一次性 source 了配置, 内存里的
    # FLUID_CLOUD_ENABLE 不会随 App/WebUI 的开关请求刷新; 若直接用它,
    # 会出现"App 里已关闭流体云、状态却仍显示 on"的不一致。
    _sj_fluid="off"
    _fc_cfg="${CONFIG_PATH:-$USER_CONFIG_DIR/fastcharge.conf}"
    [ -f "$_fc_cfg" ] || _fc_cfg="$USER_CONFIG_DIR/fastcharge.conf"
    _fc_val=$(grep -m1 '^FLUID_CLOUD_ENABLE=' "$_fc_cfg" 2>/dev/null | cut -d= -f2- | tr -d ' \t\r\n')
    _fc_val="${_fc_val:-${FLUID_CLOUD_ENABLE:-true}}"
    [ "$_fc_val" = "true" ] && _sj_fluid="on"
    _sj_applied=""; _sj_result=""; _sj_dpid=""
    if [ -f "$STATUS_FILE" ]; then
      _sj_applied=$(grep -m1 '^applied_current=' "$STATUS_FILE" 2>/dev/null | cut -d= -f2-)
      _sj_result=$(grep -m1 '^result=' "$STATUS_FILE" 2>/dev/null | cut -d= -f2-)
    fi
    _sj_pidf="$LOG_DIR/daemon.pid"
    if [ -f "$_sj_pidf" ]; then
      _sj_dpid=$(cat "$_sj_pidf" 2>/dev/null | tr -d ' \t\r\n')
      case "$_sj_dpid" in ""|*[!0-9]*) _sj_dpid="" ;; esac
    fi
    _sj_modecfg=$(cat "$LOG_DIR/current_mode" 2>/dev/null)
    # ★ v1.8.32: 整份 JSON 改走 atomic_write(先写 .tmp 再 rename)。
    #   这是「App 前台时档位来回跳」的一个直接诱因:
    #   旧写法 `{ ... } > status.json` 会先把文件截断成 0 字节再写 20 行,
    #   载体 App 的 WebView 恰好在这一瞬读取就会拿到**半截 JSON** → 解析失败 →
    #   桥返回 errno → 前端 status 为空 → 档位徽标被渲染成"自动档";
    #   下一帧读到完整文件又变回"手动锁定 8000"。文件内容每次都完整,
    #   但读者看到的是"有 / 无"交替, 表现就是两个档位频繁切换。
    {
      printf '{\n'
      printf '  "ts": %s,\n' "$_nu"
      printf '  "mode": "%s",\n' "$_sj_mode"
      printf '  "manual_current": "%s",\n' "$_mc"
      # ---- v1.8.13: 把滑块边界与折算系数一并下发 ----
      # 目的: 载体 App 原生界面与 WebUI 共用同一份「真值源」。
      #   WebUI 走 `grep MANUAL_*_MA fastcharge.conf` 直接读配置;
      #   App 走 status.json 读模块算好并下发的值。
      #   两者若各自解析配置，一旦配置格式/注释变化就会出现"两边阈值不一样"。
      #   这里由模块统一解析后下发, 从根本上保证一致性。
      printf '  "manual_min": "%s",\n' "${MANUAL_MIN_MA:-1000}"
      printf '  "manual_max": "%s",\n' "${MANUAL_MAX_MA:-8800}"
      printf '  "manual_danger": "%s",\n' "${MANUAL_DANGER_MA:-9200}"
      printf '  "divider": "%s",\n' "${VOOTABLE_DIVIDER:-1}"
      printf '  "charging": "%s",\n' "$_sj_chg"
      printf '  "capacity": "%s",\n' "$_sj_cap"
      printf '  "temp": "%s",\n' "$_sj_temp"
      printf '  "current_now": "%s",\n' "$_cur"
      printf '  "target_current": "%s",\n' "$_sj_target"
      printf '  "applied_current": "%s",\n' "$_sj_applied"
      printf '  "result": "%s",\n' "$_sj_result"
      printf '  "daemon_pid": "%s",\n' "$_sj_dpid"
      printf '  "power": "%s",\n' "$_pw"
      printf '  "fluid": "%s",\n' "$_sj_fluid"
      printf '  "cur_mode": "%s",\n' "$_sj_modecfg"
      printf '  "mode_game": "%s",\n' "$(read_mode_ma game 2>/dev/null)"
      printf '  "mode_daily": "%s",\n' "$(read_mode_ma daily 2>/dev/null)"
      printf '  "mode_fast": "%s"\n' "$(read_mode_ma fast 2>/dev/null)"
      printf '}\n'
    } | atomic_write_app /data/data/com.fcpower/files/status.json "$_uid"

    # ---- 背景图 ----
    # ★ v1.8.34: 这一段原来是「把 webroot/background.png 拷成 App 侧 files/bg.png」,
    #   那是 v1.8.28 及更早**原生界面**时代的产物: 当年 ControlActivity 自己
    #   BitmapFactory.decodeFile(files/bg.png) 画背景。
    #   v1.8.29 载体 App 改成 WebView 加载模块 WebUI 之后, **全工程再没有任何代码
    #   读 files/bg.png** —— 它纯粹是每次模块升级白拷 1.15MB 的死代码, 已删。
    #   (背景图现在只有一条路径: index.html 的 --user-bg / --bg-default,
    #    前者由页面自己管, 后者已经内嵌。)
    #
    #   取而代之, 这里做一件**真正需要的事**: 镜像「两端共享的自选背景图」。
    #   App 与 KernelSU 管理器是两个不同的 origin, localStorage 各存一份, 所以在
    #   管理器里选的背景图 App 看不见(反之亦然) —— 实机表现就是"同一个界面, 一边
    #   显示了自选图、另一边退回内置默认图"。
    #   现在两个宿主选图时都会把图写到 App 私有目录 files/bg_user.jpg
    #   (App 侧走 fcapp 桥; KernelSU 侧有 root, 页面用 ksu.exec 分块写入),
    #   这里把它镜像到模块 webroot/, 让模块侧的 WebUI 也能看到同一张。
    #   单向: 私有目录是唯一的写入端点, 模块侧只是镜像。
    #   同样"大小一致即跳过" —— 稳定态零 IO。
    _ub_src=/data/data/com.fcpower/files/bg_user.jpg
    _ub_dst="${MODROOT:-/data/adb/modules/oppo_findx9_fastcharge}/webroot/bg_user.jpg"
    if [ -f "$_ub_src" ]; then
      if [ ! -f "$_ub_dst" ] || \
         [ "$(stat -c %s "$_ub_src" 2>/dev/null)" != "$(stat -c %s "$_ub_dst" 2>/dev/null)" ]; then
        # 原子替换: WebUI 可能正在读它(页面里的 Image 探测), rename 保证非全即全
        if cp -f "$_ub_src" "$_ub_dst.tmp" 2>/dev/null; then
          chmod 644 "$_ub_dst.tmp" 2>/dev/null
          mv -f "$_ub_dst.tmp" "$_ub_dst" 2>/dev/null && log "已镜像自选背景图: $_ub_dst"
        fi
        rm -f "$_ub_dst.tmp" 2>/dev/null
      fi
    fi

    # ---- v1.8.29: WebUI(index.html) ----
    # 载体 App 的界面已改为 WebView 加载这一份 HTML, 必须持续保持同步:
    # 模块升级后(文件大小变化)下一 tick 就会把新界面送到 App。
    # 内部同样自带"大小一致即跳过"的短路, 稳定态零开销。
    sync_webui_to_app
  fi

  # 3) 兜底通道: 发送 UPDATE 广播。
  #    ColorOS 17 下仅依赖 App 自轮询容易出现"前几次能刷新、随后卡住"；
  #    广播作为主动唤醒通道，确保通知/流体云持续拿到最新功率。
  #
  #    v1.8.8 修正: 旧版每 FLUID_CLOUD_INTERVAL_SEC(1s) 都无条件发一次广播，
  #    而 App 的 onReceive 每次收到都会 `notify(1, ...)` 重建通知 ——
  #    即使功率数值没变也会触发通知更新，在流体云上就是持续的胶囊抖动/重展开。
  #    现在改为: 只在功率数值**真的变化**时才发，并受 FLUID_BROADCAST_INTERVAL_SEC 限流。
  #
  #    v1.8.13 修正「与 WebUI 不同步」:
  #    旧逻辑 `[ "$_pw" != "$_bcast_last" ] && [ 间隔 >= gap ]` 在功率**不变**时
  #    完全不发广播。看似省事，实际有两个副作用:
  #      ① 「不变」只是模块侧认为的不变; 若 App 在此时被系统冻结/重建,
  #         它就永远等不到下一帧(因为功率稳定时模块根本不发), 流体云卡在旧值。
  #      ② WebUI 走 `action.sh status` 每 1s 直接读文件, 是**拉取**模型;
  #         流体云走广播, 是**推送**模型。功率稳定期间二者节奏不一致,
  #         用户会看到 WebUI 已在跳动而流体云还是旧数 —— 即报告里的"不同步"。
  #    改为: 功率变化时立即发(最快路径, 不等间隔);
  #          功率未变化时也按 FLUID_BROADCAST_INTERVAL_SEC 做**心跳式**重发,
  #          给 App 兜底对齐机会。这样流体云与 WebUI 都是稳定的 1s 节奏。
  if [ -n "$_do_fluid" ]; then
  _bcast_last=$(cat "$LOG_DIR/fluid.bcast.pw" 2>/dev/null)
  _bcast_ts=$(cat "$LOG_DIR/fluid.bcast.ts" 2>/dev/null)
  case "$_bcast_ts" in ""|*[!0-9]*) _bcast_ts=0 ;; esac
  _bcast_gap=${FLUID_BROADCAST_INTERVAL_SEC:-1}
  case "$_bcast_gap" in ""|*[!0-9]*) _bcast_gap=1 ;; esac
  _do_bcast=""
  if [ "$_pw" != "$_bcast_last" ]; then
    _do_bcast="1"                       # 数值变了: 立即推送, 不受间隔限制
  elif [ $((_nu - _bcast_ts)) -ge "$_bcast_gap" ]; then
    _do_bcast="1"                       # 数值没变: 按间隔心跳重发, 兜底对齐
  fi
  if [ -n "$_do_bcast" ]; then
    echo "$_pw" > "$LOG_DIR/fluid.bcast.pw" 2>/dev/null
    echo "$_nu" > "$LOG_DIR/fluid.bcast.ts" 2>/dev/null
    timeout 4 am broadcast -n com.fcpower/.PowerReceiver -a com.fcpower.UPDATE -f 0x01000000 --es pw "$_pw" >/dev/null 2>&1 &
  fi

  # 3b) PowerService 恢复：不主动反复拉起，只在确认服务已经不存在时恢复一次。
  #     这样既避免 ColorOS 17 的“强制停止 -> 立即拉起”循环，又能覆盖
  #     “服务被系统清掉后，流体云长期停在旧数值”的情况。
  _sr=$(cat "$LOG_DIR/fluid.service" 2>/dev/null)
  case "$_sr" in ""|*[!0-9]*) _sr=0 ;; esac
  if [ $((_nu - _sr)) -ge 10 ]; then
    echo "$_nu" > "$LOG_DIR/fluid.service" 2>/dev/null
    ( timeout 12 fluid_recover_service >/dev/null 2>&1 ) &
  fi

  # 4) 防冻结/免动画白名单每 5 分钟复核一次
  _np=$(cat "$LOG_DIR/fluid.protect" 2>/dev/null)
  case "$_np" in ""|*[!0-9]*) _np=0 ;; esac
  if [ $((_nu - _np)) -ge 300 ]; then
    echo "$_nu" > "$LOG_DIR/fluid.protect" 2>/dev/null
    ( timeout 10 fluid_protect_app >/dev/null 2>&1 ) &
  fi
  fi  # end if _do_fluid
}

