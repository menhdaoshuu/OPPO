#!/system/bin/sh
MODROOT="$1"
[ -n "$MODROOT" ] || exit 1
export MODROOT
. "$MODROOT/scripts/common.sh"
CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

# v1.8.12: PID 文件改由 daemon 自己写"真实 PID"，不再由 start_daemon 写 $!。
# 旧版 start_daemon 先写 $!（nohup/sh 的中间进程 PID），随后本脚本又用 $$ 覆盖。
# 两者在 nohup 场景下**不是同一个值**，会出现：
#   - stop_daemon 读到 $$ 之前的时间窗口里杀掉的是中间进程，daemon 成为孤儿继续跑；
#   - 反过来若中间进程已退出，kill -0 判活失败，watchdog 误判"已退出"并再起一个，
#     形成两个 daemon 同时写 votable 互相覆盖。
# 现在统一以本脚本写下的 $$ 为唯一真值，start_daemon 只负责拉起、不写 PID。
echo $$ > "$DAEMON_PID_FILE" 2>/dev/null
log "快充守护进程已启动 (PID $$, 轮询 ${DAEMON_INTERVAL_SEC:-1}s, 始终在线=${ALWAYS_ONLINE:-true}, WebUI-independent)"
log "机型: device=$(getprop ro.product.device 2>/dev/null) model=$(getprop ro.product.model 2>/dev/null) (期望: $DEVICE_CODENAMES)"
node=$(pick_charger_node)
if [ -n "$node" ]; then
  log "检测到候选节点: $node (写入时逐个尝试)"
else
  log "警告: 未找到可写的充电电流节点，守护进程将持续重试"
fi
last_written=""
last_effective=""
probed=0
write_voltage_cap
while :; do
  if is_charging; then
    charging="yes"
  else
    charging="no"
  fi
  # 流体云已经独立为单独的 root 守护进程 fluid_cloud_daemon.sh。
  # 本进程只负责快充控制，避免快充循环异常、过流保护或 PPS 状态切换
  # 影响流体云刷新。
  if ! check_overspeed; then
    sleep "${DAEMON_INTERVAL_SEC:-1}"
    continue
  fi
  if [ "${ALWAYS_ONLINE:-true}" = "true" ] || [ "$charging" = "yes" ]; then
    fluid_apply_request
    if [ "$charging" = "yes" ] && [ "$probed" = "0" ] && [ "${AUTO_PROBE:-true}" = "true" ]; then
      probed=1
      probe_nodes
    fi
    cap=$(get_battery_capacity)
    manual=$(read_manual_current)
    if [ -n "$manual" ]; then
      manual=$(clamp_manual_ma "$manual") || manual=""
    fi
    if [ -n "$manual" ]; then
      base=$manual
      mode="manual"
    else
      base=$(current_for_capacity "$cap")
      mode="auto"
    fi
    if [ -n "$base" ]; then
      derated=$(derate_current "$base")
      # system limit unlock (bright-screen charge fix); slider still controls current
      apply_limit_unlock
      if [ "$derated" != "$last_written" ]; then
        before_now=$(get_battery_current_now)
        if apply_derated "$derated" "$cap"; then
          last_written=$derated
          result="OK ${derated}mA (目标 ${base}mA)"
          if [ "${SYSFS_WRITE_ENABLE:-false}" = "true" ]; then
            node=$(pick_charger_node)
            last_effective=$(cat "$node" 2>/dev/null)
          else
            node="votable"
            last_effective=$(cat /proc/oplus-votable/VOOC_CURR/force_val 2>/dev/null)
          fi
          sleep 2
          after_now=$(get_battery_current_now)
        else
          result="FAIL ${derated}mA (写入失败)"
          after_now=""
        fi
        temp=$(get_battery_temp_tenths)
        actual=$(get_battery_current_now)
        maxc=$(get_uevent_current_max)
        if [ "${SYSFS_WRITE_ENABLE:-false}" = "true" ]; then
          node=$(pick_charger_node)
        else
          node="votable"
        fi
        {
          echo "last_apply=$(date '+%F %T')"
          echo "result=$result"
          echo "charging=$charging"
          echo "mode=$mode"
          echo "manual_current=${manual:-auto}mA"
          echo "capacity=${cap}%"
          echo "target_current=${base}mA"
          echo "applied_current=${derated}mA"
          echo "actual_current=${actual:-n/a}µA"
          echo "current_before=${before_now:-n/a}µA"
          echo "current_after=${after_now:-n/a}µA"
          echo "max_current=${maxc:-n/a}µA"
          if [ -n "$temp" ]; then
            echo "temperature=$((temp / 10)).$((temp % 10))℃"
          fi
          echo "node=${node:-none}"
          echo "daemon_pid=$$"
        # v1.8.32: 原子写(见 common.sh atomic_write)。status.txt 会被
        # `action.sh status` 逐行 grep, 非原子写会读到缺行的中间态。
        } | atomic_write "$STATUS_FILE"
      else
        if [ "${SYSFS_WRITE_ENABLE:-false}" = "true" ]; then
          node=$(pick_charger_node)
          if [ -n "$node" ] && [ -n "$last_effective" ]; then
            rb=$(cat "$node" 2>/dev/null)
            if [ -n "$rb" ] && [ "$rb" != "$last_effective" ]; then
              log "节点值被改动 ($rb != $last_effective)，补写 ${derated}mA"
              write_current_ma "$derated" "$cap"
              last_effective=$(cat "$node" 2>/dev/null)
            fi
          fi
        fi
        check_votable_ma "$derated"
      fi
    fi
  fi
  sleep "${DAEMON_INTERVAL_SEC:-1}"
done
exit 0
