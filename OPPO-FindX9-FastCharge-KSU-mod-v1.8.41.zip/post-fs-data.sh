#!/system/bin/sh
MODDIR=${0%/*}
MODID=oppo_findx9_fastcharge
mkdir -p "$MODDIR/logs" 2>/dev/null
chmod 0755 "$MODDIR/logs" 2>/dev/null
chmod 0666 /sys/class/oplus_chg/battery/battery_cc 2>/dev/null
chmod 0666 /sys/class/power_supply/main/constant_charge_current_max 2>/dev/null
chmod 0666 /sys/class/power_supply/battery/constant_charge_current_max 2>/dev/null
chmod 0666 /sys/class/power_supply/battery/constant_charge_current 2>/dev/null
chmod 0666 /sys/class/xm_power/charger/charger_thermal/wired_chg_curr 2>/dev/null
USER_CONFIG=/data/adb/$MODID/fastcharge.conf
if [ ! -f "$USER_CONFIG" ]; then
  mkdir -p "/data/adb/$MODID" 2>/dev/null
  cp -f "$MODDIR/config/fastcharge.conf" "$USER_CONFIG" 2>/dev/null
  chmod 0644 "$USER_CONFIG" 2>/dev/null
else
  CONFIG_VERSION_TMPL=$(grep '^CONFIG_VERSION=' "$MODDIR/config/fastcharge.conf" 2>/dev/null | cut -d= -f2)
  CONFIG_VERSION_OLD=$(grep '^CONFIG_VERSION=' "$USER_CONFIG" 2>/dev/null | cut -d= -f2)
  if [ -n "$CONFIG_VERSION_TMPL" ] && [ "$CONFIG_VERSION_OLD" != "$CONFIG_VERSION_TMPL" ]; then
    cp -f "$USER_CONFIG" "$USER_CONFIG.bak" 2>/dev/null
    cp -f "$MODDIR/config/fastcharge.conf" "$USER_CONFIG" 2>/dev/null
    chmod 0644 "$USER_CONFIG" 2>/dev/null
  fi

  # ---- 增量迁移 ----
  # 保留用户原有配置；仅补齐新版协议开关。PPS/PD 默认不强制激活，
  # 让系统协议栈自行协商，避免第三方 PPS/PD 被锁到低功率档。
  if ! grep -q '^VOOTABLE_FORCE_ACTIVE=' "$USER_CONFIG" 2>/dev/null; then
    echo 'VOOTABLE_FORCE_ACTIVE=true' >> "$USER_CONFIG" 2>/dev/null
  fi
  if ! grep -q '^VOOTABLE_PPS_FORCE_ACTIVE=' "$USER_CONFIG" 2>/dev/null; then
    echo 'VOOTABLE_PPS_FORCE_ACTIVE=false' >> "$USER_CONFIG" 2>/dev/null
  fi

  # v1.7.5 清理已废弃的本地 fcweb / 旧 HANS 配置项。
  sed -i \
    -e '/^FCWEB_ENABLE=/d' \
    -e '/^FCWEB_PORT=/d' \
    -e '/^FLUID_KEEPALIVE_ENABLE=/d' \
    -e '/^HANS_DISABLE=/d' \
    -e '/^FREEZE_BINDER_DISABLE=/d' \
    "$USER_CONFIG" 2>/dev/null
fi
exit 0
