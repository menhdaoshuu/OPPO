#!/system/bin/sh
# OPPO Find X9 FastCharge - UI independent service
# 重要：快充守护进程不得依赖 KSU WebUI。WebUI 只是控制/查看前端，关闭后仍应正常工作。

MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"

CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

# 等待系统完成启动；不再等待“屏幕亮起”，避免快充功能被 WebUI/屏幕状态间接影响。
i=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ] && [ "$i" -lt 180 ]; do
  sleep 2
  i=$((i + 2))
done

if [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; then
  log "系统启动完成，独立启动快充守护进程（不依赖 WebUI/屏幕状态）"
else
  log "等待 sys.boot_completed 超时，仍尝试启动快充守护进程"
fi

# ColorOS 17 生命周期兼容：不再全局关闭 HANS / CachedAppOptimizer。
# 旧版会修改 sys.hans.enable 和 activity_manager/freeze_binder_enabled，
# 可能与 ColorOS 17 的流体云生命周期管理产生“停止/重新拉起”循环。
# 现在仅让载体 App 自己使用前台服务运行，避免模块接管系统后台策略。

# 同步"残留清理脚本"到共享存储(每次开机自动更新):
#   customize.sh 只在"安装模块那一刻"复制一次, 之后模块升级/脚本改动都不会刷新它,
#   会导致用户手里的 /storage/emulated/0/FindX9快充残留清理.sh 长期停留在旧版本(缺新清理项)。
#   这里每次开机都比对内容, 不一致才覆盖, 保证它始终等于当前模块内的 scripts/cleanup.sh。
if [ "${CLEANUP_SYNC_ENABLE:-true}" = "true" ]; then
  _cl_dst=/storage/emulated/0/FindX9快充残留清理.sh
  _cl_src="$MODDIR/scripts/cleanup.sh"
  if [ -d /storage/emulated/0 ] && [ -f "$_cl_src" ]; then
    _sum_src=$(md5sum "$_cl_src" 2>/dev/null | cut -d' ' -f1)
    _sum_dst=$(md5sum "$_cl_dst" 2>/dev/null | cut -d' ' -f1)
    if [ -n "$_sum_src" ] && [ "$_sum_src" != "$_sum_dst" ]; then
      if cp -f "$_cl_src" "$_cl_dst" 2>/dev/null; then
        chmod 0755 "$_cl_dst" 2>/dev/null
        log "已同步最新残留清理脚本 -> /storage/emulated/0/FindX9快充残留清理.sh"
      fi
    fi
  fi
fi

if [ "${DAEMON_ENABLED:-true}" = "true" ]; then
  start_daemon
  start_fluid_daemon
else
  apply_fastcharge
  exit $?
fi

# 轻量 watchdog：WebUI 关闭、KSU Manager 退出均不应影响 daemon。
# daemon 自己负责每秒重写充电控制；这里负责三件事：
#   1) daemon 意外退出后的拉起
#   2) daemon "假死"检测 —— Android 17 / ColorOS 17 实测存在 daemon 进程存活
#      但主循环卡住不干活的情况(表现为流体云一直停在旧值/待机、votable 电流不再刷新)。
#      通过监测流体云功率文件的修改时间来发现假死并强制重启。
while :; do
  sleep 10
  if [ "${DAEMON_ENABLED:-true}" != "true" ]; then
    break
  fi
  if ! is_daemon_running; then
    log "检测到快充守护进程退出，自动重启"
    start_daemon
  fi
  # 流体云独立守护：与快充 daemon 分开监控，任何一方异常都不会拖死另一方。
  if [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ]; then
    _ff="$LOG_DIR/fluid_cloud.pid"
    _fpid=$(cat "$_ff" 2>/dev/null)
    if [ -z "$_fpid" ] || ! kill -0 "$_fpid" 2>/dev/null; then
      log "检测到独立流体云守护进程退出，自动重启"
      start_fluid_daemon
    fi
  fi
  # 独立流体云假死检测：只重启流体云 daemon，不碰快充 daemon。
  if [ "${FLUID_CLOUD_ENABLE:-true}" = "true" ]; then
    _fp="$LOG_DIR/fluid_power.txt"
    _mt=$(stat -c %Y "$_fp" 2>/dev/null)
    _now=$(date +%s)
    if [ -n "$_mt" ] && [ "$((_now - _mt))" -gt 20 ]; then
      _fpid=$(cat "$LOG_DIR/fluid_cloud.pid" 2>/dev/null)
      log "检测到独立流体云刷新停滞(>20s)，仅重启流体云 daemon"
      [ -n "$_fpid" ] && kill -9 "$_fpid" 2>/dev/null
      rm -f "$LOG_DIR/fluid_cloud.pid" 2>/dev/null
      start_fluid_daemon
    fi
  fi
done
exit 0
