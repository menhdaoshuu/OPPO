#!/system/bin/sh
#
# action.sh - OPPO Find X9 快充增强 模块操作入口
#
# 用法（无参数 = 交互式音量键调流，KSU 管理器「操作」按钮）：
#   sh action.sh               交互式：音量+/- 每次加减 500mA
#   sh action.sh set 6500      设置手动电流为 6500mA 并立即生效
#   sh action.sh auto          恢复自动档位（按电量分档）
#   sh action.sh apply         重新应用当前目标（手动值或自动档）
#   sh action.sh restart       重启守护进程并应用
#   sh action.sh start         启动守护进程（未运行时）
#   sh action.sh stop          停止守护进程
#   sh action.sh clean         清理模块残留文件（日志/配置/手动值/临时文件, 免确认）
#   sh action.sh status        输出 key=value 状态（WebUI 使用）

MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"

CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

step=${MANUAL_STEP_MA:-500}

# 超过危险阈值时输出醒目提示（MANUAL_DANGER_MA，默认 9200）
warn_if_danger() {
  v="$1"
  d=${MANUAL_DANGER_MA:-9200}
  case "$v" in ""|*[!0-9]*|0) return 0 ;; esac
  case "$d" in ""|*[!0-9]*|0) return 0 ;; esac
  if [ "$v" -gt "$d" ]; then
    echo "⚠⚠⚠ [危险] 电流 ${v}mA 超过危险阈值 ${d}mA！"
    echo "⚠  电池过热损伤风险极高，请务必确认已开启散热背夹/散热器！"
  fi
}

# ---------- key=value 状态（供 WebUI / 自检解析） ----------
status_lines() {
  m=$(read_manual_current)
  if [ -n "$m" ]; then
    mode="manual"
    mc="${m}mA"
  else
    mode="auto"
    mc="auto"
  fi

  cap=$(get_battery_capacity)
  t=$(get_battery_temp_tenths)
  now=$(get_battery_current_now)
  if is_charging; then st="charging"; else st="idle"; fi

  base="$m"
  [ -z "$base" ] && base=$(current_for_capacity "$cap")
  [ -z "$base" ] && base="n/a"

  echo "mode=$mode"
  echo "manual_current=$mc"
  echo "charging=$st"
  echo "capacity=${cap:-n/a}"
  if [ -n "$t" ]; then
    echo "temp=$((t / 10)).$((t % 10))"
  else
    echo "temp=n/a"
  fi
  echo "current_now=${now:-n/a}"
  echo "target_current=${base}mA"
  # FFC 常驻：当前强制快充节点值（1=生效, 空=节点缺失）
  echo "ffc=$(cat "${FFC_FAST_CHARGE_NODE:-/sys/class/oplus_chg/battery/fast_charge}" 2>/dev/null | tr -d ' \n\r')"

  if [ -f "$STATUS_FILE" ]; then
    grep -E '^(applied_current|result|node|daemon_pid|last_apply)=' "$STATUS_FILE" 2>/dev/null
  fi

  for v in $VOOTABLE_NODES; do
    case "$v" in
      ""|\#*) continue ;;
    esac
    if [ -r "$v/force_val" ]; then
      echo "votable=$v"
      echo "votable_force_val=$(cat "$v/force_val" 2>/dev/null)"
      echo "votable_force_active=$(cat "$v/force_active" 2>/dev/null)"
      break
    fi
  done
}

# ---------- 交互式音量键调流（KSU 管理器「操作」执行页） ----------
interactive_mode() {
  if ! command -v getevent >/dev/null 2>&1; then
    echo "! 未找到 getevent，无法监听音量键"
    echo "  可用命令行方式: $0 set 6500  或  $0 auto"
    exit 1
  fi

  echo "============================================"
  echo "  OPPO Find X9 快充 · 音量键手动调流"
  echo "============================================"
  echo "  [音量+]   +${step}mA"
  echo "  [音量-]   -${step}mA"
  echo "  [电源键 / 返回键]   保存并退出"
  echo "  30 秒无按键自动退出（保留当前值）"
  echo "  恢复自动档: WebUI 点【恢复自动】或执行 $0 auto"
  echo "--------------------------------------------"

  cur=$(read_manual_current)
  if [ -n "$cur" ]; then
    echo "当前: 手动 ${cur}mA"
  else
    base=$(current_for_capacity "$(get_battery_capacity)")
    [ -z "$base" ] && base=${MANUAL_DEFAULT_MA:-5000}
    base=$(( (base + 250) / 500 * 500 ))
    [ "$base" -lt 500 ] && base=500
    cur=$base
    echo "当前: 自动档（基准 ${base}mA），按音量键后转为手动锁定"
  fi
  echo "--------------------------------------------"

  KEY_TMP=/data/local/tmp/ksu_fastcharge_key.txt

  while :; do
    rm -f "$KEY_TMP" 2>/dev/null
    getevent -c 1 > "$KEY_TMP" 2>/dev/null &
    pid=$!
    ticks=0
    while [ ! -s "$KEY_TMP" ] && kill -0 "$pid" 2>/dev/null; do
      ticks=$((ticks + 1))
      if [ "$ticks" -ge 30 ]; then
        kill "$pid" 2>/dev/null
        break
      fi
      sleep 1
    done
    ev=$(cat "$KEY_TMP" 2>/dev/null)

    # 30 秒（30 × 1s）无事件 -> 退出
    if [ -z "$ev" ]; then
      echo "[超时] 30 秒无操作，退出（当前值已保留）"
      break
    fi

    code=$(echo "$ev" | awk '{print $3}')
    val=$(echo "$ev" | awk '{print $4}')

    # 只处理按下事件（value=0001），UP/重复事件忽略
    [ "$val" = "0001" ] || continue

    case "${code:-none}" in
      0073) # KEY_VOLUMEUP
        cur=$((cur + step))
        if set_manual_current "$cur"; then
          echo "[音量+] -> ${cur}mA（已生效）"
        else
          echo "[音量+] -> ${cur}mA（已记录，写入结果见日志）"
        fi
        warn_if_danger "$cur"
        ;;
      0072) # KEY_VOLUMEDOWN
        cur=$((cur - step))
        [ "$cur" -lt "${MANUAL_MIN_MA:-1000}" ] && cur=${MANUAL_MIN_MA:-1000}
        if set_manual_current "$cur"; then
          echo "[音量-] -> ${cur}mA（已生效）"
        else
          echo "[音量-] -> ${cur}mA（已记录，写入结果见日志）"
        fi
        warn_if_danger "$cur"
        ;;
      *) # 其他按键（电源/返回等）-> 保存并退出
        if [ -n "$(read_manual_current)" ]; then
          echo "[退出] 已保存当前值 ${cur}mA"
        else
          echo "[退出] 未设置手动值，保持自动档"
        fi
        break
        ;;
    esac
  done
  rm -f "$KEY_TMP" 2>/dev/null

  echo "--------------------------------------------"
  m=$(read_manual_current)
  if [ -n "$m" ]; then
    echo "结束。当前手动电流: ${m}mA"
  else
    echo "结束。当前模式: 自动档（按电量分档）"
  fi
  echo "恢复自动档: WebUI【恢复自动】或执行 $0 auto"
  exit 0
}

# ---------- 命令分发 ----------
case "$1" in
  set)
    ma="$2"
    case "$ma" in
      ""|*[!0-9]*) echo "用法: $0 set <毫安>   例: $0 set 6500"; exit 1 ;;
    esac
    if set_manual_current "$ma"; then
      echo "已设置手动电流: $(clamp_manual_ma "$ma")mA（立即生效）"
    else
      echo "!! 手动电流已记录，但充电节点写入失败（详见日志）"
    fi
    warn_if_danger "$ma"
    status_lines
    ;;
  auto)
    if set_manual_current 0; then
      echo "已恢复自动档位电流（按电量分档）"
    else
      echo "!! 恢复自动时写入失败（详见日志）"
    fi
    status_lines
    ;;
  apply)
    m=$(read_manual_current)
    if [ -n "$m" ]; then
      set_manual_current "$m"
    else
      apply_fastcharge
    fi
    status_lines
    ;;
  restart)
    echo "重启快充控制..."
    stop_daemon
    if [ "${DAEMON_ENABLED:-true}" = "true" ]; then
      start_daemon
    else
      apply_fastcharge
    fi
    sleep 1
    status_lines
    ;;
  start)
    start_daemon
    status_lines
    ;;
  stop)
    stop_daemon
    echo "守护进程已停止"
    ;;
  clean)
    sh "$MODDIR/scripts/cleanup.sh" -y
    ;;
  status)
    status_lines
    ;;
  *)
    echo "== 重启快充控制 =="
    stop_daemon
    if [ "${DAEMON_ENABLED:-true}" = "true" ]; then
      start_daemon
    else
      apply_fastcharge
    fi
    sleep 1
    echo ""
    echo "== 模块自检 =="
    if is_daemon_running; then
      echo "守护进程: 运行中 (PID $(cat "$DAEMON_PID_FILE"))"
    else
      echo "守护进程: 未运行"
    fi
    if is_charging; then
      echo "充电状态: 充电中"
    else
      echo "充电状态: 未充电（模块始终在线，限流已就位）"
    fi
    cap=$(get_battery_capacity)
    [ -n "$cap" ] && echo "电量: ${cap}%"
    t=$(get_battery_temp_tenths)
    [ -n "$t" ] && echo "温度: $((t / 10)).$((t % 10))℃"
    node=$(pick_charger_node)
    if [ -n "$node" ]; then
      echo "电流节点: $node"
      echo "节点当前值: $(cat "$node" 2>/dev/null)"
    else
      echo "电流节点: 未找到可写节点（votable 通道由守护进程维护）"
    fi
    actual=$(get_battery_current_now)
    [ -n "$actual" ] && echo "实际电流: $((actual / 1000))mA ($actualµA)"
    maxc=$(get_uevent_current_max)
    [ -n "$maxc" ] && echo "系统最大电流: $((maxc / 1000))mA ($maxcµA)"
    dev=$(getprop ro.product.device 2>/dev/null)
    model=$(getprop ro.product.model 2>/dev/null)
    echo "机型: device=$dev model=$model (配置期望: $DEVICE_CODENAMES)"
    m=$(read_manual_current)
    if [ -n "$m" ]; then
      echo "手动电流: ${m}mA（守护进程持续锁定）"
    else
      echo "手动电流: 未设置（自动档）"
    fi
    echo "----------------------------------------"
    echo ""
    echo ""
    interactive_mode
    ;;
esac

exit 0
