#!/system/bin/sh
# OPPO Find X9 FastCharge - UI independent service
# 重要：快充守护进程不得依赖 KSU WebUI。WebUI 只是控制/查看前端，关闭后仍应正常工作。

MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"

CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

# 等待系统完成启动；不再等待“屏幕亮起”，避免快充功能被 WebUI/屏幕状态间接影响。
i=0
while [ "$(getprop sys.boot_completed 2>/dev/null)" != "1" ] && [ "$i" -lt 180 ]; do
  sleep 2
  i=$((i + 2))
done

if [ "$(getprop sys.boot_completed 2>/dev/null)" = "1" ]; then
  log "系统启动完成，独立启动快充守护进程（不依赖 WebUI/屏幕状态）"
else
  log "等待 sys.boot_completed 超时，仍尝试启动快充守护进程"
fi

if [ "${DAEMON_ENABLED:-true}" = "true" ]; then
  start_daemon
else
  apply_fastcharge
  exit $?
fi

# 轻量 watchdog：WebUI 关闭、KSU Manager 退出均不应影响 daemon。
# daemon 自己负责每秒重写充电控制；这里仅负责 daemon 意外退出后的拉起。
while :; do
  sleep 10
  if [ "${DAEMON_ENABLED:-true}" != "true" ]; then
    break
  fi
  if ! is_daemon_running; then
    log "检测到快充守护进程退出，自动重启"
    start_daemon
  fi
done
exit 0
