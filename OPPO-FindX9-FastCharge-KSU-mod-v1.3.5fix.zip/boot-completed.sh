#!/system/bin/sh
# boot-completed fallback. It is intentionally UI-independent.
MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"
CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

if [ "${DAEMON_ENABLED:-true}" = "true" ]; then
  if ! is_daemon_running; then
    log "boot-completed 兜底：启动快充守护进程（不等待 WebUI/屏幕）"
    start_daemon
  else
    log "boot-completed 兜底：守护进程已运行"
  fi
else
  apply_fastcharge
fi
exit 0
