#!/system/bin/sh
# ============================================================
# cleanup_fastcharge.sh - OPPO Find X9 快充增强 残留文件清理
#
# 用法:
#   sh cleanup_fastcharge.sh                  完整清理（需确认）
#   sh cleanup_fastcharge.sh -y               完整清理（跳过确认）
#   sh cleanup_fastcharge.sh --keep-config -y 保留 fastcharge.conf，
#                                             仅清日志/手动值/临时文件
#
# 清理内容:
#   - 停止守护进程（PID 文件 + pkill 兜底）
#   - 模块日志目录 logs/（fastcharge.log / status.txt / daemon.pid / derate.state）
#   - 用户配置目录 /data/adb/oppo_findx9_fastcharge
#     （fastcharge.conf / .bak / current_ma 手动电流 / current_state.txt）
#   - 执行页与安装产生的临时文件（ksu_fastcharge_key.txt / key_event.txt）
# ============================================================

MODID=oppo_findx9_fastcharge
MODROOT=/data/adb/modules/$MODID
USER_DIR=/data/adb/$MODID
LOG_DIR=$MODROOT/logs

confirm="ask"
keep_config=0

for a in "$@"; do
  case "$a" in
    -y|--force|--yes) confirm="force" ;;
    --keep-config)    keep_config=1 ;;
    -h|--help)
      echo "用法: sh cleanup_fastcharge.sh [-y] [--keep-config]"
      exit 0
      ;;
    *)
      echo "! 未知参数: $a"
      exit 1
      ;;
  esac
done

if [ "$(id -u 2>/dev/null)" != "0" ]; then
  echo "! 需要 root 权限才能清理"
  echo "  请在 KernelSU 终端 / adb root 下执行，例如:"
  echo "    su -c sh $0 -y"
  exit 1
fi

echo "==== OPPO Find X9 快充模块残留清理 ===="
if [ "$keep_config" = "1" ]; then
  echo "模式: 保留 $USER_DIR/fastcharge.conf，仅清日志/手动值/临时文件"
else
  echo "模式: 完整清理（含配置、手动电流、日志）"
fi

if [ "$confirm" != "force" ]; then
  printf "确认清理? [y/N] "
  read ans
  case "$ans" in
    y|Y|yes|YES) ;;
    *) echo "已取消"; exit 0 ;;
  esac
fi

# ---------- 1. 停止守护进程 ----------
killed=0
if [ -f "$LOG_DIR/daemon.pid" ]; then
  pid=$(cat "$LOG_DIR/daemon.pid" 2>/dev/null)
  if [ -n "$pid" ]; then
    kill "$pid" 2>/dev/null && { echo "[OK] 已停止守护进程 (PID $pid)"; killed=1; }
  fi
fi
if [ "$killed" = "0" ]; then
  if pkill -f 'fastcharge_daemon.sh' 2>/dev/null; then
    echo "[OK] 已停止守护进程 (pkill 兜底)"
  else
    echo "[--] 未发现运行中的守护进程"
  fi
fi
sleep 1

# ---------- 2. 模块日志 ----------
if [ -d "$LOG_DIR" ]; then
  rm -rf "$LOG_DIR" 2>/dev/null
  echo "[OK] 已删除模块日志目录: $LOG_DIR"
else
  echo "[--] 日志目录不存在: $LOG_DIR"
fi

# ---------- 3. 用户配置 / 手动电流状态 ----------
if [ "$keep_config" = "1" ]; then
  rm -f "$USER_DIR/fastcharge.conf.bak" 2>/dev/null
  rm -f "$USER_DIR/current_ma" 2>/dev/null
  rm -f "$USER_DIR/current_state.txt" 2>/dev/null
  echo "[OK] 已清理: fastcharge.conf.bak / current_ma / current_state.txt（保留 fastcharge.conf）"
else
  if [ -d "$USER_DIR" ]; then
    rm -rf "$USER_DIR" 2>/dev/null
    echo "[OK] 已删除用户配置目录: $USER_DIR"
  else
    echo "[--] 用户配置目录不存在: $USER_DIR"
  fi
fi

# ---------- 4. 临时文件 ----------
n=0
for f in /data/local/tmp/ksu_fastcharge_key.txt \
         /data/local/tmp/key_event.txt \
         /dev/tmp/key_event.txt; do
  if [ -f "$f" ]; then
    rm -f "$f" 2>/dev/null
    echo "[OK] 已删除临时文件: $f"
    n=$((n + 1))
  fi
done
[ "$n" = "0" ] && echo "[--] 无临时文件残留"

echo "----------------------------------------"
if [ -d "$MODROOT" ]; then
  echo "!! 注意: 模块仍处于安装/启用状态"
  echo "   手机重启或屏幕亮起后 service.sh 会重新创建日志/写入限流"
  echo "   若不再使用: 请在 KSU 管理器卸载模块后，可再运行本脚本收尾"
  if [ "$keep_config" = "1" ]; then
    echo "   已保留用户配置: $USER_DIR/fastcharge.conf"
  fi
fi
echo "==== 清理完成 ===="
exit 0
