#!/system/bin/sh

MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"

CONFIG_PATH=/data/adb/oppo_findx9_fastcharge/fastcharge.conf
load_config "$CONFIG_PATH"

if [ "${START_ON_SCREEN_ON:-true}" = "true" ]; then
  log "boot-completed 兜底: 等待屏幕亮起 (最多 60s)"
  waited=0
  while ! is_screen_on; do
    sleep 2
    waited=$((waited + 2))
    if [ "$waited" -ge 60 ]; then
      log "等待屏幕亮起超时(60s)，继续启动"
      break
    fi
  done
  delay=${SCREEN_ON_DELAY_SEC:-15}
  log "等待 ${delay}s 后启动守护进程"
  sleep "$delay"
fi

if [ "${DAEMON_ENABLED:-true}" = "true" ]; then
  start_daemon
else
  apply_fastcharge
fi

exit 0
