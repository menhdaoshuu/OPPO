============================================================
OPPO Find X9 快充增强 (KernelSU) v1.1.0 - 手动电流调节版
============================================================

【新增功能】
1. WebUI 滑动条调流（需 KSU 管理器含 WebUI 支持）
   - 安装后模块页会多出一个【WebUI】按钮/图标
   - 滑动条范围 1000~13000mA（步进 100），另有 +500/-500 按钮和
     3000/5000/8000 预设值
   - 超过 9200mA（MANUAL_DANGER_MA）会弹出危险警告弹窗，
     倒计时 3 秒后才可点击「继续设置」或「取消」关闭
   - 点【应用电流】立即生效；点【恢复自动】回到电量分档模式
   - 页面每 5 秒自动刷新实时状态

2. 执行页音量键调流
   - KSU 管理器模块页点【操作】运行 action.sh
   - [音量+]  每次 +500mA        [音量-]  每次 -500mA
   - [电源键/返回键]  保存并退出；30 秒无按键自动退出（保留当前值）
   - 音量键调节超过 9200mA 时执行页会同步打印危险提示

3. FFC 强制快充（整合自 FFC 模块逻辑）
   - WebUI 一键开启/关闭（默认关闭）
   - 开启后充电时持续锁定系统强制快充开关（fast_charge），
     并解除冷却降流 / 阶梯充电 / 受限充电限制
   - 节点不存在自动跳过（兼容机型差异）；温度降额与过流保护仍生效
   - 命令行: sh action.sh ffc on|off|status

【命令行用法】（有 root 的终端 / ADB）
   sh /data/adb/modules/oppo_findx9_fastcharge/action.sh set 6500   # 设 6500mA
   sh /data/adb/modules/oppo_findx9_fastcharge/action.sh auto        # 恢复自动
   sh /data/adb/modules/oppo_findx9_fastcharge/action.sh status      # 查看状态
   sh /data/adb/modules/oppo_findx9_fastcharge/action.sh restart     # 重启守护进程

【原理】
- 手动值保存在 /data/adb/oppo_findx9_fastcharge/current_ma
- 守护进程每秒读取：有手动值则以手动值为目标，无则按电量分档
- 手动值同样受到温度降额（41.6℃ 起）和实测过流保护约束，不会无脑拉满
- 卸载模块时可选择清理手动值（卸载脚本已自动清理）

【配置】
/data/adb/oppo_findx9_fastcharge/fastcharge.conf 中新增第 9 节：
  MANUAL_MIN_MA=1000     # 手动下限
  MANUAL_MAX_MA=13000    # 手动上限（须 ≤ GLOBAL_MAX_MA）
  MANUAL_DANGER_MA=9200  # 超过此值弹危险警告（WebUI 3 秒倒计时）
  MANUAL_STEP_MA=500     # 音量键步进
  MANUAL_DEFAULT_MA=5000
配套调整：
  GLOBAL_MAX_MA=13000    # 全局硬上限（须 ≥ MANUAL_MAX_MA）
  SAFETY_MAX_MA=13500    # 实测过流保护上限（须高于手动上限，否则高电流档会被反复压回 2000）

【注意】
- 请务必搭配散热器使用；高于 9200mA 危险区发热极大，谨慎使用！
- 若屏幕亮起后 15 秒模块未启动，可点【操作】或手动执行 restart
============================================================
