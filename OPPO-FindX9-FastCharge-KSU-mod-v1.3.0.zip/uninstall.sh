#!/system/bin/sh

MODDIR=${0%/*}
export MODROOT=$MODDIR
. "$MODDIR/scripts/common.sh"

stop_daemon
rm -rf "$MODDIR/logs" 2>/dev/null
rm -f "$USER_CONFIG_DIR/current_ma" "$USER_CONFIG_DIR/current_state.txt" 2>/dev/null
rm -f /data/local/tmp/ksu_fastcharge_key.txt /data/local/tmp/key_event.txt /dev/tmp/key_event.txt 2>/dev/null

echo "已停止守护进程并清理日志"
echo "提示: 如卸载时正在充电，当前限流值在重新插拔充电器或重启后由系统恢复默认"
echo "用户配置已保留: /data/adb/$MODID/fastcharge.conf"
echo "如需彻底删除配置，请手动删除该目录"

exit 0
